# Study Rooms — RF2

A local study-room reservation application with a native CLI, server-rendered browser interface, and one read-only MCP tool. All application runtime source is RF2. `launch.json` contains `["./app"]`; the signed native `app` is included.

## Build

On this Mac (Darwin ARM64), from this directory:

```sh
./rf2c main.flow app.next --compact --opt
codesign -s - app.next
mv app.next app
```

The compiler exclusively creates its output and refuses to overwrite an existing path. Choose an unused output name if `app.next` exists. No package installation or external runtime is required. `application.flow` implements command handling, form actions, rendering and the MCP callback; `main.flow` is the error/exit entry point.

## Use

```sh
./app init rooms.db
./app reserve rooms.db 1 1 3 2026-11-16 09:00 10:00
./app list rooms.db
./app cancel rooms.db 2 1
./app serve rooms.db
```

The reserve example returns revision 2 with reservation `{"id":"1","room":3,"day":739936,"start":540,"finish":600}` (and the SDK's version field). Each successful mutation increments the revision. Use the latest saved revision for the next change. `init` exclusively creates a new file; it refuses an existing path. Failure prints `{"error":CODE}` and exits 2. Success exits 0.

`serve` requires an existing readable workspace. It prints its exact `http://127.0.0.1:PORT/` address as the first line and serves until terminated (Ctrl-C). Open that address in a browser. The page displays saved reservations, a room/date/start/end form, and explicit cancellation buttons. End `24:00` means the end of the selected day. Pages use current saved revisions; stale or overlapping submissions display an explanation and reload saved state while retaining reserve details. Forms use an unpredictable token generated for each server process. Restarting the server invalidates old forms.

The server validates the exact loopback Host and POST Origin, request framing and form fields. No scripts, fonts, assets or services are fetched externally. Layout has responsive breakpoints, light/dark system colors, labelled controls, a skip link and visible keyboard focus. This is a local single-user tool, with no authentication claim or public hosting support.

## Read-only MCP

Start `./app mcp rooms.db` with newline-delimited JSON-RPC on stdin/stdout. Initialize with protocol version `2025-11-25`, send `notifications/initialized`, then use `tools/list` or:

```json
{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"booking_list","arguments":{}}}
```

Exactly one tool is advertised. It reads only the launch-selected workspace and returns `structuredContent` plus a short text result. It accepts an explicit empty arguments object; no paths or mutations are exposed. Protocol errors leave the connection usable; storage failures become `isError:true` tool results. Requests are limited to 65536 bytes. This is the SDK's bounded legacy MCP subset, not a claim of support for other protocol versions.

## Data and limits

- IDs are positive canonical decimal strings through unsigned 64-bit maximum. Rooms are 1–16. Dates are exact Gregorian `YYYY-MM-DD`, years 0001–9999; times are exact 24-hour `HH:MM`.
- Same-day half-open intervals permit adjacency. Overlaps in the same room/date refuse; other rooms/dates are independent. No recurring reservations or timezone conversion.
- At most 256 current rows; insertion order is preserved and cancellation removes only its exact ID. The supplied collection currently returns error 22 at capacity (observed), rather than the SDK prose's suggested 27. Journal exhaustion returns its storage error.
- The application configures the supplied snapshot journal to 4 MiB before its first operation. History is bounded, with no compaction or migration UI. A long mutation history can exhaust it even with fewer current rows. Keep the file and create another workspace when needed; do not edit journal bytes.
- Storage uses the supplied domain validation, advisory locking, revision comparison, append/sync handling and private hashed snapshot schema. Missing files map to 404. Invalid numeric syntax/overflow maps to 22; storage failures remain failures. Uncertain saves never become successful confirmations.
- The SDK requires regular single-link files, refuses symlinks, and relies on cooperative local file locking. It is not protection against a hostile same-user filesystem actor. Backups should be taken while stopped. Corrupt/incomplete journals fail closed; this application exposes no repair command.
- Native trusted raw-pointer SDK code targets Mac ARM64/Darwin. Portability, full memory safety, hardware qualification, crash/fault injection and production internet security have not been established.

## Tests and evidence

The supplied `lib/` files are starting SDKs, used unchanged: booking ownership/domain rules, durable store, date/text parsing, HTTP framing/forms, UI CSS/helpers, and bounded MCP. They do not provide this application's command routing, page, form/domain integration or selected-workspace callback.

Python standard-library files under `tests/` are test drivers only, not runtime implementation. Build the separate RF2 browser test harness:

```sh
./rf2c browser-check.flow browser-check.next --compact --opt
codesign -s - browser-check.next
mv browser-check.next browser-check
python3 tests/selftest.py --skip-http
python3 tests/browser_direct.py
python3 tests/http_pipe.py
```

Actual results from this attempt:

- **363 assertions passed**: fresh-process CLI, date/time/ID bounds, adjacency/overlap, room/date independence, durable reopening, cancellation order, revision races, busy locking, symlink/corrupt-file refusal, all 256 rows, and MCP initialization/tool schema/listing/errors/notifications/oversized-line recovery.
- **42 assertions passed**: direct native RF2 form actions, stale state refresh, failed input retention/escaping, cancellation and HTML generation.
- **43 assertions passed**: HTTP parser and action dispatch through OS pipes, including Host/Origin mismatch, duplicate headers, transfer encoding/content type refusal, response content length, reserve and cancel.

`artifacts/selftest.txt`, `browser-direct.txt`, `http-pipe.txt` record these results. `artifacts/sample.html` is generated application HTML. `browser-check` has a deterministic token and fixed test endpoint **only in that test executable**; `app` uses the SDK's random process token and actual bound endpoint.

**TCP and visual limit:** the sandbox denies socket creation/bind (`Operation not permitted`), independently reproduced with a minimal loopback probe. Consequently `serve` returns `{"error":5}` in this environment. Real loopback HTTP end-to-end tests are included in `tests/selftest.py` (run without `--skip-http` where permitted), but did not pass here because the listener cannot start. The pipe checks do not verify TCP binding, connection handling or browser appearance. No graphical browser inspection was performed. This limitation is not represented as a passed test.

Actual failed checks are retained in `artifacts/failure-*.txt`: numeric overflow mapping, blocked HTTP startup, MCP response newline, capacity code mismatch, and an initial test-harness transport timeout. See `docs/PROGRESS.md` for the corrections. No external acceptance/grader tests, human trials, token/speed claims, remote services or shared compute were used.
