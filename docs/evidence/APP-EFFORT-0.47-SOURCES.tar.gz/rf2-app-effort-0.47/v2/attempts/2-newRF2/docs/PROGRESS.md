# Local trial handover

Implemented the Study Rooms application entirely in RF2, using the supplied SDK unchanged. Delivered signed native `app`, `launch.json`, RF2 source, README, test drivers and native test harness.

Verified locally: 363 CLI/storage/MCP assertions, 42 direct form/render assertions, 43 pipe HTTP/parser assertions. Receipts: `artifacts/selftest.txt`, `artifacts/browser-direct.txt`, `artifacts/http-pipe.txt`. Generated page: `artifacts/sample.html`. Tests use temporary workspaces under this directory and remove them after execution. `artifacts/smoke.db` retains the initial working CLI example.

Corrections/failures preserved:

1. Initial compile rejected a record declared in a handler and direct typed-result forwarding. Records moved to function scope; result calls now explicitly propagate with `try` and return `ok`.
2. First numeric bound test returned SDK error 75 for overflow. Application numeric parsing now converts parse failures to invalid 22; storage errors are not globally remapped.
3. Compiler refused overwriting an existing executable. Rebuilds use a fresh output and replace only after compilation/signing succeeds.
4. Live HTTP failed with error 5. Independent standard-library socket bind returned EPERM. No sandbox bypass attempted. Real TCP serving remains unverified.
5. MCP tool state included the store's trailing newline, breaking newline response framing. Read-only callback trims that one newline; rejected-input/recovery tests now pass.
6. SDK collection capacity returns 22, not prose's 27. Preserved runtime behavior and corrected the local test expectation/documentation; no storage rewrite.
7. Initial direct rendering harness tried an invalid transport descriptor and timed out. Rendering is now a shared application function separate from sending; direct tests use it without transport. Pipe tests exercise framing and dispatch independently of sockets.

Unresolved: socket serving and graphical/interactive browser behavior cannot be validated under this sandbox. No crash-save fault injection, hardware qualification, other platform readiness or unseen acceptance tests claimed. Suggested next check in an environment allowing local listeners: `python3 tests/selftest.py` without the skip flag, then inspect the page at the URL printed by `./app serve DB`.

This is isolated trial continuity only. No remote Memory, shared compute, GitHub write, dependency installation, other workspace access or delegation was used. TASK.md and SDK.md were not edited.
