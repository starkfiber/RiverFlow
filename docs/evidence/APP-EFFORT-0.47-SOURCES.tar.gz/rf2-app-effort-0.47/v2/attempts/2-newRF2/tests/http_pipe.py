"""HTTP framing through OS pipes with a fixed test endpoint; no TCP listener."""
import subprocess, pathlib, tempfile, json, urllib.parse
ROOT=pathlib.Path(__file__).resolve().parents[1]
checks=0

def check(v):
 global checks
 assert v
 checks+=1

def wire(db,method='GET',target='/',body='',host='127.0.0.1:12345',origin='http://127.0.0.1:12345',extra='',content_type='application/x-www-form-urlencoded'):
 if isinstance(body,dict): body=urllib.parse.urlencode(body)
 req=f'{method} {target} HTTP/1.1\r\nHost: {host}\r\n'
 if method=='POST': req+=f'Origin: {origin}\r\nContent-Type: {content_type}\r\nContent-Length: {len(body.encode())}\r\n'
 req+=extra+'\r\n'+body
 p=subprocess.run([str(ROOT/'browser-check'),str(db),'wire',''],input=req.encode(),capture_output=True,timeout=10)
 check(p.returncode==0)
 head,html=p.stdout.split(b'\r\n\r\n',1)
 length=int([v for v in head.split(b'\r\n') if v.startswith(b'Content-Length:')][0].split(b':')[1])
 check(length==len(html))
 return int(head.split()[1]),html.decode()

def state(db): return json.loads(subprocess.check_output([str(ROOT/'app'),'list',str(db)]))
with tempfile.TemporaryDirectory(dir=ROOT/'artifacts',prefix='http-pipe-') as td:
 db=pathlib.Path(td)/'rooms.db'
 subprocess.check_output([str(ROOT/'app'),'init',str(db)])
 code,page=wire(db);check(code==200 and 'Study Rooms' in page)
 fields=dict(action='reserve',rev='1',id='1',room='1',date='2026-11-16',start='09:00',end='10:00',token='0123456789abcdef0123456789abcdef')
 code,page=wire(db,'POST','/action',fields);check(code==200 and 'Saved to your workspace.' in page)
 check(state(db)['revision']==2)
 for kwargs in [dict(host='evil.invalid'),dict(origin='http://evil.invalid'),dict(origin='null'),dict(origin='http://localhost:12345'),dict(extra='Host: 127.0.0.1:12345\r\n'),dict(extra='Origin: http://127.0.0.1:12345\r\n'),dict(extra='Content-Length: 0\r\n'),dict(extra='Transfer-Encoding: chunked\r\n'),dict(content_type='text/plain')]:
  code,page=wire(db,'POST','/action',dict(fields,rev='2',id='2',room='2'),**kwargs)
  check(code==400 and state(db)['revision']==2)
 code,page=wire(db,'POST','/action',dict(fields,rev='2',id='2',room='2',token='bad'));check(code==200 and state(db)['revision']==2)
 code,page=wire(db,target='/missing');check(code==404)
 code,page=wire(db,'POST','/action',dict(action='cancel',rev='2',id='1',token=fields['token']))
 check(code==200 and state(db)['bookings']==[] and state(db)['revision']==3)
print(f'PASS: {checks} assertions for HTTP parser/Host/Origin/framing/response and action dispatch through pipes. TCP binding, sockets, and browser visual behavior NOT exercised.')
