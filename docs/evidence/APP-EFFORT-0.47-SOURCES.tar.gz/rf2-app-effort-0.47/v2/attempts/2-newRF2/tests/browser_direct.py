"""Tests application form handling and generated HTML, NOT HTTP transport."""
import json, pathlib, subprocess, tempfile, urllib.parse, re
ROOT=pathlib.Path(__file__).resolve().parents[1]
TOKEN='0123456789abcdef0123456789abcdef'
checks=0

def check(v):
 global checks
 assert v
 checks+=1

def run(db,mode='render',body=''):
 if isinstance(body,dict): body=urllib.parse.urlencode(body)
 p=subprocess.run([str(ROOT/'browser-check'),str(db),mode,body],capture_output=True,text=True,timeout=10)
 check(p.returncode==0)
 metadata,html=p.stdout.split('\n',1)
 return json.loads(metadata),html

def state(db): return json.loads(subprocess.check_output([str(ROOT/'app'),'list',str(db)]))
with tempfile.TemporaryDirectory(dir=ROOT/'artifacts',prefix='browser-direct-') as td:
 db=pathlib.Path(td)/'rooms.db'
 subprocess.check_output([str(ROOT/'app'),'init',str(db)])
 meta,html=run(db)
 check('Study Rooms' in html and 'No reservations yet.' in html)
 check('name=room' in html and 'name="date"' in html)
 check('prefers-color-scheme:dark' in html and ':focus-visible' in html)
 check('name=token' in html and TOKEN in html and 'name=rev value="1"' in html)
 check(html.endswith('</html>'))
 fields=dict(action='reserve',rev='1',id='1',room='3',date='2024-02-29',start='23:00',end='24:00',token=TOKEN)
 meta,html=run(db,'action',fields)
 check(meta=={'error':0,'saved':1})
 check('Room 3' in html and '2024-02-29' in html and '23:00 – 24:00' in html)
 check('name=action value=cancel' in html and '>Cancel</button>' in html)
 check(state(db)['revision']==2)
 meta,html=run(db,'action',fields)
 check(meta['error']==409)
 check('value="2024-02-29"' in html and 'value="23:00"' in html and 'value="24:00"' in html)
 check('name=rev value="2"' in html and 'name=id value="2"' in html)
 invalid=[dict(fields,rev='2',id='2',token='invalid'),dict(fields,rev='2',id='2',end='22:00'),dict(fields,rev='2',id='2',action='appearance'),dict(fields,rev='2',id='2',date='<bad>'),urllib.parse.urlencode(dict(fields,rev='2',id='2'))+'&room=4',urllib.parse.urlencode(dict(fields,rev='2',id='2'))+'&extra=1']
 for body in invalid:
  meta,html=run(db,'action',body)
  check(meta['error']!=0 and meta['saved']==0)
  check(state(db)['revision']==2)
  check('<bad>' not in html)
 meta,html=run(db,'action',dict(action='cancel',rev='2',id='1',token=TOKEN))
 check(meta=={'error':0,'saved':1})
 check(state(db)['bookings']==[] and state(db)['revision']==3)
 (ROOT/'artifacts'/'sample.html').write_text(html)
print(f'PASS: {checks} assertions for direct RF2 form actions and HTML rendering. HTTP framing/Host/Origin/transport NOT exercised.')
