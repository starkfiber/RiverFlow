"""Local black-box checks. Python is a test driver only, never app runtime."""
import fcntl, sys, datetime, json, subprocess, pathlib, tempfile, urllib.parse, http.client, re, selectors, time
ROOT=pathlib.Path(__file__).resolve().parents[1]
APP=str(ROOT/'app')
checks=0

def check(condition, detail='assertion'):
    global checks
    assert condition, detail
    checks+=1

def cli(*args, error=None):
    p=subprocess.run([APP,*map(str,args)],capture_output=True,text=True,timeout=15)
    result=json.loads(p.stdout)
    check(p.returncode==(2 if error is not None else 0),(args,p.returncode,p.stdout,p.stderr))
    if error is not None: check(result=={'error':error},(args,result))
    return result

def state(db): return cli('list',db)
def reserve(db,rev,id,room=1,date='2024-02-29',start='09:00',end='10:00',error=None):
    return cli('reserve',db,rev,id,room,date,start,end,error=error)

def rpc(p,msg):
    line=msg if isinstance(msg,str) else json.dumps(msg)
    p.stdin.write(line+'\n'); p.stdin.flush()
    sel=selectors.DefaultSelector(); sel.register(p.stdout,selectors.EVENT_READ)
    check(bool(sel.select(5)),'MCP response timeout')
    sel.close()
    return json.loads(p.stdout.readline())

def request(port,method,path='/',body=None,headers=None):
    c=http.client.HTTPConnection('127.0.0.1',port,timeout=10)
    c.request(method,path,body,headers or {})
    r=c.getresponse(); data=r.read().decode(); status=r.status; c.close()
    return status,data

with tempfile.TemporaryDirectory(prefix='selftest-',dir=ROOT/'artifacts') as tmp:
    db=pathlib.Path(tmp)/'rooms.db'
    check(cli('init',db)['revision']==1)
    cli('init',db,error=17)
    cli('list',str(db)+'.missing',error=404)
    cli('reserve',db,1,1,error=22)
    a=reserve(db,1,1)
    check(a['bookings']==[{'id':'1','room':1,'day':datetime.date(2024,2,29).toordinal(),'start':540,'finish':600}])
    reserve(db,1,2,error=409)
    reserve(db,2,1,error=17)
    reserve(db,2,2,start='09:59',end='11:00',error=409)
    reserve(db,2,2,start='10:00',end='11:00')
    reserve(db,3,3,room=2)
    reserve(db,4,4,date='2024-03-01')
    reserve(db,5,'18446744073709551615',room=16,date='9999-12-31',start='23:59',end='24:00')
    reserve(db,6,6,room=16,date='0001-01-01',start='00:00',end='00:01')
    for kwargs in [dict(id='0'),dict(id='01'),dict(id='18446744073709551616'),dict(id='+7'),dict(id='7',room=0),dict(id='7',room=17),dict(id='7',date='1900-02-29'),dict(id='7',date='0000-01-01'),dict(id='7',date='2024-2-29'),dict(id='7',start='9:00'),dict(id='7',start='24:00'),dict(id='7',end='24:01'),dict(id='7',end='09:00'),dict(id='7',end='08:00')]:
        reserve(db,7,error=22,**kwargs)
    before=state(db)
    cli('cancel',db,6,1,error=409)
    cli('cancel',db,7,99,error=404)
    cli('cancel',db,7,0,error=22)
    check(state(db)==before)
    after=cli('cancel',db,7,2)
    check([r['id'] for r in after['bookings']]==['1','3','4','18446744073709551615','6'])
    check(state(db)==after,'durability')
    # Two fresh processes racing on one revision: exactly one commits.
    jobs=[subprocess.Popen([APP,'reserve',str(db),'8',str(i),'3','2024-04-01','09:00','10:00'],stdout=subprocess.PIPE,text=True) for i in (20,21)]
    replies=[(p.communicate(timeout=15)[0],p.returncode) for p in jobs]
    check(sum(code==0 for _,code in replies)==1,replies)
    check(state(db)['revision']==9)
    with db.open('rb') as locked:
        fcntl.flock(locked,fcntl.LOCK_EX|fcntl.LOCK_NB)
        cli('list',db,error=35)
        reserve(db,9,22,room=5,error=35)
        fcntl.flock(locked,fcntl.LOCK_UN)
    check(state(db)['revision']==9)
    link=pathlib.Path(tmp)/'linked.db'; link.symlink_to(db)
    link_result=subprocess.run([APP,'list',str(link)],capture_output=True,text=True)
    check(link_result.returncode==2 and 'error' in json.loads(link_result.stdout))
    # Corruption must stay a failure, never a blank or successful state.
    broken=pathlib.Path(tmp)/'broken.db'; broken.write_bytes(b'not a journal')
    cli('list',broken,error=9001)
    if '--skip-http' not in sys.argv:
        # Browser real local HTTP, token and stale-form behavior.
        server=subprocess.Popen([APP,'serve',str(db)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            sel=selectors.DefaultSelector(); sel.register(server.stdout,selectors.EVENT_READ)
            check(bool(sel.select(5)),'serve URL timeout'); sel.close()
            url=server.stdout.readline().strip(); check(bool(re.fullmatch(r'http://127\.0\.0\.1:\d+/',url)),url)
            port=urllib.parse.urlparse(url).port
            status,page=request(port,'GET'); check(status==200)
            check(all(f'name={name}' in page or f'name="{name}"' in page for name in ['room','date','start','end','rev','token','id']))
            token=re.search(r'name=token value="([a-f0-9]{32})"',page).group(1)
            fields=dict(action='reserve',rev='9',id='30',room='4',date='2024-05-01',start='09:00',end='10:00',token=token)
            headers={'Origin':url.rstrip('/'),'Content-Type':'application/x-www-form-urlencoded'}
            def post(data,head=None): return request(port,'POST','/action',data if isinstance(data,str) else urllib.parse.urlencode(data),head or headers)
            status,page=post(fields); check(status==200 and 'Saved to your workspace.' in page)
            check(state(db)['revision']==10)
            status,page=post(fields); check('could not be saved' in page and 'value="10"' in page)
            check('value="2024-05-01"' in page and 'value="09:00"' in page,'failed inputs retained')
            for payload,head in [(dict(fields,rev='10',id='31',token='bad'),None),(dict(fields,rev='10',id='31'),dict(headers,Origin='http://evil.invalid')),(urllib.parse.urlencode(dict(fields,rev='10',id='31'))+'&room=5',None),(urllib.parse.urlencode(dict(fields,rev='10',id='31'))+'&extra=x',None),(dict(fields,rev='10',id='31',end='08:00'),None)]:
                post(payload,head); check(state(db)['revision']==10,'bad POST mutated')
            status,_=request(port,'GET',headers={'Host':'evil.invalid'}); check(status==400)
            status,_=request(port,'GET','/missing'); check(status==404)
            status,page=post(dict(action='cancel',rev='10',id='30',token=token)); check('Saved to your workspace.' in page)
            check(state(db)['revision']==11)
            (ROOT/'artifacts'/'sample.html').write_text(page)
        finally:
            server.terminate(); server.communicate(timeout=5)
    else:
        print('SKIP: real HTTP checks requested skipped (sandbox refuses socket creation).')
    # MCP requests and malformed inputs share a live connection.
    p=subprocess.Popen([APP,'mcp',str(db)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    try:
        init=rpc(p,dict(jsonrpc='2.0',id=1,method='initialize',params={'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'selftest','version':'1'}}))
        check(init['result']['protocolVersion']=='2025-11-25')
        p.stdin.write('{"jsonrpc":"2.0","method":"notifications/initialized"}\n'); p.stdin.flush()
        tools=rpc(p,dict(jsonrpc='2.0',id=2,method='tools/list'))['result']['tools']
        check([t['name'] for t in tools]==['booking_list'])
        check(tools[0]['inputSchema']=={'type':'object','properties':{},'additionalProperties':False})
        msg=dict(jsonrpc='2.0',id=3,method='tools/call',params={'name':'booking_list','arguments':{}})
        check(rpc(p,msg)['result']['structuredContent']==state(db))
        for bad in ['{', '{"jsonrpc":"2.0","id":4,"method":"ping","metho\\u0064":"ping"}',dict(jsonrpc='2.0',id=5,method='unknown'),dict(jsonrpc='2.0',id=6,method='tools/call',params={'name':'booking_list','arguments':{'path':'other'}}),dict(jsonrpc='2.0',id=7,method='tools/call',params={'name':'booking_list'})]:
            check('error' in rpc(p,bad))
        notification=dict(msg); notification.pop('id')
        p.stdin.write(json.dumps(notification)+'\n');p.stdin.flush()
        check(rpc(p,dict(jsonrpc='2.0',id=8,method='ping'))['result']=={})
        check('error' in rpc(p,'x'*65537))
        check(rpc(p,dict(jsonrpc='2.0',id=10,method='ping'))['result']=={})
        # Callback error is reported as a tool error, connection stays usable.
        db.rename(str(db)+'.moved')
        check(rpc(p,msg)['result']['isError'] is True)
        check(rpc(p,dict(jsonrpc='2.0',id=9,method='ping'))['result']=={})
    finally:
        p.stdin.close();p.wait(timeout=5)
    # Capacity and a full snapshot roundtrip.
    cap=pathlib.Path(tmp)/'capacity.db'; cli('init',cap)
    for i in range(1,257): reserve(cap,i,i,date='2000-01-01',start=f'{(i-1)//60:02}:{(i-1)%60:02}',end=f'{i//60:02}:{i%60:02}')
    check(len(state(cap)['bookings'])==256)
    reserve(cap,257,257,start='20:00',end='21:00',error=22)
print(f'PASS: {checks} assertions; native CLI, stdio MCP, persistence, concurrency, capacity. HTTP run: {"--skip-http" not in sys.argv}.')
