# Study Rooms

A local Python application with a CLI, browser interface and read-only MCP server. Uses Python 3.9+ and the standard library; no installation or dependencies are needed. Run all commands from this directory. `launch.json` is the executable contract `["python3","app.py"]`.

## Build and run

Python runs the source directly. An optional syntax build, keeping bytecode inside this directory:

```sh
python3 -B -c 'import py_compile; py_compile.compile("app.py", cfile="app.pyc", doraise=True)'
```

Working CLI example (choose a path that does not already exist):

```sh
python3 app.py init rooms.sqlite
python3 app.py reserve rooms.sqlite 1 1 3 2026-11-16 09:00 10:00
python3 app.py list rooms.sqlite
python3 app.py cancel rooms.sqlite 2 1
python3 app.py serve rooms.sqlite
```

The reserve command returns:

```json
{"revision":2,"bookings":[{"id":"1","room":3,"day":739936,"start":540,"finish":600}]}
```

`serve` prints its exact `http://127.0.0.1:PORT/` address as its first line, using a dynamically allocated port. Open that address in a browser; keep the process running. Ctrl-C stops it. Reserve and cancel forms carry the current revision. A stale or overlapping submission shows the current saved schedule and preserves entered reserve values. Refresh after another client edits the workspace. A server restart creates a new CSRF token; refresh old tabs.

CLI commands:

```text
init DB
list DB
reserve DB REV ID ROOM DATE START END
cancel DB REV ID
serve DB
mcp DB
```

IDs are canonical positive decimal strings through 18446744073709551615. Rooms are 1–16. Dates use exactly YYYY-MM-DD, from 0001-01-01 through 9999-12-31. Times use exactly HH:MM, with 24:00 permitted only as an end. Intervals are half-open, so adjacent bookings are valid. No overnight sessions, recurring bookings or timezone conversion. Maximum 256 current bookings. Cancellation preserves the order of remaining rows.

CLI successes emit only JSON state. Failures emit `{"error":CODE}` and exit 2. Common codes: invalid input/capacity 22, existing ID/path 17, missing file/reservation 404, stale revision/overlap 409, busy 35. Other storage failures remain failures, including corrupt 9001 and uncertain 9002. After an uncertain outcome, read saved state before attempting another write. No automatic mutation retries occur.

## MCP

Start `python3 app.py mcp rooms.sqlite`. Send one JSON-RPC object per newline; there is no stdout banner. Example input sequence:

```jsonl
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{},"clientInfo":{"name":"local-client","version":"1"}}}
{"jsonrpc":"2.0","method":"notifications/initialized"}
{"jsonrpc":"2.0","id":2,"method":"tools/list"}
{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"booking_list","arguments":{}}}
```

Exactly one tool, `booking_list`, returns the selected workspace's state in `structuredContent` plus a short text description. An explicit empty arguments object is required. There are no write, path-selection, execution, network or migration tools. Duplicate decoded JSON keys, malformed JSON, oversized lines (over 65536 bytes excluding newline), unknown tools and arguments are rejected. Later valid requests remain usable. Storage failures return `isError:true`.

## Storage and local security limits

`booking_sdk.py` is the supplied, unchanged domain/storage SDK. Every frontend uses its `execute` transactions, revision checks and SQLite locking. `app.py` normalizes its missing-file code 2 to 404 and capacity code 27 to 22. The optional supplied `mcp_sdk.py` remains unchanged; the application implements its own bounded protocol frontend for strict parameter checks.

The database is SQLite, not the native RF2 journal. The SDK uses full synchronous commits and rollback journaling; SQLite may create a journal beside the database, so its parent directory must be writable. Use local storage with working SQLite locks. Copy or back up databases while clients are stopped, or use SQLite-aware backup tooling. Native RF2 storage interoperability, network-filesystem durability and hostile same-user path isolation are not claimed. No migration or database-repair tool is provided.

The browser server listens only on IPv4 loopback and serves only its selected existing workspace. It checks exact Host and POST Origin, an unpredictable process-local token, exact form fields and bounded URL-encoded input. It escapes user text and loads no remote assets. This is a local single-user utility, with no public server or authentication claim. The HTTP server is single-threaded and intended for small local workloads. OS filesystem permissions remain the local access boundary.

## Verification and known limits

Run:

```sh
python3 -B -m unittest -v test_app
```

The included tests exercise fresh-process persistence, insertion order, cancellation, overlap and adjacency, date/time/u64 boundaries, capacity, competing writes, busy/corrupt storage, HTTP request parsing and forms, CSRF/Host/Origin/duplicate-field rejection, stale-input retention and escaping, and actual subprocess MCP framing, recovery and read-only behavior.

During this attempt, eight tests ran: seven passed and the live loopback test was skipped because the execution sandbox denies `socket.bind(('127.0.0.1', 0))` with `PermissionError: [Errno 1] Operation not permitted`. HTTP parsing and handler tests passed using in-memory streams connected to the real `BaseHTTPRequestHandler`, real application code and real SQLite state. A live listener and visual browser rendering could not be verified here. The live integration test remains available and will run when loopback binding is permitted.

The initial compile command failed because this environment redirected bytecode to a non-writable cache outside the directory. A rerun with a local cache succeeded; the build command above explicitly chooses its output file. These failures and the final test output are preserved in `VERIFICATION.md` and `test-results.txt`. No external acceptance suite, human trials or performance claims are included.
