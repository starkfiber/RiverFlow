#!/usr/bin/env python3
"""Local Study Rooms application. Python standard library only."""
import datetime as dt
import html
import json
import re
import secrets
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qsl

from booking_sdk import BookingError, execute


def store(path, action, **kwargs):
    try:
        return execute(path, action, **kwargs)
    except BookingError as exc:
        # Normalize the SDK's missing-file and capacity domain outcomes.
        raise BookingError({2: 404, 27: 22}.get(exc.code, exc.code)) from exc


def number(value, low, high):
    if not isinstance(value, str) or not re.fullmatch(r'[0-9]+', value) or len(value) > 20:
        raise BookingError(22)
    n = int(value)
    if not low <= n <= high:
        raise BookingError(22)
    return n


def date(value):
    if not re.fullmatch(r'[0-9]{4}-[0-9]{2}-[0-9]{2}', value):
        raise BookingError(22)
    try:
        return dt.date.fromisoformat(value).toordinal()
    except ValueError:
        raise BookingError(22)


def minute(value, end=False):
    if end and value == '24:00':
        return 1440
    if not re.fullmatch(r'[0-9]{2}:[0-9]{2}', value):
        raise BookingError(22)
    h, m = map(int, value.split(':'))
    if h > 23 or m > 59:
        raise BookingError(22)
    return h * 60 + m


def mutate(path, fields):
    args = dict(expected=number(fields['rev'], 1, 2**32-1), id=fields['id'])
    if fields['action'] == 'reserve':
        args.update(room=number(fields['room'], 1, 16), day=date(fields['date']),
                    start=minute(fields['start']), finish=minute(fields['end'], True))
    return store(path, fields['action'], **args)


def clock(n):
    return f'{n // 60:02d}:{n % 60:02d}'


def calendar(n):
    d = dt.date.fromordinal(n)
    return f'{d.year:04d}-{d.month:02d}-{d.day:02d}'


MESSAGES = {
    22: 'Invalid input. Use a positive decimal ID, room 1–16, YYYY-MM-DD and HH:MM; end must follow start. Capacity is 256 reservations.',
    17: 'That reservation ID already exists. Choose a different ID.',
    404: 'The workspace or reservation was not found. Refresh and check the ID.',
    409: 'The form is stale or the room overlaps another reservation. Current bookings are shown below; review them and try again.',
    35: 'The workspace is busy. Wait briefly, refresh and try again.',
}

CSS = '''
:root{color-scheme:light dark;--bg:#f3f5f9;--panel:#fff;--ink:#18253b;--muted:#52617a;--line:#cbd3e0;--accent:#264dc0;--soft:#e9efff}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.5 system-ui,sans-serif}main{max-width:1120px;margin:auto;padding:36px 24px}header{margin-bottom:28px}h1{font-size:clamp(2rem,5vw,3rem);margin:0}h2{margin-top:0;font-size:1.3rem}p{color:var(--muted)}.eyebrow{font-size:.8rem;text-transform:uppercase;letter-spacing:.12em;color:var(--accent);font-weight:700}.layout{display:grid;grid-template-columns:330px 1fr;gap:24px;align-items:start}.card{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:24px}label{display:block;font-size:.9rem;font-weight:650;margin:16px 0 5px}input,select,button{font:inherit}input,select{width:100%;padding:10px;border:1px solid var(--line);border-radius:7px;background:var(--bg);color:var(--ink)}button{border:0;border-radius:7px;background:var(--accent);color:white;padding:11px 16px;cursor:pointer;font-weight:650}button.primary{margin-top:22px;width:100%}button.cancel{background:var(--soft);color:var(--accent);font-size:.85rem;padding:8px 10px}a{color:var(--accent)}:focus-visible{outline:3px solid #e69b22;outline-offset:3px}.notice{border:2px solid var(--accent);background:var(--soft);padding:16px;border-radius:10px;margin-bottom:24px}.notice.error{border-color:#b44b31}.table-wrap{overflow-x:auto}table{width:100%;border-collapse:collapse;text-align:left;font-size:.9rem}th,td{padding:12px 8px;border-bottom:1px solid var(--line);white-space:nowrap}th{color:var(--muted);font-weight:600}.meta,.hint{font-size:.85rem;color:var(--muted)}.split{display:grid;grid-template-columns:1fr 1fr;gap:12px}.empty{padding:28px 0}.toolbar{display:flex;justify-content:space-between;gap:12px;align-items:baseline}footer{margin-top:24px;font-size:.85rem;color:var(--muted)}@media(prefers-color-scheme:dark){:root{--bg:#111827;--panel:#1b2638;--ink:#ecf0fa;--muted:#b0bed4;--line:#45516a;--accent:#9db9ff;--soft:#283b5c}button.primary{background:#8baafa;color:#10203e}}@media(max-width:800px){.layout{grid-template-columns:1fr}main{padding:24px 16px}.card{padding:18px}}
'''


def page(state, token, message='', failed=None, error=False):
    esc = lambda v: html.escape(str(v), quote=True)
    values = {'id': '', 'room': '1', 'date': calendar(dt.date.today().toordinal()), 'start': '09:00', 'end': '10:00'}
    if failed:
        values.update({k: failed[k] for k in values if k in failed})
    hidden = f'<input type="hidden" name="rev" value="{state["revision"]}"><input type="hidden" name="token" value="{esc(token)}">'
    def field(key, label, kind='text', extra=''):
        return f'<label for="{key}">{label}</label><input id="{key}" name="{key}" type="{kind}" value="{esc(values[key])}" required {extra}>'
    options = ''.join(f'<option value="{i}"'+(' selected' if values['room'] == str(i) else '')+f'>Room {i}</option>' for i in range(1,17))
    if values['room'] not in {str(i) for i in range(1, 17)}:
        options = f'<option value="{esc(values["room"])}" selected>Entered: {esc(values["room"])}</option>' + options
    rows = ''
    for b in state['bookings']:
        rows += f'''<tr><td>{esc(b['id'])}</td><td>Room {b['room']}</td><td>{calendar(b['day'])}</td><td>{clock(b['start'])}–{clock(b['finish'])}</td><td><form method="post" action="/action">{hidden}<input type="hidden" name="action" value="cancel"><input type="hidden" name="id" value="{esc(b['id'])}"><button class="cancel" type="submit" aria-label="Cancel reservation {esc(b['id'])}">Cancel</button></form></td></tr>'''
    notice = f'<div class="notice{" error" if error else ""}" role="{"alert" if error else "status"}">{esc(message)}</div>' if message else ''
    bookings = f'<div class="table-wrap"><table><thead><tr><th>ID</th><th>Room</th><th>Date</th><th>Time</th><th>Action</th></tr></thead><tbody>{rows}</tbody></table></div>' if rows else '<p class="empty">No reservations yet. Choose a room and time to book your first study session.</p>'
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Study Rooms</title><style>{CSS}</style></head><body><main><header><div class="eyebrow">Your space to focus</div><h1>Study Rooms</h1><p>Reserve one of 16 rooms. Clear schedules, more time to study.</p></header>{notice}<div class="layout"><section class="card"><h2>Reserve a room</h2><p class="hint">Same-day bookings. Adjacent sessions are welcome.</p><form method="post" action="/action">{hidden}<input type="hidden" name="action" value="reserve">{field('id','Reservation ID','text','inputmode="numeric" pattern="[1-9][0-9]*" maxlength="20"')}<label for="room">Room</label><select id="room" name="room">{options}</select>{field('date','Date','text','placeholder="YYYY-MM-DD" pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}"')}<div class="split"><div>{field('start','Start','text','placeholder="HH:MM"')}</div><div>{field('end','End','text','placeholder="HH:MM"')}</div></div><p class="hint">24-hour times, e.g. 09:00. End may be 24:00. Use a unique positive numeric ID.</p><button class="primary" type="submit">Reserve room</button></form></section><section class="card"><div class="toolbar"><h2>Saved reservations</h2><a href="/">Refresh</a></div><p class="meta">Revision {state['revision']} · {len(state['bookings'])} / 256 reservations</p>{bookings}</section></div><footer>Local workspace · Dates and times are used as entered, without timezone conversion.</footer></main></body></html>'''


class RequestError(Exception):
    pass


def web_handler(path, token):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def send(self, status, body, content_type='text/html; charset=utf-8'):
            encoded = body.encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(encoded)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'")
            self.end_headers()
            self.wfile.write(encoded)

        def endpoint_valid(self):
            return self.headers.get_all('Host', []) == [self.server.endpoint]

        def render(self, status=200, message='', failed=None, error=False):
            try:
                state = store(path, 'list')
                self.send(status, page(state, token, message, failed, error))
            except BookingError as exc:
                self.send(503, '<h1>Workspace unavailable</h1><p>'+html.escape(MESSAGES.get(exc.code, f'Storage error {exc.code}. Reopen the workspace and inspect its state before retrying.'))+'</p>')

        def do_GET(self):
            if not self.endpoint_valid():
                self.send(403, '<h1>Invalid Host</h1>'); return
            if self.path != '/':
                self.send(404, '<h1>Not found</h1>'); return
            self.render()

        def do_POST(self):
            self.close_connection = True
            fields = None
            try:
                if not self.endpoint_valid() or self.headers.get_all('Origin', []) != ['http://' + self.server.endpoint]:
                    raise RequestError('Invalid Host or Origin. Open the printed loopback URL and retry.')
                if self.path != '/action':
                    self.send(404, '<h1>Not found</h1>'); return
                if self.headers.get_all('Transfer-Encoding') or self.headers.get_all('Content-Type', []) != ['application/x-www-form-urlencoded']:
                    raise RequestError('Expected a URL-encoded form.')
                lengths = self.headers.get_all('Content-Length', [])
                if len(lengths) != 1 or not re.fullmatch(r'[0-9]{1,5}', lengths[0]) or int(lengths[0]) > 8192:
                    raise RequestError('Invalid form length.')
                raw = self.rfile.read(int(lengths[0]))
                if len(raw) != int(lengths[0]):
                    raise RequestError('Incomplete form.')
                encoded = raw.decode('utf-8', errors='strict')
                if re.search(r'%(?![0-9A-Fa-f]{2})', encoded):
                    raise RequestError('Malformed form encoding.')
                pairs = parse_qsl(encoded, keep_blank_values=True, strict_parsing=True, encoding='utf-8', errors='strict', max_num_fields=10)
                fields = dict(pairs)
                if len(fields) != len(pairs):
                    raise RequestError('Duplicate form fields.')
                action = fields.get('action')
                required = {'action', 'rev', 'id', 'token'}
                if action == 'reserve':
                    required |= {'room', 'date', 'start', 'end'}
                elif action != 'cancel':
                    raise RequestError('Unknown action.')
                if set(fields) != required:
                    raise RequestError('Unexpected or missing form fields.')
                if not secrets.compare_digest(fields['token'].encode(), token.encode()):
                    raise RequestError('Invalid form token. Refresh this page and retry.')
                mutate(path, fields)
            except (RequestError, ValueError, UnicodeError) as exc:
                self.render(400, str(exc) if isinstance(exc, RequestError) else 'Malformed form. Refresh and retry.', fields if fields and fields.get('action') == 'reserve' else None, True)
            except BookingError as exc:
                self.render(409 if exc.code in (409,17) else 400, MESSAGES.get(exc.code, f'Storage error {exc.code}. Refresh and inspect saved state before retrying.'), fields if fields and fields.get('action') == 'reserve' else None, True)
            else:
                self.render(200, 'Reservation saved.' if fields['action'] == 'reserve' else 'Reservation cancelled.')

    return Handler


def serve_web(path, server_class=HTTPServer):
    store(path, 'list')
    token = secrets.token_hex(16)
    server = server_class(('127.0.0.1', 0), web_handler(path, token))
    server.endpoint = f'127.0.0.1:{server.server_address[1]}'
    print('http://' + server.endpoint + '/', flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()


def mcp(path):
    # Keep all tool access bound to the path selected on startup.
    def pairs(items):
        obj = {}
        for key, value in items:
            if key in obj:
                raise ValueError('Duplicate key')
            obj[key] = value
        return obj

    def invalid_constant(value):
        raise ValueError('Invalid JSON constant')

    def reply(id, result=None, code=None, message=None):
        out = dict(jsonrpc='2.0', id=id)
        out['error' if code else 'result'] = dict(code=code, message=message) if code else result
        print(json.dumps(out, ensure_ascii=True, separators=(',', ':')), flush=True)

    initialized = ready = False
    while True:
        raw = sys.stdin.buffer.readline(65538)
        if not raw:
            return
        if len(raw) > 65537 or not raw.endswith(b'\n'):
            while raw and not raw.endswith(b'\n'):
                raw = sys.stdin.buffer.readline(65538)
            reply(None, code=-32700, message='Request framing or size limit'); continue
        try:
            req = json.loads(raw.decode('utf-8'), object_pairs_hook=pairs, parse_constant=invalid_constant)
        except (ValueError, UnicodeError, RecursionError):
            reply(None, code=-32700, message='Invalid JSON'); continue
        if type(req) is not dict:
            reply(None, code=-32600, message='Expected request object'); continue
        id = req.get('id')
        has_id = 'id' in req
        if has_id and not (type(id) is int and len(str(id)) <= 21 or type(id) is str and len(id.encode('utf-8', errors='surrogatepass')) <= 256):
            reply(None, code=-32600, message='Invalid request ID'); continue
        if req.get('jsonrpc') != '2.0' or type(req.get('method')) is not str or set(req) - {'jsonrpc','id','method','params'}:
            reply(id, code=-32600, message='Invalid envelope'); continue
        method = req['method']
        params = req.get('params', {})
        if not has_id:
            if method == 'notifications/initialized' and initialized and params == {}:
                ready = True
            continue
        if type(params) is not dict:
            reply(id, code=-32602, message='Expected object params'); continue
        if method == 'initialize':
            if initialized:
                reply(id, code=-32600, message='Already initialized'); continue
            if set(params) != {'protocolVersion','capabilities','clientInfo'} or params['protocolVersion'] != '2025-11-25' or type(params['capabilities']) is not dict or type(params['clientInfo']) is not dict:
                reply(id, code=-32602, message='Expected legacy initialize params'); continue
            initialized = True
            reply(id, dict(protocolVersion='2025-11-25', capabilities=dict(tools={}), serverInfo=dict(name='study-rooms',version='1.0')))
        elif method == 'ping':
            if params:
                reply(id, code=-32602, message='Expected empty params')
            else:
                reply(id, {})
        elif not ready:
            reply(id, code=-32600, message='Initialize session first')
        elif method == 'tools/list':
            if params:
                reply(id, code=-32602, message='Expected empty params'); continue
            reply(id, dict(tools=[dict(name='booking_list', description='Read saved reservations in the selected workspace.', inputSchema=dict(type='object',properties={},additionalProperties=False), annotations=dict(readOnlyHint=True,destructiveHint=False,idempotentHint=True,openWorldHint=False))]))
        elif method == 'tools/call':
            if set(params) != {'name','arguments'} or params['name'] != 'booking_list' or type(params['arguments']) is not dict or params['arguments']:
                reply(id, code=-32602, message='Unknown tool or arguments'); continue
            try:
                state = store(path, 'list')
            except BookingError as exc:
                reply(id, dict(isError=True,content=[dict(type='text',text=f'Workspace read failed ({exc.code}).')]))
            else:
                reply(id, dict(isError=False, structuredContent=state,content=[dict(type='text',text=f'Revision {state["revision"]}: {len(state["bookings"])} reservations.')]))
        else:
            reply(id, code=-32601, message='Unknown method')


def main(argv):
    try:
        if len(argv) < 2:
            raise BookingError(22)
        action, path = argv[:2]
        if action in ('init', 'list') and len(argv) == 2:
            result = store(path, action)
        elif action == 'reserve' and len(argv) == 8:
            result = mutate(path, dict(zip(('action','rev','id','room','date','start','end'), [action]+argv[2:])))
        elif action == 'cancel' and len(argv) == 4:
            result = mutate(path, dict(action=action, rev=argv[2], id=argv[3]))
        elif action == 'serve' and len(argv) == 2:
            serve_web(path); return 0
        elif action == 'mcp' and len(argv) == 2:
            mcp(path); return 0
        else:
            raise BookingError(22)
        print(json.dumps(result, separators=(',', ':')))
        return 0
    except BookingError as exc:
        print(json.dumps(dict(error=exc.code), separators=(',', ':')))
        return 2
    except (OSError, ValueError, OverflowError):
        print('{"error":5}')
        return 2


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv[1:]))
    except KeyboardInterrupt:
        sys.exit(0)
