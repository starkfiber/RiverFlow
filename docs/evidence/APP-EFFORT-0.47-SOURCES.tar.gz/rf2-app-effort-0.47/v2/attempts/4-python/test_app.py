"""Local integration tests: real subprocesses, SQLite and loopback HTTP."""
import datetime
import http.client
import io
import socket
import json
import os
from pathlib import Path
import re
import select
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from urllib.parse import urlencode, urlsplit

ROOT = Path(__file__).resolve().parent
ENTRY = [sys.executable, '-B', str(ROOT / 'app.py')]


class AppTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=ROOT)
        self.db = str(Path(self.tmp.name) / 'rooms.db')
        self.processes = []

    def tearDown(self):
        for p in self.processes:
            if p.poll() is None:
                p.terminate()
            p.wait(timeout=5)
            for stream in (p.stdin,p.stdout,p.stderr):
                if stream:
                    stream.close()
        self.tmp.cleanup()

    def cli(self, *args, code=0):
        p = subprocess.run(ENTRY + [str(x) for x in args], capture_output=True, text=True, timeout=5)
        self.assertEqual(p.returncode, code, p.stdout + p.stderr)
        self.assertEqual(p.stderr, '')
        return json.loads(p.stdout)

    def init(self):
        self.assertEqual(self.cli('init', self.db), dict(revision=1,bookings=[]))

    def reserve(self, rev=1, id='1', room=1, day='2026-11-16', start='09:00', end='10:00', code=0):
        return self.cli('reserve',self.db,rev,id,room,day,start,end,code=code)

    def test_durability_order_conflicts_and_cancel(self):
        self.init()
        self.assertEqual(self.cli('init',self.db,code=2), {'error':17})
        state = self.reserve()
        self.assertEqual(state, {'revision':2,'bookings':[{'id':'1','room':1,'day':datetime.date(2026,11,16).toordinal(),'start':540,'finish':600}]})
        self.assertEqual(self.cli('list', self.db),state)
        self.assertEqual(self.reserve(1,'2',code=2),{'error':409})
        self.assertEqual(self.reserve(2,'2',start='09:59',end='11:00',code=2),{'error':409})
        self.reserve(2,'2',start='10:00',end='11:00')
        self.reserve(3,'3',room=2)
        self.reserve(4,'4',day='2026-11-17')
        self.assertEqual(self.reserve(5,code=2), {'error':17})
        self.assertEqual(self.cli('cancel',self.db,5,'99',code=2),{'error':404})
        state = self.cli('cancel',self.db,5,'2')
        self.assertEqual(state['revision'],6)
        self.assertEqual([b['id'] for b in state['bookings']],['1','3','4'])
        self.assertEqual(self.cli('list',self.db),state)

    def test_validation_and_boundaries(self):
        self.init()
        for args in [dict(id='0'),dict(id='01'),dict(id='18446744073709551616'),dict(id='١'),dict(id='-1'),dict(room=0),dict(room=17),dict(day='2026-2-01'),dict(day='1900-02-29'),dict(day='0000-01-01'),dict(start='9:00'),dict(start='24:00'),dict(end='24:01'),dict(end='09:00'),dict(start='09:60'),dict(rev='1.0')]:
            with self.subTest(args=args):
                self.assertEqual(self.reserve(**args,code=2),{'error':22})
        self.reserve(id='18446744073709551615',day='0001-01-01',start='00:00',end='24:00')
        self.reserve(2,'2',day='9999-12-31',start='23:59',end='24:00')
        self.reserve(3,'3',day='2000-02-29')
        self.assertEqual(self.cli('list',self.db)['revision'],4)
        self.assertEqual(self.cli('list',self.db+'.missing',code=2),{'error':404})
        self.assertFalse(os.path.exists(self.db+'.missing'))

    def test_capacity(self):
        # Use the same domain/storage entry point for a fast full-capacity fixture.
        from app import store
        self.init()
        for n in range(1,257):
            store(self.db,'reserve',expected=n,id=str(n),room=1,day=n,start=0,finish=1)
        self.assertEqual(self.reserve(257,'257',code=2),{'error':22})
        self.assertEqual(len(self.cli('list',self.db)['bookings']),256)

    def test_lock_and_corrupt(self):
        self.init()
        c = sqlite3.connect(self.db)
        c.execute('BEGIN IMMEDIATE')
        try:
            self.assertEqual(self.reserve(code=2),{'error':35})
        finally:
            c.rollback(); c.close()
        Path(self.db).write_bytes(b'not sqlite')
        self.assertEqual(self.cli('list',self.db,code=2),{'error':9001})

    def test_competing_writes(self):
        self.init()
        ps = [subprocess.Popen(ENTRY+['reserve',self.db,'1',str(n),'1','2026-11-16','09:00','10:00'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True) for n in (1,2)]
        results = [p.communicate(timeout=5) for p in ps]
        self.assertEqual(sum(p.returncode == 0 for p in ps),1)
        loser = [json.loads(out) for p,(out,err) in zip(ps,results) if p.returncode != 0][0]
        self.assertIn(loser['error'],(35,409))
        self.assertEqual(self.cli('list',self.db)['revision'],2)

    def start(self, mode):
        p = subprocess.Popen(ENTRY+[mode,self.db],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        self.processes.append(p)
        return p

    def test_browser(self):
        self.init()
        probe = socket.socket()
        try:
            probe.bind(('127.0.0.1', 0))
        except PermissionError as exc:
            self.skipTest(f'Environment blocks loopback bind: {exc}')
        finally:
            probe.close()
        p = self.start('serve')
        self.assertTrue(select.select([p.stdout],[],[],5)[0], 'server URL timed out')
        url = p.stdout.readline().decode().strip()
        self.assertRegex(url, r'^http://127\.0\.0\.1:[0-9]+/$')
        target = urlsplit(url)
        def request(method='GET', path='/', body=None, headers=None):
            c = http.client.HTTPConnection(target.hostname,target.port, timeout=5)
            c.request(method,path,body=body,headers=headers or {})
            response = c.getresponse()
            result = response.status, response.read().decode()
            c.close()
            return result
        status, body = request()
        self.assertEqual(status,200)
        for label in ('Reservation ID','Room','Date','Start','End'):
            self.assertIn(label,body)
        token = re.search(r'name="token" value="([a-f0-9]+)"',body)[1]
        fields = dict(action='reserve',rev='1',id='1',room='1',date='2026-11-16',start='09:00',end='10:00',token=token)
        headers = {'Content-Type':'application/x-www-form-urlencoded','Origin':url[:-1]}
        def post(f, h=None):
            return request('POST','/action',urlencode(f),headers if h is None else h)
        self.assertEqual(request(headers={'Host':'evil.example'})[0],403)
        self.assertEqual(post(fields, {'Content-Type':headers['Content-Type'],'Origin':'http://evil.example'})[0],400)
        self.assertEqual(post(dict(fields,token='bad'))[0],400)
        self.assertEqual(post(list(fields.items())+[('id','2')])[0],400)
        self.assertEqual(post(dict(fields,unknown='x'))[0],400)
        self.assertEqual(self.cli('list',self.db)['revision'],1)
        status, body = post(fields)
        self.assertEqual(status,200)
        self.assertIn('Reservation saved.',body)
        status, body = post(dict(fields,id='2',start='11:00',end='12:00'))
        self.assertEqual(status,409)
        self.assertIn('name="rev" value="2"',body)
        self.assertIn('value="11:00"',body)
        # Stored labels are readable strings, and failed input is escaped.
        self.assertIn('2026-11-16',body)
        status, body = post(dict(fields,rev='2',id='<script>alert(1)</script>'))
        self.assertEqual(status,400)
        self.assertNotIn('<script>',body)
        self.assertIn('&lt;script&gt;',body)
        status, body = post(dict(action='cancel',rev='2',id='1',token=token))
        self.assertEqual(status,200)
        self.assertIn('Reservation cancelled.',body)
        self.assertEqual(self.cli('list',self.db),{'revision':3,'bookings':[]})

    def test_http_handler_without_network(self):
        # Real HTTP parser/handler with in-memory streams; no socket bind needed.
        from app import web_handler
        from types import SimpleNamespace
        self.init()
        token = 'a' * 32
        handler = web_handler(self.db, token)
        server = SimpleNamespace(endpoint='127.0.0.1:12345')

        class Connection:
            def __init__(self, raw):
                self.input = io.BytesIO(raw)
                self.output = io.BytesIO()
            def makefile(self, *args):
                return self.input
            def sendall(self, data):
                self.output.write(data)

        def request(method='GET', body='', extra='', host=server.endpoint, path='/'):
            raw = f'{method} {path} HTTP/1.0\r\nHost: {host}\r\n{extra}Content-Length: {len(body.encode())}\r\n\r\n{body}'.encode()
            connection = Connection(raw)
            handler(connection, ('127.0.0.1', 10000), server)
            head, content = connection.output.getvalue().decode().split('\r\n\r\n', 1)
            return int(head.split()[1]), content

        headers = 'Origin: http://127.0.0.1:12345\r\nContent-Type: application/x-www-form-urlencoded\r\n'
        fields = dict(action='reserve',rev='1',id='1',room='1',date='2026-11-16',start='09:00',end='10:00',token=token)
        def post(f, extra=headers):
            return request('POST', urlencode(f),extra,path='/action')
        status, body = request()
        self.assertEqual(status,200)
        self.assertIn('name="token" value="'+token+'"',body)
        self.assertIn('for="date"',body)
        self.assertEqual(request(host='evil.example')[0],403)
        self.assertEqual(request(path='/other')[0],404)
        self.assertEqual(post(fields,headers.replace('http://127.0.0.1:12345','http://evil.example'))[0],400)
        self.assertEqual(post(dict(fields,token='bad'))[0],400)
        self.assertEqual(post(list(fields.items())+[('id','2')])[0],400)
        self.assertEqual(post(dict(fields,unknown='x'))[0],400)
        self.assertEqual(post(fields,headers+'Origin: http://127.0.0.1:12345\r\n')[0],400)
        self.assertEqual(request('POST','x=%zz',headers,path='/action')[0],400)
        self.assertEqual(self.cli('list',self.db)['revision'],1)
        status, body = post(fields)
        self.assertEqual(status,200)
        self.assertIn('Reservation saved.',body)
        self.assertIn('2026-11-16',body)
        self.assertIn('09:00–10:00',body)
        status, body = post(dict(fields,id='2',start='11:00',end='12:00'))
        self.assertEqual(status,409)
        self.assertIn('name="rev" value="2"',body)
        self.assertIn('value="11:00"',body)
        status, body = post(dict(fields,rev='2',id='<script>alert(1)</script>'))
        self.assertEqual(status,400)
        self.assertNotIn('<script>',body)
        self.assertIn('&lt;script&gt;',body)
        self.assertEqual(post(dict(fields,rev='2',id='2'))[0],409)
        status, body = post(dict(action='cancel',rev='2',id='1',token=token))
        self.assertEqual(status,200)
        self.assertIn('Reservation cancelled.',body)
        self.assertEqual(self.cli('list',self.db),dict(revision=3,bookings=[]))

    def test_mcp(self):
        self.init()
        self.reserve()
        p = self.start('mcp')
        def send(value):
            p.stdin.write((json.dumps(value)+'\n').encode()); p.stdin.flush()
        def receive():
            self.assertTrue(select.select([p.stdout],[],[],5)[0], 'MCP response timed out')
            return json.loads(p.stdout.readline())
        def call(method,params=None,id=1):
            req = dict(jsonrpc='2.0',id=id,method=method)
            if params is not None: req['params']=params
            send(req); return receive()
        self.assertIn('error',call('tools/list'))
        self.assertEqual(call('initialize',dict(protocolVersion='2025-11-25',capabilities={},clientInfo={'name':'test','version':'1'}))['result']['protocolVersion'],'2025-11-25')
        send(dict(jsonrpc='2.0',method='notifications/initialized'))
        tools = call('tools/list')['result']['tools']
        self.assertEqual(len(tools),1)
        self.assertEqual(tools[0]['name'],'booking_list')
        self.assertEqual(tools[0]['inputSchema'],dict(type='object',properties={},additionalProperties=False))
        self.assertEqual(call('tools/call',dict(name='booking_list',arguments={}))['result']['structuredContent'],self.cli('list',self.db))
        for params in [dict(name='booking_list'),dict(name='booking_list',arguments={'path':self.db}),dict(name='reserve',arguments={}),dict(name='booking_list',arguments=[])]:
            self.assertIn('error',call('tools/call',params))
        p.stdin.write(b'{"jsonrpc":"2.0","id":4,"method":"ping","p\\u0061rams":{},"params":{}}\n');p.stdin.flush()
        self.assertEqual(receive()['error']['code'],-32700)
        p.stdin.write(b'x'*70000+b'\n');p.stdin.flush()
        self.assertEqual(receive()['error']['code'],-32700)
        p.stdin.write(b'{oops}\n');p.stdin.flush()
        self.assertEqual(receive()['error']['code'],-32700)
        send(dict(jsonrpc='2.0',method='tools/call',params=dict(name='cancel',arguments={'id':'1'})))
        self.assertEqual(call('ping')['result'],{})
        self.assertEqual(self.cli('list',self.db)['revision'],2)
        os.unlink(self.db)
        self.assertTrue(call('tools/call',dict(name='booking_list',arguments={}))['result']['isError'])
        self.assertEqual(call('ping')['result'],{})


if __name__ == '__main__':
    unittest.main(verbosity=2)
