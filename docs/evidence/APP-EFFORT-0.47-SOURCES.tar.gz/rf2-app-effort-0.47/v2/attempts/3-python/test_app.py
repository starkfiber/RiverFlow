"""Application integration checks; all workspaces are temporary local files."""
import datetime
import http.client
import io
import socket
from types import SimpleNamespace
from app import make_handler
import json
import os
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from urllib.parse import urlencode, urlsplit

ROOT = Path(__file__).resolve().parent

class AppTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=ROOT)
        self.addCleanup(self.tmp.cleanup)
        self.db = str(Path(self.tmp.name) / 'rooms.db')
        self.cli('init', ok=True)

    def cli(self, action, *args, ok=True, db=None):
        p = subprocess.run([sys.executable, str(ROOT/'app.py'), action, db or self.db, *map(str,args)], capture_output=True, text=True)
        self.assertEqual(p.returncode, 0 if ok else 2, p.stderr + p.stdout)
        self.assertEqual(p.stderr, '')
        return json.loads(p.stdout)

    def book(self, rev=1, id='1', room=1, date='2026-11-16', start='09:00', end='10:00', ok=True):
        return self.cli('reserve', rev,id,room,date,start,end,ok=ok)

    def test_cli_persistence_order_and_conflicts(self):
        self.assertEqual(self.cli('list'), {'revision':1,'bookings':[]})
        self.assertEqual(self.cli('init',ok=False), {'error':17})
        s = self.book()
        self.assertEqual(s['revision'], 2)
        self.assertEqual(s['bookings'][0],dict(id='1',room=1,day=datetime.date(2026,11,16).toordinal(),start=540,finish=600))
        self.assertEqual(self.book(rev=1,id='2',ok=False), {'error':409})
        self.assertEqual(self.book(rev=2,id='2',start='09:59',ok=False), {'error':409})
        self.book(rev=2,id='2',start='10:00',end='11:00')
        self.book(rev=3,id='3',room=2)
        self.book(rev=4,id='4',date='2026-11-17')
        self.assertEqual(self.book(rev=5,ok=False), {'error':17})
        s = self.cli('cancel',5,'2')
        self.assertEqual([b['id'] for b in s['bookings']], ['1','3','4'])
        self.assertEqual(self.cli('cancel',6,'2',ok=False), {'error':404})
        self.assertEqual(self.cli('list'),s)

    def test_validation_and_boundaries(self):
        for key,value in [('id','0'),('id','01'),('id','18446744073709551616'),('id','١'),('room','17'),('room','0'),('date','2026-2-01'),('date','2025-02-29'),('date','0000-01-01'),('start','9:00'),('start','24:00'),('end','24:01'),('end','09:00'),('rev','0')]:
            with self.subTest(key=key,value=value):
                self.assertEqual(self.book(**{key:value},ok=False), {'error':22})
                self.assertEqual(self.cli('list')['revision'],1)
        self.book(id='18446744073709551615',date='0001-01-01',start='00:00',end='24:00')
        self.book(rev=2,id='2',date='9999-12-31',start='23:59',end='24:00')
        self.assertEqual(self.cli('list',db=str(Path(self.tmp.name)/'missing'),ok=False), {'error':404})
        self.assertEqual(self.cli('reserve',1,2,1,'2026-11-16','09:00','10:00','extra',ok=False),{'error':22})

    def test_capacity(self):
        for n in range(1,257):
            # One-minute adjacent slots in a single day.
            self.book(rev=n,id=str(n),start=f'{(n-1)//60:02}:{(n-1)%60:02}',end=f'{n//60:02}:{n%60:02}')
        self.assertEqual(self.book(rev=257,id='257',room=2,ok=False),{'error':409})
        self.assertEqual(len(self.cli('list')['bookings']),256)

    def test_lock_and_corruption(self):
        con=sqlite3.connect(self.db)
        try:
            con.execute('BEGIN IMMEDIATE')
            self.assertEqual(self.book(ok=False),{'error':35})
        finally:
            con.rollback();con.close()
        p=Path(self.tmp.name)/'corrupt.db';p.write_bytes(b'not sqlite')
        self.assertIn('error',self.cli('list',db=str(p),ok=False))

    def test_concurrent_revision(self):
        args=[sys.executable,str(ROOT/'app.py'),'reserve',self.db,'1']
        a=subprocess.Popen(args+['1','1','2026-11-16','09:00','10:00'],stdout=subprocess.PIPE)
        b=subprocess.Popen(args+['2','2','2026-11-16','09:00','10:00'],stdout=subprocess.PIPE)
        results=[json.loads(p.communicate(timeout=5)[0]) for p in (a,b)]
        self.assertEqual(sum('revision' in r for r in results),1)
        self.assertIn(next(r['error'] for r in results if 'error' in r),(35,409))
        self.assertEqual(len(self.cli('list')['bookings']),1)

    def test_web(self):
        p=subprocess.Popen([sys.executable,str(ROOT/'app.py'),'serve',self.db],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        self.addCleanup(lambda: self.stop(p))
        url=p.stdout.readline().strip()
        if url == '{"error":5}':
            # Only skip for a verified OS permission failure, never for arbitrary startup errors.
            probe=socket.socket()
            try:
                probe.bind(('127.0.0.1',0))
            except PermissionError as exc:
                self.skipTest(f'OS sandbox forbids loopback bind: {exc}')
            finally:
                probe.close()
        self.assertRegex(url,r'^http://127\.0\.0\.1:[0-9]+/$')
        parsed=urlsplit(url)
        def request(method='GET',body=None,headers=None,path='/'):
            conn=http.client.HTTPConnection(parsed.hostname,parsed.port,timeout=5)
            conn.request(method,path,body,headers or {})
            response=conn.getresponse();data=response.read().decode();status=response.status;conn.close()
            return status,data
        status,body=request();self.assertEqual(status,200)
        for label in ['Reservation ID','Room (1–16)','Date (YYYY-MM-DD)','Start (HH:MM)','End (HH:MM)']:
            self.assertIn(label,body)
        token=re.search(r'name="token" value="([a-f0-9]+)"',body)[1]
        fields=dict(action='reserve',rev='1',id='7',room='3',date='2026-11-16',start='09:00',end='10:00',token=token)
        headers={'Origin':url.rstrip('/'),'Content-Type':'application/x-www-form-urlencoded'}
        def post(data,override=None):
            return request('POST',data,{**headers,**(override or {})},'/action')
        self.assertEqual(request(headers={'Host':'evil.test'})[0],403)
        self.assertEqual(post(urlencode(fields),{'Origin':'http://evil.test'})[0],403)
        self.assertEqual(post(urlencode({**fields,'token':'bad'}))[0],403)
        for bad in [urlencode(fields)+'&id=8',urlencode(fields)+'&unknown=x',urlencode(fields)+'&%69d=8',urlencode(fields)+'&x=%ZZ']:
            self.assertEqual(post(bad)[0],400)
        self.assertEqual(self.cli('list')['revision'],1)
        self.assertEqual(post(urlencode(fields))[0],200)
        status,body=post(urlencode({**fields,'id':'8'}))
        self.assertEqual(status,409);self.assertIn('name="rev" value="2"',body);self.assertIn('value="8"',body)
        status,body=post(urlencode({**fields,'rev':'2','id':'<script>','room':'2'}))
        self.assertEqual(status,400);self.assertIn('&lt;script&gt;',body)
        status,body=post(urlencode(dict(action='cancel',rev='2',id='7',token=token)))
        self.assertEqual(status,200);self.assertIn('cancelled',body)
        self.assertEqual(self.cli('list'),{'revision':3,'bookings':[]})

    def test_http_handler_without_socket(self):
        token='a'*32
        handler=make_handler(self.db,token)
        server=SimpleNamespace(endpoint='127.0.0.1:12345')
        class Transport:
            def __init__(self,raw):
                self.reader=io.BytesIO(raw)
                self.sent=bytearray()
            def makefile(self,*args,**kwargs): return self.reader
            def sendall(self,data): self.sent.extend(data)
        def request(method='GET',fields=None,extra='',headers=None,path='/'):
            body=(urlencode(fields)+extra).encode() if fields is not None else b''
            hdr={'Host':server.endpoint}
            if method=='POST':
                hdr.update({'Origin':'http://'+server.endpoint,'Content-Type':'application/x-www-form-urlencoded','Content-Length':str(len(body))})
            hdr.update(headers or {})
            raw=(method+' '+path+' HTTP/1.1\r\n'+''.join(k+': '+v+'\r\n' for k,v in hdr.items())+'\r\n').encode()+body
            transport=Transport(raw)
            handler(transport,('127.0.0.1',123),server)
            head,body=bytes(transport.sent).split(b'\r\n\r\n',1)
            return int(head.split()[1]),body.decode()
        status,body=request()
        self.assertEqual(status,200)
        self.assertIn('name="token" value="'+token+'"',body)
        fields=dict(action='reserve',rev='1',id='7',room='3',date='2026-11-16',start='09:00',end='10:00',token=token)
        def post(values=fields,**kw): return request('POST',values,path='/action',**kw)
        self.assertEqual(request(headers={'Host':'evil.test'})[0],403)
        self.assertEqual(post(headers={'Origin':'http://evil.test'})[0],403)
        self.assertEqual(post({**fields,'token':'wrong'})[0],403)
        for extra in ('&id=8','&%69d=8','&unknown=x','&bad=%ZZ'):
            self.assertEqual(post(extra=extra)[0],400)
        self.assertEqual(self.cli('list')['revision'],1)
        self.assertEqual(post()[0],200)
        status,body=post({**fields,'id':'8'})
        self.assertEqual(status,409)
        self.assertIn('name="rev" value="2"',body)
        self.assertIn('value="8"',body)
        status,body=post({**fields,'rev':'2','id':'<script>'})
        self.assertEqual(status,400)
        self.assertIn('&lt;script&gt;',body)
        status,body=post(dict(action='cancel',rev='2',id='7',token=token))
        self.assertEqual(status,200)
        self.assertIn('cancelled',body)
        self.assertEqual(self.cli('list'),{'revision':3,'bookings':[]})

    @staticmethod
    def stop(p):
        p.terminate()
        p.communicate(timeout=5)

    def test_mcp(self):
        requests=[
            '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{},"clientInfo":{"name":"test","version":"1"}}}',
            '{"jsonrpc":"2.0","method":"notifications/initialized"}',
            '{"jsonrpc":"2.0","id":2,"method":"tools/list"}',
            '{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"booking_list","arguments":{}}}',
            '{"jsonrpc":"2.0","id":4,"method":"tools/call","params":{"name":"booking_list","arguments":{"path":"x"}}}',
            '{"jsonrpc":"2.0","id":5,"method":"tools/call","params":{"name":"reserve","arguments":{}}}',
            '{"jsonrpc":"2.0","id":6,"id":7,"method":"ping"}',
            '{bad',
            'x'*65537,
            '{"jsonrpc":"2.0","method":"tools/call","params":{"name":"reserve","arguments":{}}}',
            '{"jsonrpc":"2.0","id":8,"method":"unknown"}',
            '{"jsonrpc":"2.0","id":9,"method":"ping"}',
        ]
        p=subprocess.run([sys.executable,str(ROOT/'app.py'),'mcp',self.db],input='\n'.join(requests)+'\n',text=True,capture_output=True,timeout=5)
        self.assertEqual(p.returncode,0,p.stderr)
        responses=[json.loads(line) for line in p.stdout.splitlines()]
        self.assertEqual(len(responses),10)
        self.assertEqual(responses[0]['result']['protocolVersion'],'2025-11-25')
        tools=responses[1]['result']['tools'];self.assertEqual(len(tools),1)
        self.assertEqual(tools[0]['name'],'booking_list')
        self.assertEqual(tools[0]['inputSchema'],dict(type='object',properties={},additionalProperties=False))
        self.assertEqual(responses[2]['result']['structuredContent'],{'revision':1,'bookings':[]})
        for r in responses[3:9]:self.assertIn('error',r)
        self.assertEqual(responses[-1],{'jsonrpc':'2.0','id':9,'result':{}})
        self.assertEqual(self.cli('list')['revision'],1)

    def test_mcp_storage_error_and_protocol_recovery(self):
        requests=[
            dict(jsonrpc='2.0',id=1,method='initialize',params=dict(protocolVersion='2025-11-25',capabilities={},clientInfo={})),
            dict(jsonrpc='2.0',method='notifications/initialized'),
            dict(jsonrpc='2.0',id=2,method='tools/call',params=dict(name='booking_list',arguments={})),
            dict(jsonrpc='2.0',id=3,method='ping',params=dict(unexpected=True)),
            dict(jsonrpc='2.0',id=4,method='ping',unexpected=True),
            dict(jsonrpc='2.0',id='\ud800',method='ping'),
            dict(jsonrpc='2.0',id=5,method='tools/call',params=dict(name='booking_list')),
            dict(jsonrpc='2.0',id=6,method='ping'),
        ]
        missing=str(Path(self.tmp.name)/'missing.db')
        p=subprocess.run([sys.executable,str(ROOT/'app.py'),'mcp',missing],input=''.join(json.dumps(r)+'\n' for r in requests),text=True,capture_output=True,timeout=5)
        self.assertEqual(p.returncode,0,p.stderr)
        responses=[json.loads(line) for line in p.stdout.splitlines()]
        self.assertEqual(len(responses),7)
        self.assertTrue(responses[1]['result']['isError'])
        self.assertNotIn('structuredContent',responses[1]['result'])
        for response in responses[2:6]:self.assertIn('error',response)
        self.assertEqual(responses[-1]['result'],{})
        self.assertFalse(Path(missing).exists())

if __name__=='__main__':
    unittest.main(verbosity=2)
