"""Local Study Rooms application. Python standard library only."""
import datetime as dt
import html
import json
import re
import secrets
import sys
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import parse_qsl

from booking_sdk import execute, BookingError
from mcp_sdk import serve as serve_mcp


def storage(path, action, **kw):
    try:
        return execute(path, action, **kw)
    except BookingError as exc:
        # Normalize missing workspace and capacity to the public application codes.
        raise BookingError({2: 404, 27: 409}.get(exc.code, exc.code)) from exc


def decimal(value, low, high):
    if not isinstance(value, str) or not re.fullmatch(r'[0-9]+', value) or len(value) > 20:
        raise BookingError(22)
    n = int(value)
    if not low <= n <= high:
        raise BookingError(22)
    return n


def date_value(value):
    if not re.fullmatch(r'[0-9]{4}-[0-9]{2}-[0-9]{2}', value):
        raise BookingError(22)
    try:
        return dt.date.fromisoformat(value).toordinal()
    except ValueError:
        raise BookingError(22)


def time_value(value, end=False):
    if not re.fullmatch(r'[0-9]{2}:[0-9]{2}', value):
        raise BookingError(22)
    h, m = map(int, value.split(':'))
    if end and h == 24 and m == 0:
        return 1440
    if h > 23 or m > 59:
        raise BookingError(22)
    return h * 60 + m


def reserve(path, values):
    return storage(path, 'reserve', expected=decimal(values['rev'], 1, 2**32-1),
                   id=values['id'], room=decimal(values['room'], 1, 16),
                   day=date_value(values['date']), start=time_value(values['start']),
                   finish=time_value(values['end'], True))


def cancel(path, values):
    return storage(path, 'cancel', expected=decimal(values['rev'], 1, 2**32-1), id=values['id'])


MESSAGES = {
    22: 'Invalid input. Use a positive decimal ID, room 1–16, YYYY-MM-DD and HH:MM. End must be after start; only the end may be 24:00.',
    17: 'That reservation ID already exists. Choose a different ID.',
    404: 'The reservation or workspace was not found. Review the current list.',
    409: 'The form is stale, the room overlaps another booking, or capacity is full. Current reservations are shown below. Review them and submit again.',
    35: 'The workspace is busy. Wait briefly, refresh and try again.',
}

CSS = '''
:root{color-scheme:light dark;--bg:#f3f5f9;--card:#fff;--ink:#172338;--muted:#526078;--line:#cad3e1;--accent:#2458bb;--notice:#eef4ff}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.5 system-ui,sans-serif}main{max-width:1100px;margin:auto;padding:32px 20px 60px}header{margin-bottom:24px}h1{font-size:2.2rem;margin:0}h2{margin-top:0;font-size:1.3rem}.subtitle,small{color:var(--muted)}.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:24px;margin:20px 0}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}label{display:flex;flex-direction:column;gap:6px;font-weight:600}input,select,button{font:inherit;border:1px solid var(--line);border-radius:7px;padding:10px;min-width:0;background:var(--card);color:var(--ink)}button{cursor:pointer;background:var(--accent);color:white;font-weight:650;border-color:var(--accent)}button.cancel{background:transparent;color:var(--ink);border-color:var(--line)}:focus-visible{outline:3px solid #c17c00;outline-offset:3px}.submit{margin-top:20px}.notice{padding:16px;border:1px solid var(--accent);border-radius:8px;background:var(--notice)}.table-wrap{overflow-x:auto}table{border-collapse:collapse;width:100%;text-align:left}th,td{padding:12px 10px;border-bottom:1px solid var(--line);white-space:nowrap}th{color:var(--muted);font-size:.9rem}a{color:var(--accent)}.revision{font-variant-numeric:tabular-nums}footer{color:var(--muted);font-size:.9rem}@media(max-width:650px){.grid{grid-template-columns:1fr 1fr}.card{padding:16px}main{padding:20px 12px}h1{font-size:1.8rem}}@media(max-width:380px){.grid{grid-template-columns:1fr}}@media(prefers-color-scheme:dark){:root{--bg:#111827;--card:#1b2535;--ink:#e8edf7;--muted:#b0bed2;--line:#47546b;--accent:#83adff;--notice:#20324c}button{color:#101b30}button.cancel{color:var(--ink)}}
'''


def esc(value):
    return html.escape(str(value), quote=True)


def clock(value):
    return f'{value // 60:02d}:{value % 60:02d}'


def page(state, token, message='', values=None):
    values = values or {}
    used = {b['id'] for b in state['bookings']}
    next_id = next(str(n) for n in range(1, 258) if str(n) not in used)
    defaults = dict(id=next_id, room='1', date=dt.date.today().isoformat(), start='09:00', end='10:00')
    defaults.update({k: v for k, v in values.items() if k in defaults})
    hidden = f'<input type="hidden" name="rev" value="{state["revision"]}"><input type="hidden" name="token" value="{token}">'
    rows = []
    for b in state['bookings']:
        day = dt.date.fromordinal(b['day']).isoformat()
        rows.append(f'''<tr><td>{esc(b['id'])}</td><td>Room {b['room']}</td><td>{day}</td><td>{clock(b['start'])}–{clock(b['finish'])}</td><td><form method="post" action="/action">{hidden}<input type="hidden" name="action" value="cancel"><input type="hidden" name="id" value="{esc(b['id'])}"><button class="cancel" type="submit" aria-label="Cancel reservation {esc(b['id'])}">Cancel</button></form></td></tr>''')
    fields = ''
    for name, label in [('id','Reservation ID'), ('room','Room (1–16)'), ('date','Date (YYYY-MM-DD)'), ('start','Start (HH:MM)'), ('end','End (HH:MM)')]:
        hint = ' inputmode="numeric"' if name in ('id', 'room') else ''
        fields += f'<label for="{name}">{label}<input id="{name}" name="{name}" value="{esc(defaults[name])}" required maxlength="{20 if name == "id" else 10}"{hint}></label>'
    notice = f'<p class="notice" role="status">{esc(message)}</p>' if message else ''
    table = '<div class="table-wrap"><table><thead><tr><th>ID</th><th>Room</th><th>Date</th><th>Time</th><th>Action</th></tr></thead><tbody>' + ''.join(rows) + '</tbody></table></div>' if rows else '<p>No reservations yet. Choose a room and time to make your first booking.</p>'
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Study Rooms</title><style>{CSS}</style></head><body><main><header><p class="subtitle">Your local study workspace</p><h1>Study Rooms</h1><p>Reserve a quiet space. Rooms 1–16 · same-day bookings · 24-hour time</p></header>{notice}<section class="card"><h2>Reserve a room</h2><form method="post" action="/action">{hidden}<input type="hidden" name="action" value="reserve"><div class="grid">{fields}</div><p><small>Adjacent bookings are welcome. End at 24:00 for midnight. IDs must be unique positive decimal numbers.</small></p><button class="submit" type="submit">Reserve room</button></form></section><section class="card"><h2>Saved reservations</h2><p class="revision">Revision {state['revision']} · {len(rows)} / 256 reservations · <a href="/">Refresh saved state</a></p>{table}</section><footer>Local loopback service. Dates and times are used exactly as entered, with no timezone conversion.</footer></main></body></html>'''.encode('utf-8')


def make_handler(path, token):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def output(self, status, body, content_type='text/html; charset=utf-8'):
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'")
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(body)

        def endpoint_ok(self):
            return self.headers.get_all('Host') == [self.server.endpoint]

        def show(self, status=200, message='', values=None):
            try:
                state = storage(path, 'list')
                self.output(status, page(state, token, message, values))
            except BookingError as exc:
                self.output(503, f'Workspace read failed ({exc.code}). Refresh before retrying.'.encode(), 'text/plain; charset=utf-8')

        def do_GET(self):
            if not self.endpoint_ok():
                self.output(403, b'Invalid Host', 'text/plain')
            elif self.path != '/':
                self.output(404, b'Not found', 'text/plain')
            else:
                self.show()

        def do_POST(self):
            # Close on rejection so unread request bodies cannot become another request.
            self.close_connection = True
            if not self.endpoint_ok() or self.headers.get_all('Origin') != ['http://' + self.server.endpoint]:
                self.output(403, b'Invalid Host or Origin. Open the exact local URL and retry.', 'text/plain')
                return
            if self.path != '/action':
                self.output(404, b'Not found', 'text/plain')
                return
            values = {}
            try:
                lengths = self.headers.get_all('Content-Length')
                if not lengths or len(lengths) != 1 or not re.fullmatch(r'[0-9]{1,5}', lengths[0]):
                    raise BookingError(22)
                size = int(lengths[0])
                if not 0 < size <= 8192 or self.headers.get('Transfer-Encoding') is not None:
                    raise BookingError(22)
                if self.headers.get_content_type() != 'application/x-www-form-urlencoded':
                    raise BookingError(22)
                raw = self.rfile.read(size)
                if len(raw) != size:
                    raise BookingError(22)
                text = raw.decode('utf-8', 'strict')
                if re.search(r'%(?![0-9a-fA-F]{2})', text):
                    raise BookingError(22)
                pairs = parse_qsl(text, keep_blank_values=True, strict_parsing=True, encoding='utf-8', errors='strict', max_num_fields=9)
                for key, value in pairs:
                    if key in values:
                        raise BookingError(22)
                    values[key] = value
                action = values.get('action')
                expected = {'action', 'rev', 'id', 'token'}
                if action == 'reserve':
                    expected |= {'room', 'date', 'start', 'end'}
                elif action != 'cancel':
                    raise BookingError(22)
                if set(values) != expected:
                    raise BookingError(22)
                if not secrets.compare_digest(values['token'].encode(), token.encode()):
                    self.show(403, 'Invalid form token. Review the refreshed form and try again.', values)
                    return
                (reserve if action == 'reserve' else cancel)(path, values)
                self.show(200, 'Reservation saved.' if action == 'reserve' else 'Reservation cancelled.')
            except (ValueError, UnicodeError):
                self.show(400, MESSAGES[22], values)
            except BookingError as exc:
                status = {22:400, 17:409, 409:409, 404:404, 35:503}.get(exc.code, 503)
                self.show(status, MESSAGES.get(exc.code, f'Storage failed ({exc.code}). Refresh and inspect saved state before retrying.'), values)

    return Handler


def web(path):
    storage(path, 'list')  # Refuse missing/unreadable workspaces before announcing a URL.
    token = secrets.token_hex(16)
    server = HTTPServer(('127.0.0.1', 0), make_handler(path, token))
    server.endpoint = f'127.0.0.1:{server.server_address[1]}'
    print('http://' + server.endpoint + '/', flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()


def main(args):
    if len(args) < 2:
        raise BookingError(22)
    action, path, *rest = args
    if action in ('init', 'list') and not rest:
        result = storage(path, action)
    elif action == 'reserve' and len(rest) == 6:
        result = reserve(path, dict(zip(('rev','id','room','date','start','end'), rest)))
    elif action == 'cancel' and len(rest) == 2:
        result = cancel(path, dict(zip(('rev','id'), rest)))
    elif action == 'serve' and not rest:
        web(path)
        return
    elif action == 'mcp' and not rest:
        serve_mcp('study-rooms', '1.0.0', 'booking_list', 'Read saved study-room reservations in this workspace.', lambda: storage(path, 'list'))
        return
    else:
        raise BookingError(22)
    print(json.dumps(result, separators=(',', ':')))


if __name__ == '__main__':
    try:
        main(sys.argv[1:])
    except BookingError as exc:
        print(json.dumps({'error': exc.code}, separators=(',', ':')))
        sys.exit(2)
    except (OSError, ValueError):
        print('{"error":5}')
        sys.exit(2)
    except KeyboardInterrupt:
        pass
