# Study Rooms

A local Python application with a command-line interface, browser forms and a read-only MCP server. Runtime dependencies are Python 3.9+ and its standard library. No packages, assets or network services are required.

## Build and launch

No native compilation is needed. `launch.json` contains `["python3","app.py"]`. Run commands from this directory:

```sh
python3 app.py init rooms.db
python3 app.py reserve rooms.db 1 1 3 2026-11-16 09:00 10:00
python3 app.py list rooms.db
python3 app.py serve rooms.db
```

The reservation example returns revision 2 and one booking: ID `1`, room 3, ordinal day 739936, start 540, finish 600. `serve` prints its exact `http://127.0.0.1:PORT/` URL first, then serves until stopped with Ctrl-C. Open that URL in a browser. The OS must permit loopback socket binding. Ports are ephemeral and change between launches. Start with `init`; the browser never creates a missing workspace.

To cancel the example:

```sh
python3 app.py cancel rooms.db 2 1
```

`init` exclusively creates a new file. `list` reads saved state. Mutations require the current revision, a positive canonical decimal u64 reservation ID and valid inputs. Bookings preserve insertion order. Room numbers are 1–16, dates are exactly `YYYY-MM-DD` (years 0001–9999), and times are exactly `HH:MM`. Intervals are half-open, so adjacent reservations are allowed. `24:00` is accepted only as the end. There are at most 256 current reservations. There is no timezone conversion or recurrence.

Successful CLI output is JSON with `revision` and `bookings`; dates are Gregorian ordinals and times are minutes since midnight. Failures emit `{"error":CODE}` and exit 2. Public codes include invalid 22, exists 17, not found 404, conflict/stale/capacity 409 and busy 35. Other SDK/storage errors remain failures. After an uncertain storage error, read the saved state before deciding whether to retry. Stale browser forms display the latest state and retain reserve inputs for review; they never automatically retry a mutation.

## Browser behavior

The browser shows labelled inputs, explicit cancellation buttons, current revision and saved reservations. It includes responsive layouts, light/dark colors and keyboard focus indicators. It uses no scripts, fonts or assets from the network. All dynamic input is HTML escaped.

Writes require the exact loopback Host and Origin, a process-local random CSRF token, and exact, unique form fields. Bodies are bounded to 8192 bytes. Rejected input does not write. Refresh/review before resubmitting stale or failed forms. The server is a single-request-at-a-time standard-library HTTPServer, intended for local use. This is not public hosting or authentication; hostile processes running as the same user and denial-of-service resistance are outside its scope.

## Read-only MCP

```sh
python3 app.py mcp rooms.db
```

Use newline JSON-RPC on stdin/stdout. Initialize with protocol version `2025-11-25`, then send `notifications/initialized`. The single tool is `booking_list`; call it with the explicit empty `arguments` object. It returns saved state in `structuredContent` plus text. `ping` and `tools/list` are supported. No tool accepts a path, writes, migrates, executes source or accesses a network. Duplicate decoded JSON keys, malformed requests and oversized lines are refused while later valid requests remain usable. Input lines are bounded to 65536 bytes excluding newline. Tool storage errors return `isError: true`.

Example protocol lines:

```json
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{},"clientInfo":{"name":"example","version":"1"}}}
{"jsonrpc":"2.0","method":"notifications/initialized"}
{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"booking_list","arguments":{}}}
```

## Storage and SDK

`booking_sdk.py` is the supplied SQLite domain/storage SDK, retained unchanged. Every interface uses its `execute` transaction path and revision/locking rules. The application translates missing-file code 2 to 404 and capacity code 27 to 409. `mcp_sdk.py` is the supplied read-only protocol helper with small validation additions for unknown envelope fields, nonempty ping parameters and invalid surrogate request IDs. `app.py` implements the application, validation and browser interface.

Storage uses SQLite with full synchronous commits and the SDK's DELETE journal mode. Keep the database on a local writable filesystem, with its parent directory writable for SQLite journal files. Do not copy a database during a write; stop writers before making a portable file copy. This is SQLite format, not an RF2 journal. Network filesystem locking, crash/power-loss recovery under physical faults and other platforms have not been qualified. The SDK rejects symlinks and nonregular or multiply linked files, but hostile same-user path isolation is not claimed.

## Checks and evidence

Run the build check with an in-directory bytecode cache (the Mac's default cache may be outside this isolated directory):

```sh
PYTHONPYCACHEPREFIX="$PWD/__pycache__" python3 -m py_compile app.py booking_sdk.py mcp_sdk.py test_app.py
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest -v test_app
```

`test_app.py` tests fresh-process persistence, canonical IDs, date/time boundaries, adjacency/overlap, room/day independence, duplicate IDs, stale revisions, cancellation order, all 256 capacity slots, SQLite locking/corruption and competing writers. It also tests MCP initialization, tool schema/results, rejected arguments/methods, duplicate keys, malformed JSON, oversized input, notifications and recovery. Browser checks exercise the actual HTTP handler and SQLite storage through an in-memory HTTP transport, including Host/Origin/token rejection, duplicate decoded fields, escaping, input retention, refreshed revisions and cancellation.

The initial run (`test-results-initial.txt`) had six passing tests and a failed live-browser integration test: the OS sandbox denied `socket.bind` to loopback with `PermissionError: [Errno 1] Operation not permitted`. This failure is preserved. The later suite marks that live test skipped only after separately verifying the bind permission failure, and includes the in-memory handler test. The final run reports 9 tests: 8 passed and 1 skipped. See `test-results.txt` for the actual output. No live browser rendering, accessibility audit or external acceptance suite was run. No claims of unseen grader results, human trials or performance savings are made.
