from pathlib import Path
import re
p=Path('main.flow'); lines=p.read_text().splitlines(); stack=[]; out=[]; serial=0
for line in lines:
 s=line.strip()
 if s=='end':
  out.append(line)
  if stack:stack.pop()
  continue
 if s.startswith(('fn ','if ','while ','handle ')):
  mapping={k:v for d in stack for k,v in d.items()}
  line=re.sub(r'\b[A-Za-z_][A-Za-z_0-9]*\b',lambda m:mapping.get(m[0],m[0]),line) if not s.startswith('fn ') else line
  out.append(line);stack.append({});continue
 if s.startswith(('ok ','err ')):
  stack[-1].clear()
  m=re.match(r'(ok|err) (?:own )?([A-Za-z_][A-Za-z_0-9]*)',s)
  if m:
   serial+=1;stack[-1][m[2]]=m[2]+'_binding'+str(serial)
 mapping={k:v for d in stack for k,v in d.items()}
 # avoid changing text inside literals
 chunks=re.split(r'("(?:\\.|[^"\\])*")',line)
 for j in range(0,len(chunks),2):chunks[j]=re.sub(r'\b[A-Za-z_][A-Za-z_0-9]*\b',lambda m:mapping.get(m[0],m[0]),chunks[j])
 out.append(''.join(chunks))
p.write_text('\n'.join(out)+'\n')
