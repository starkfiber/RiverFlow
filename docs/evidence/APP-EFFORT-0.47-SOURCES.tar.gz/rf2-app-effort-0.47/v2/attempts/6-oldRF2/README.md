# Study Rooms — RF2

A native RF2 study-room reservation application with command-line operations, a responsive browser interface and a read-only newline JSON-RPC MCP server. All runtime application logic is RF2 in `main.flow`, `application.flow` and `lib/`. Python files are black-box test drivers only; the application does not launch Python or another application.

## Build and run

On this Mac, using the supplied compiler (no installation needed):

```sh
# rf2c refuses to overwrite an existing output; remove app before rebuilding.
rm -f app
./rf2c main.flow app --opt
/usr/bin/codesign -s - app
./app init artifacts/example.db
./app reserve artifacts/example.db 1 1 3 2026-11-16 09:00 10:00
./app list artifacts/example.db
./app serve artifacts/example.db
```

`serve` prints its exact ephemeral loopback URL on the first stdout line. Open that URL in a browser; terminate the process to stop it. This execution sandbox denied loopback socket binding, so actual browser launch could not be verified here. The server is intended for local use on a Mac that permits loopback sockets; it is not a public hosting or authentication system.

`launch.json` contains `["./app"]`. Arguments:

```text
init DB
list DB
reserve DB REV ID ROOM YYYY-MM-DD HH:MM HH:MM
cancel DB REV ID
serve DB
mcp DB
```

Successful CLI calls print the saved revision, SDK version and bookings as JSON. IDs are canonical positive decimal u64 strings; rooms are 1–16. Dates use Gregorian years 0001–9999. Times are same-day, half-open minute ranges; only an end may be 24:00. Adjacent reservations are allowed. Mutations require the exact current revision, preserve insertion order, and reject overlaps. Failures exit 2 with an error object. A missing workspace maps to 404; duplicate workspace or ID to 17, invalid input/capacity to 22, stale/overlap to 409 and lock contention to 35. Other storage errors remain failures and retain their SDK codes.

The browser shows saved reservations, labelled inputs, explicit cancellation buttons, success/error messages, retained failed reservation values and refreshed saved revisions. Its forms use the same domain and storage functions as the CLI. Host and POST Origin must match the actual endpoint. A random 128-bit process-local CSRF token is required. Unknown/duplicate fields and invalid requests are refused. No external scripts, assets or network services are used. CSS adapts to viewport size, system light/dark preference and reduced motion.

## MCP

Run `./app mcp artifacts/example.db`, then send one JSON-RPC object per line. No stdout banner is emitted. Supported protocol: `2025-11-25`; methods: initialize, notifications/initialized, ping, tools/list, tools/call. Exactly one tool is advertised:

```json
{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"booking_list","arguments":{}}}
```

Its result contains `structuredContent` with current saved state and a short text content. An explicit empty arguments object is required. There are no write, path-selection, migration or execution tools. Tool errors set `isError:true`. Parser errors, duplicate decoded keys and oversized lines are refused without terminating the connection. Lines are bounded to 65536 bytes; oversized input is drained to the next newline. Notifications do not execute tools or produce responses.

## Verification

```sh
# Build the test-only native HTTP harness; not used by app or launch.json.
rm -f tests/http-harness
./rf2c http-harness.flow tests/http-harness --opt
/usr/bin/codesign -s - tests/http-harness
python3 tests/selftest.py
python3 tests/capacity.py
```

The separate capacity test passed: 256 saved rows, refusal of a 257th, cancellation and refill. The self-test passed 121 assertions covering real fresh-process CLI operations, durable reopen, validation, actual file locks, concurrent writers, HTTP parsing/rendering/actions and request refusals, and persistent MCP protocol/recovery. Because sandbox loopback binding failed, HTTP checks exercised the actual RF2 parser/dispatcher/transport through Unix socket pairs using the test-only harness, with a deterministic test token. Production uses `/dev/urandom`. This does not establish TCP browser operation or visual appearance; no interactive browser or unseen acceptance tests were run. See `artifacts/VERIFICATION.md` for failures and evidence.

## SDK and limits

The supplied SDK provides typed bookings, shared locking/revision enforcement, native append-only storage, SHA-256 journal validation, bounded writers, Gregorian helpers, HTTP/form primitives, CSS components and JSON parsing. The application supplies command routing, validation orchestration, browser rendering/actions and MCP handling. SDK changes map missing paths to 404, explicitly refuse a 257th reservation with 22, extend the journal bound from 1 MiB to 4 MiB so 256 rows can be reached, remove the server's request-count shutdown and simplify unused UI navigation/appearance controls. The journal codec and lock/revision mechanism are unchanged.

This build targets native Apple Silicon macOS with Darwin system calls and ad-hoc signing, not Linux/Windows or Intel portability. Storage is a regular single-link file selected at process launch; symlinks and unsuitable files are refused by the SDK. Mutations lock, validate and append synchronized snapshots. The journal is bounded to 4 MiB with no automatic compaction or exposed recovery/migration command; long-lived workspaces can reach that storage limit even with fewer than 256 current rows. Corruption/incomplete tails remain failures rather than being silently repaired. Do not hand-edit the binary journal. Preserve the file if a save is uncertain (SDK error 9002) and inspect saved state before retrying. No timezone conversion, recurrence, user accounts or network authentication are provided. Power-loss recovery, hardware qualification and visual browser review were not tested.
