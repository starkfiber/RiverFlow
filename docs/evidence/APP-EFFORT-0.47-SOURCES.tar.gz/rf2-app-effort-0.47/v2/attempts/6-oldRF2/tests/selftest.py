"""Local black-box checks. Python is only the test driver; app runtime is RF2."""
import datetime, fcntl, json, os, pathlib, re, select, socket, subprocess, tempfile, urllib.parse, http.client
ROOT=pathlib.Path(__file__).resolve().parents[1]
os.chdir(ROOT)
checks=0
def check(v, message):
 global checks
 checks+=1
 assert v,message
def cli(*args, error=None):
 p=subprocess.run(['./app',*map(str,args)],capture_output=True,text=True,timeout=10)
 try: data=json.loads(p.stdout)
 except Exception: raise AssertionError((args,p.returncode,p.stdout,p.stderr))
 check(p.returncode==(2 if error else 0),(args,p.returncode,data))
 if error is not None:check(data=={'error':error},(args,data,error))
 return data
with tempfile.TemporaryDirectory(dir=ROOT/'artifacts',prefix='checks-') as td:
 db=pathlib.Path(td)/'rooms.db'
 cli('list',db,error=404)
 check(cli('init',db)['revision']==1,'initial revision')
 cli('init',db,error=17)
 s=cli('reserve',db,1,18446744073709551615,16,'0001-01-01','00:00','24:00')
 check(s['bookings'][0]==dict(id='18446744073709551615',room=16,day=1,start=0,finish=1440),'maximum id and full day')
 cli('reserve',db,1,2,1,'2026-11-16','09:00','10:00',error=409)
 cli('reserve',db,2,2,16,'0001-01-01','23:00','24:00',error=409)
 cli('reserve',db,2,18446744073709551615,1,'2026-11-16','09:00','10:00',error=17)
 cli('reserve',db,2,2,1,'2026-11-16','09:00','10:00')
 cli('reserve',db,3,3,1,'2026-11-16','10:00','11:00')
 cli('reserve',db,4,4,2,'2026-11-16','09:30','10:30')
 cli('reserve',db,5,5,1,'9999-12-31','23:59','24:00')
 for id,room,date,start,end in [('01',1,'2026-11-16','09:00','10:00'),('0',1,'2026-11-16','09:00','10:00'),('18446744073709551616',1,'2026-11-16','09:00','10:00'),('6',0,'2026-11-16','09:00','10:00'),('6',17,'2026-11-16','09:00','10:00'),('6',1,'1900-02-29','09:00','10:00'),('6',1,'2026-2-01','09:00','10:00'),('6',1,'0000-01-01','09:00','10:00'),('6',1,'2026-11-16','24:00','24:00'),('6',1,'2026-11-16','9:00','10:00'),('6',1,'2026-11-16','10:00','09:00')]:
  cli('reserve',db,6,id,room,date,start,end,error=22)
 check(cli('list',db)['revision']==6,'invalid operations unchanged')
 cli('cancel',db,6,999,error=404)
 cli('cancel',db,5,2,error=409)
 s=cli('cancel',db,6,2)
 check([x['id'] for x in s['bookings']]==['18446744073709551615','3','4','5'],'preserve insertion order')
 with open(db,'rb') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  cli('reserve',db,7,6,1,'2026-11-16','12:00','13:00',error=35)
 # HTTP, real local server, no external network.
 server=subprocess.Popen(['./app','serve',str(db)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 try:
  ready,_,_=select.select([server.stdout],[],[],5)
  check(bool(ready),'server URL timeout')
  url=server.stdout.readline().strip()
  socket_pair_mode=not url
  if socket_pair_mode:
   check(server.wait(timeout=5)==2,'server bind refused with failure')
   print('LIMIT: loopback bind denied by sandbox; HTTP uses actual RF2 parser/dispatch over local socket pairs.')
   url='http://127.0.0.1:54321/'
  check(bool(re.fullmatch(r'http://127\.0\.0\.1:\d+/',url)),('server URL',url))
  port=urllib.parse.urlsplit(url).port;host=f'127.0.0.1:{port}'
  def http(method,path='/',data=None,headers=None):
   if not socket_pair_mode:
    c=http.client.HTTPConnection('127.0.0.1',port,timeout=5)
    c.request(method,path,body=data,headers=headers or {})
    r=c.getresponse(); b=r.read().decode();status=r.status;c.close();return status,b
   left,right=socket.socketpair()
   left.settimeout(5)
   proc=subprocess.Popen(['./tests/http-harness',str(db),str(right.fileno()),'a'*32],pass_fds=(right.fileno(),),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   right.close()
   h={'Host':host,**(headers or {})}
   body=(data or '').encode()
   if data is not None:h['Content-Length']=str(len(body))
   request=(f'{method} {path} HTTP/1.1\r\n'+''.join(f'{k}: {v}\r\n' for k,v in h.items())+'\r\n').encode()+body
   left.sendall(request)
   result=b''
   while True:
    chunk=left.recv(65536)
    if not chunk:break
    result+=chunk
   left.close()
   stdout,stderr=proc.communicate(timeout=5)
   check(proc.returncode==0,('HTTP harness',proc.returncode,stderr))
   head,body=result.split(b'\r\n\r\n',1)
   return int(head.split()[1]),body.decode()
  status,html=http('GET')
  check(status==200 and 'Make room for focus.' in html,'GET page')
  token=re.search(r'name=token value="([a-f0-9]{32})"',html)[1]
  check(all(f'name="{x}"' in html or f'name={x}' in html for x in ['room','date','start','end']),'labelled inputs')
  base=dict(action='reserve',rev='7',id='6',room='3',date='2028-02-29',start='12:00',end='13:00',token=token)
  headers={'Origin':url[:-1],'Content-Type':'application/x-www-form-urlencoded'}
  def post(fields,extra='',h=None):return http('POST','/action',urllib.parse.urlencode(fields)+extra,headers if h is None else h)
  status,body=post(base)
  check(status==200 and 'Saved to your workspace.' in body,'web reserve')
  check(cli('list',db)['revision']==8,'web persisted')
  status,body=post(base)
  check('This booking could not be saved.' in body and 'value="2028-02-29"' in body,'stale notice and retained input')
  check('name=rev value="8"' in body,'fresh revision after stale')
  for fields,extra,h in [(dict(base,rev='8',id='7',token='bad'),'',None),(dict(base,rev='8',id='7'),'&id=8',None),(dict(base,rev='8',id='7'),'&unknown=1',None),(dict(base,rev='8',id='7'),'',dict(headers,Origin='http://evil.invalid'))]:
   status,body=post(fields,extra,h)
   check(status==400,'refused unsafe post')
   check(cli('list',db)['revision']==8,'unsafe post unchanged')
  status,body=http('GET',headers={'Host':'evil.invalid'})
  check(status==400,'host refused')
  cancel=dict(action='cancel',rev='8',id='6',token=token)
  status,body=post(cancel)
  check(status==200 and 'Saved to your workspace.' in body,'web cancel')
  check(cli('list',db)['revision']==9,'web cancel saved')
 finally:
  server.terminate();server.wait(timeout=5)
 # MCP: one persistent connection, recovery and read-only selected path.
 mcp=subprocess.Popen(['./app','mcp',str(db)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 def rpc(obj):
  line=obj if isinstance(obj,str) else json.dumps(obj)
  mcp.stdin.write(line+'\n');mcp.stdin.flush()
  ready,_,_=select.select([mcp.stdout],[],[],5)
  check(bool(ready),'MCP timeout')
  return json.loads(mcp.stdout.readline())
 def request(method,params=None,id=1):
  x=dict(jsonrpc='2.0',id=id,method=method)
  if params is not None:x['params']=params
  return x
 try:
  x=rpc(request('initialize',dict(protocolVersion='2025-11-25',capabilities={},clientInfo={'name':'selftest','version':'1'})))
  check(x['result']['protocolVersion']=='2025-11-25','MCP initialize')
  mcp.stdin.write(json.dumps(dict(jsonrpc='2.0',method='notifications/initialized'))+'\n');mcp.stdin.flush()
  check(rpc(request('ping'))['result']=={},'MCP ping')
  tools=rpc(request('tools/list'))['result']['tools']
  check(len(tools)==1 and tools[0]['name']=='booking_list','one read-only tool')
  check(tools[0]['inputSchema']==dict(type='object',properties={},additionalProperties=False),'strict schema')
  x=rpc(request('tools/call',dict(name='booking_list',arguments={})))['result']
  check(x['isError']==False and x['structuredContent']==cli('list',db),'MCP saved state')
  for params in [dict(name='booking_list'),dict(name='booking_list',arguments={'path':'other'}),dict(name='reserve',arguments={}),dict(name='booking_list',arguments={},extra=1)]:
   check(rpc(request('tools/call',params))['result']['isError']==True,'tool error')
  for raw in ['{','{"jsonrpc":"2.0","id":1,"method":"ping","m\\u0065thod":"ping"}', 'x'*65537]:
   check('error' in rpc(raw),'malformed refused')
  check('error' in rpc(request('unknown')),'unknown method')
  check(rpc(request('ping',id='string-id'))['id']=='string-id','recovery and string ID')
  mcp.stdin.write(json.dumps(dict(jsonrpc='2.0',method='tools/call',params={'name':'reserve','arguments':{}}))+'\n');mcp.stdin.flush()
  check(rpc(request('ping'))['result']=={},'notification has no response')
  check(cli('list',db)['revision']==9,'MCP did not mutate')
 finally:
  mcp.stdin.close();mcp.wait(timeout=5)
 # Concurrent writers use actual SDK lock/revision handling.
 jobs=[subprocess.Popen(['./app','reserve',str(db),'9',str(20+i),'5','2026-12-01',f'{i:02d}:00',f'{i+1:02d}:00'],stdout=subprocess.PIPE,text=True) for i in range(6)]
 results=[(p.wait(timeout=5),json.loads(p.stdout.read())) for p in jobs]
 check(sum(code==0 for code,data in results)==1,('one concurrent winner',results))
 check(all(code==0 or data['error'] in (35,409) for code,data in results),'concurrent losers refused')
 check(cli('list',db)['revision']==10,'one revision after race')
print(f'PASS: {checks} assertions; CLI, HTTP, MCP, locking and durability checks.')
