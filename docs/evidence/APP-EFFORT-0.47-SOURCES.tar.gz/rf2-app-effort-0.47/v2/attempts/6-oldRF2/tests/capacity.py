import json, pathlib, subprocess, tempfile
root=pathlib.Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(dir=root/'artifacts',prefix='capacity-') as td:
 db=str(pathlib.Path(td)/'rooms.db')
 def run(*args):
  p=subprocess.run([str(root/'app'),*map(str,args)],capture_output=True,text=True,timeout=30)
  return p.returncode,json.loads(p.stdout)
 assert run('init',db)[0]==0
 for i in range(1,257):
  status,data=run('reserve',db,i,i,1,'2026-11-16',f'{(i-1)//60:02}:{(i-1)%60:02}',f'{i//60:02}:{i%60:02}')
  assert status==0,(i,status,data)
 assert len(data['bookings'])==256 and data['revision']==257
 assert run('reserve',db,257,257,2,'2026-11-16','00:00','01:00')==(2,{'error':22})
 assert run('cancel',db,257,128)[0]==0
 status,data=run('reserve',db,258,257,2,'2026-11-16','00:00','01:00')
 assert status==0 and len(data['bookings'])==256 and data['revision']==259
 print('PASS: 256 current reservations, capacity refusal, cancel and refill; durable fresh-process operations.')
