"""Local black-box tests. Python is a test driver only; app runtime is RF2."""
import concurrent.futures
import datetime
import fcntl
import html.parser
import http.client
import json
import pathlib
import subprocess
import socket
import tempfile
import urllib.parse

ROOT = pathlib.Path(__file__).resolve().parents[1]
APP = str(ROOT / 'app')
checks = 0

def check(condition, message):
    global checks
    assert condition, message
    checks += 1

def cli(*args, error=None):
    p = subprocess.run([APP, *map(str, args)], capture_output=True, text=True, timeout=15)
    data = json.loads(p.stdout)
    check(p.returncode == (0 if error is None else 2), (args, p.returncode, p.stdout, p.stderr))
    if error is not None:
        check(data == {'error': error}, (args, data, error))
    return data

class Forms(html.parser.HTMLParser):
    def __init__(self, source):
        super().__init__(); self.forms=[]; self.current=None; self.feed(source)
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if tag=='form': self.current={}; self.forms.append(self.current)
        if tag=='input' and self.current is not None and 'name' in a:
            self.current[a['name']]=a.get('value','')
    def handle_endtag(self, tag):
        if tag=='form': self.current=None

with tempfile.TemporaryDirectory(prefix='selftest-', dir=ROOT/'artifacts') as tmp:
    db=pathlib.Path(tmp)/'study.db'
    cli('list',db,error=404)
    check(cli('init',db)=={'revision':1,'version':2,'bookings':[]},'initial')
    cli('init',db,error=17)
    def reserve(rev, id='1', room='1', date='2024-02-29', start='09:00', end='10:00', error=None):
        return cli('reserve',db,rev,id,room,date,start,end,error=error)
    first=reserve(1)
    check(first['bookings'][0]==dict(id='1',room=1,day=datetime.date(2024,2,29).toordinal(),start=540,finish=600),'row')
    reserve(1,'2',error=409)
    reserve(2,'2',start='09:59',end='10:30',error=409)
    reserve(2,'1',start='10:00',end='11:00',error=17)
    reserve(2,'2',start='10:00',end='11:00')
    reserve(3,'3','2')
    reserve(4,'4','1','2024-03-01')
    reserve(5,'18446744073709551615','16','9999-12-31','23:59','24:00')
    for kwargs in [dict(id='0'),dict(id='01'),dict(id='18446744073709551616'),dict(room='0'),dict(room='17'),dict(room='01'),dict(date='1900-02-29'),dict(date='0000-01-01'),dict(date='2024-2-29'),dict(start='9:00'),dict(start='24:00'),dict(end='24:01'),dict(start='10:00',end='09:00'),dict(start='10:00',end='10:00')]:
        reserve(6,**kwargs,error=22)
    check(cli('list',db)['revision']==6,'invalid did not save')
    cli('cancel',db,5,'1',error=409)
    cli('cancel',db,6,'99',error=404)
    cli('cancel',db,6,'0',error=22)
    cancelled=cli('cancel',db,6,'2')
    check([b['id'] for b in cancelled['bookings']]==['1','3','4','18446744073709551615'],'order')
    reserve(7,'5','3','0001-01-01','00:00','00:01')
    check(cli('list',db)['bookings'][-1]['day']==1,'first date')
    with open(db,'rb') as locked:
        fcntl.flock(locked,fcntl.LOCK_EX|fcntl.LOCK_NB)
        cli('list',db,error=35)
        reserve(8,'6',error=35)
    # Competing processes use the same revision. Exactly one succeeds.
    def race(i):
        return subprocess.run([APP,'reserve',str(db),'8',str(i),'4','2025-01-01','10:00','11:00'],capture_output=True,text=True)
    with concurrent.futures.ThreadPoolExecutor(2) as pool:
        results=list(pool.map(race,[6,7]))
    check(sorted(p.returncode for p in results)==[0,2],'race exits')
    check(any(json.loads(p.stdout)=={'error':409} for p in results),'race stale')
    # Browser uses actual ephemeral loopback endpoint, no external calls.
    bind_allowed=True
    with socket.socket() as probe:
        try:
            probe.bind(('127.0.0.1',0))
        except PermissionError:
            bind_allowed=False
    if not bind_allowed:
        probe_result=subprocess.run([APP,'serve',str(db)],capture_output=True,text=True,timeout=5)
        check(probe_result.returncode==2 and json.loads(probe_result.stdout)=={'error':5},'explicit bind failure')
        print('LIMIT: live HTTP tests skipped: sandbox denies loopback bind; server returned error 5.')
    else:
        server=subprocess.Popen([APP,'serve',str(db)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            url=server.stdout.readline().strip(); endpoint=urllib.parse.urlsplit(url)
            check(endpoint.hostname=='127.0.0.1' and endpoint.port>0 and endpoint.path=='/','URL')
            def http(method='GET',path='/',fields=None,origin=None,host=None,raw=None):
                c=http.client.HTTPConnection('127.0.0.1',endpoint.port,timeout=6)
                headers={'Host':host or endpoint.netloc}
                body=raw if raw is not None else urllib.parse.urlencode(fields or {})
                if method=='POST':
                    headers.update({'Origin':origin or url.rstrip('/'),'Content-Type':'application/x-www-form-urlencoded'})
                c.request(method,path,body=body if method=='POST' else None,headers=headers)
                r=c.getresponse(); status=r.status; content=r.read().decode(); c.close()
                return status,content
            status,page=http()
            check(status==200 and 'Study Rooms' in page and '9999-12-31' in page,'GET renders')
            forms=Forms(page).forms
            form=next(f for f in forms if f.get('action')=='reserve')
            check(set(form)=={'action','token','rev','id','room','date','start','end'},'exact reserve fields')
            check(len(form['token'])==32,'token length')
            form.update(id='100',room='5',date='2026-11-16',start='09:00',end='10:00')
            before=cli('list',db)
            for variant in ['token','origin','host','duplicate','unknown','missing']:
                bad=dict(form); opts={}
                if variant=='token': bad['token']='0'*32
                if variant=='origin': opts['origin']='http://example.invalid'
                if variant=='host': opts['host']='example.invalid'
                if variant=='duplicate': opts['raw']=urllib.parse.urlencode(bad)+'&room=6'
                if variant=='unknown': bad['extra']='x'
                if variant=='missing': del bad['end']
                http('POST','/action',bad,**opts)
                check(cli('list',db)==before,'refuse '+variant)
            status,success=http('POST','/action',form)
            check(status==200 and 'Saved to your workspace' in success,'browser reserve')
            check(cli('list',db)['revision']==before['revision']+1,'browser save revision')
            status,stale=http('POST','/action',form)
            check('could not be saved' in stale and 'value="2026-11-16"' in stale,'stale input retained')
            fresh=next(f for f in Forms(stale).forms if f.get('action')=='reserve')
            check(int(fresh['rev'])==cli('list',db)['revision'],'stale refresh')
            fresh.update(id='101',room='5',date='2026-11-16',start='09:30',end='10:30')
            _,overlap=http('POST','/action',fresh)
            check('could not be saved' in overlap and 'value="09:30"' in overlap,'overlap input retained')
            cancel=next(f for f in Forms(success).forms if f.get('action')=='cancel' and f.get('id')=='100')
            check(set(cancel)=={'action','token','rev','id'},'exact cancel fields')
            _,page=http('POST','/action',cancel)
            check('Saved to your workspace' in page and all(b['id']!='100' for b in cli('list',db)['bookings']),'browser cancel')
            check(http(path='/unknown')[0]==404,'unknown route')
        finally:
            server.terminate(); server.communicate(timeout=5)
    # Direct RF2 browser harness tests the same actions/rendering without a socket.
    def browser(body=None):
        args=[str(ROOT/'browser-test'),str(db)]
        if body is not None: args.append(body)
        p=subprocess.run(args,capture_output=True,text=True,timeout=10)
        check(p.returncode==0,'RF2 browser harness')
        return p.stdout
    page=browser()
    form=next(f for f in Forms(page).forms if f.get('action')=='reserve')
    check(set(form)=={'action','rev','token','id','room','date','start','end'},'direct exact form fields')
    check('9999-12-31' in page and '0001-01-01' in page,'readable dates')
    form.update(id='100',room='5',date='2026-11-16',start='09:00',end='10:00')
    before=cli('list',db)
    for kind in ['token','duplicate','unknown','missing','action']:
        bad=dict(form)
        if kind=='token': bad['token']='bad'
        if kind=='unknown': bad['extra']='x'
        if kind=='missing': del bad['date']
        if kind=='action': bad['action']='delete'
        body=urllib.parse.urlencode(bad)+('&room=6' if kind=='duplicate' else '')
        browser(body)
        check(cli('list',db)==before,'direct refuse '+kind)
    success=browser(urllib.parse.urlencode(form))
    check('Saved to your workspace' in success,'direct reserve')
    stale=browser(urllib.parse.urlencode(form))
    check('could not be saved' in stale and 'value="2026-11-16"' in stale,'direct stale retained')
    fresh=next(f for f in Forms(stale).forms if f.get('action')=='reserve')
    check(int(fresh['rev'])==cli('list',db)['revision'],'direct refreshed revision')
    fresh.update(id='101',room='5',date='2026-11-16',start='09:30',end='10:30')
    overlap=browser(urllib.parse.urlencode(fresh))
    check('could not be saved' in overlap and 'value="09:30"' in overlap,'direct overlap retains')
    cancel=next(f for f in Forms(success).forms if f.get('action')=='cancel' and f.get('id')=='100')
    check(set(cancel)=={'action','rev','token','id'},'direct exact cancel')
    cancelled_html=browser(urllib.parse.urlencode(cancel))
    check('Saved to your workspace' in cancelled_html and all(b['id']!='100' for b in cli('list',db)['bookings']),'direct cancel')
    # Exercise the real SDK HTTP framing/Host/Origin parser over a pipe.
    # This tests parser logic without claiming that a listening socket was tested.
    header_form=next(f for f in Forms(browser()).forms if f.get('action')=='reserve')
    header_form.update(id='200',room='7',date='2026-11-17',start='11:00',end='12:00')
    body=urllib.parse.urlencode(header_form)
    def request_bytes(host='127.0.0.1:12345', origin='http://127.0.0.1:12345', extra='', data=body):
        return ('POST /action HTTP/1.1\r\nHost: '+host+'\r\nOrigin: '+origin+'\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: '+str(len(data))+'\r\n'+extra+'\r\n'+data)
    for packet in [request_bytes(host='evil.invalid'),request_bytes(origin='http://evil.invalid'),request_bytes(extra='Host: 127.0.0.1:12345\r\n'),request_bytes(extra='Transfer-Encoding: chunked\r\n')]:
        before_headers=cli('list',db)
        result=subprocess.run([str(ROOT/'browser-test'),str(db),'http','pipe'],input=packet,capture_output=True,text=True,timeout=6)
        check(result.returncode==2,'HTTP parser refuses headers')
        check(cli('list',db)==before_headers,'bad HTTP headers do not write')
    result=subprocess.run([str(ROOT/'browser-test'),str(db),'http','pipe'],input=request_bytes(),capture_output=True,text=True,timeout=6)
    check(result.returncode==0 and 'Saved to your workspace' in result.stdout,'HTTP parser valid request via pipe')
    # Read-only MCP: malformed requests do not poison the connection.
    mcp=subprocess.Popen([APP,'mcp',str(db)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    def send(obj):
        mcp.stdin.write(json.dumps(obj)+'\n'); mcp.stdin.flush()
    def rpc(id,method,params=None):
        obj={'jsonrpc':'2.0','id':id,'method':method}
        if params is not None: obj['params']=params
        send(obj); return json.loads(mcp.stdout.readline())
    try:
        check(rpc(1,'initialize',{'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'selftest','version':'1'}})['result']['protocolVersion']=='2025-11-25','initialize')
        send({'jsonrpc':'2.0','method':'notifications/initialized'})
        listing=rpc(2,'tools/list',{})['result']['tools']
        check(len(listing)==1 and listing[0]['name']=='booking_list','one tool')
        check(listing[0]['inputSchema']=={'type':'object','properties':{},'additionalProperties':False},'schema')
        before=cli('list',db)
        result=rpc(3,'tools/call',{'name':'booking_list','arguments':{}})['result']
        check(result['structuredContent']==before and result['isError'] is False,'MCP state')
        for params in [{'name':'booking_list'},{'name':'booking_list','arguments':{'path':'elsewhere'}},{'name':'reserve','arguments':{}}]:
            check('error' in rpc(4,'tools/call',params),'bad tool params')
        check('error' in rpc(5,'unknown',{}),'unknown method')
        check('error' in rpc(50,'ping',{'unexpected':1}),'unknown ping args')
        for raw in ['{bad}', '{"jsonrpc":"2.0","id":6,"method":"ping","metho\\u0064":"ping"}', 'x'*65537]:
            mcp.stdin.write(raw+'\n'); mcp.stdin.flush()
            check('error' in json.loads(mcp.stdout.readline()),'bad JSON/bound')
            check('result' in rpc(7,'ping'),'connection recovered')
        send({'jsonrpc':'2.0','method':'tools/call','params':{'name':'booking_list','arguments':{}}})
        check(rpc(8,'ping')['id']==8,'notification silent')
        check(cli('list',db)==before,'MCP read only')
        with open(db,'rb') as locked:
            fcntl.flock(locked,fcntl.LOCK_EX|fcntl.LOCK_NB)
            check(rpc(9,'tools/call',{'name':'booking_list','arguments':{}})['result']['isError'] is True,'tool failure')
    finally:
        mcp.stdin.close(); mcp.wait(timeout=5)
    # Full live capacity using independent room/day intervals.
    capacity=pathlib.Path(tmp)/'capacity.db'; cli('init',capacity)
    for i in range(1,257):
        cli('reserve',capacity,i,i,1,'2026-01-01',f'{(i-1)//60:02}:{(i-1)%60:02}',f'{i//60:02}:{i%60:02}')
    check(len(cli('list',capacity)['bookings'])==256,'256 capacity persisted')
    cli('reserve',capacity,257,257,2,'2026-01-01','00:00','00:01',error=22)
    corrupt=pathlib.Path(tmp)/'corrupt.db'; corrupt.write_bytes(b'not a journal')
    cli('list',corrupt,error=9001)
print(f'PASS: {checks} assertions (CLI, native browser actions/rendering, MCP, locking, concurrency, capacity; HTTP conditional).')
