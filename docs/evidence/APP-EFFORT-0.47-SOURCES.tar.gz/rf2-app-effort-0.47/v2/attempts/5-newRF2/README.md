# Study Rooms in RF2

A local study-room reservation application with a native RF2 CLI, server-rendered browser interface, and read-only JSON-RPC MCP endpoint. Runtime source is `main.flow` and `study.flow`; no Python, JavaScript, shell or external service runs the application. `launch.json` selects `./app`.

## Build and launch

This supplied compiler/SDK targets macOS ARM64 using Darwin system calls. No packages or installation are needed. The delivered `app` is compiled and ad-hoc signed. To rebuild, remove the existing output first (the compiler refuses to overwrite files):

```sh
rm -f app
./rf2c main.flow app --compact --opt
codesign -s - app
```

Example, using a new file path:

```sh
./app init rooms.db
./app reserve rooms.db 1 1 2 2026-11-16 09:00 10:00
./app list rooms.db
./app cancel rooms.db 2 1
./app serve rooms.db
```

The reserve returns revision 2 with ID `"1"`, room 2, day 739936, start 540 and finish 600. Cancellation returns revision 3 with no bookings. `serve` prints its exact ephemeral `http://127.0.0.1:PORT/` endpoint as its first line and runs until terminated; open that address in a browser. Only the selected existing file is used. A failed bind returns an error instead of a URL.

CLI syntax:

```text
init DB
list DB
reserve DB REV ID ROOM DATE START END
cancel DB REV ID
serve DB
mcp DB
```

`init` exclusively creates a new regular file; existing paths refuse. Reopen the same path across processes. IDs are positive canonical decimal u64 strings, rooms 1–16. Dates are exact Gregorian YYYY-MM-DD (0001–9999); times exact HH:MM. End 24:00 is allowed. Intervals are half-open, same-day, and must have positive duration. Adjacent sessions are valid; same-room/same-day overlaps refuse. Revision comparisons happen inside SDK locking. Insertion order survives reopening; cancellation removes only its ID.

Successful CLI output has `revision`, SDK numeric `version`, and `bookings`. Errors print `{"error":CODE}` to stdout and exit 2. Invalid inputs use 22, existing IDs/paths 17, missing file/ID 404, overlap/stale revision 409, and busy locks 35. Other storage failures remain errors. At most 256 reservations can be current; the supplied collection refuses row 257 with 22. Journal-budget exhaustion uses 27. Corrupt data and uncertain saves remain distinct SDK errors (9001/9002); do not assume an uncertain write failed to persist.

## Browser

The app renders a responsive reservation list, readable dates/times, workspace statistics, labelled inputs, explicit cancellation buttons, light/dark CSS, keyboard focus styles and no external assets or scripts. Reserve and cancel forms use the saved revision and an unpredictable process-local token. Failed reserve values are escaped and retained; stale submissions reload current state. Errors and save confirmations appear on the page. GET `/` and POST `/action` are the only routes. The SDK validates HTTP framing, the actual Host and POST Origin; application parsing rejects unknown/duplicate fields, invalid tokens, incomplete action-specific forms and invalid values before storage.

This is a private loopback application, not an authentication system or public internet service. It does not convert timezones, support recurrence or automatically refresh an open tab. Refresh after another client changes the workspace. Avoid refreshing a successful POST to resubmit it; revision checks refuse duplicate stale submissions.

## Read-only MCP

Run `./app mcp rooms.db`. No banner is printed. Send one JSON-RPC object per line. Initialize with protocolVersion `2025-11-25`, capabilities `{}`, and clientInfo; then send `notifications/initialized`. `ping`, `tools/list`, and `tools/call` are supported. Exactly one tool is advertised:

```json
{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"booking_list","arguments":{}}}
```

It returns the selected file's state as `structuredContent` plus short text. No path arguments or write tools exist. Notifications do not invoke the callback. Invalid JSON, duplicate decoded keys, unknown methods/arguments and oversized lines refuse while allowing subsequent requests. Callback/storage errors use `isError:true`. This is the bounded legacy SDK subset, not a claim of broader MCP compatibility.

## SDK and storage limits

The supplied `lib/` modules provide the compiler-facing primitives, typed booking collection, Gregorian parsing, bounded writers, hash-chained snapshot journal, cooperative locks, HTTP framing/server and bounded MCP protocol. The application supplies command dispatch and validation, browser page construction, reserve/cancel orchestration, selected-workspace management and the read-only MCP callback. These libraries are building blocks, not the finished app.

The app configures a 4 MiB journal before first use. Each mutation appends a complete bounded snapshot; history is finite and there is no app compactor, recovery command or migration command. Keep backups; corruption is refused rather than repaired automatically. Storage requires a regular single-link file and refuses symlinks. SDK cooperative pathname/locking rules are not isolation from a hostile process running as the same user. Durability uses the SDK's sync operations, but power-loss/hardware behavior was not independently qualified. The implementation uses trusted raw pointers and native Darwin layouts and is not portable or fully memory-safe.

Local changes to the supplied MCP helper reject unknown top-level request fields, extra initialize parameters and nonempty ping parameters. The app trims the store serializer's final newline in its MCP callback so each response remains a single JSON-RPC line; CLI state retains its normal trailing newline.

## Self-tests and evidence

Python is used only as a standard-library test driver, not as runtime implementation. Build the native RF2 browser test harness, then run:

```sh
rm -f browser-test
./rf2c browser-test.flow browser-test --compact --opt
codesign -s - browser-test
python3 tests/selftest.py
```

The harness directly imports the application and exercises its real form actions/rendering. Its fixed test token and synthetic endpoint exist only in the separate `browser-test` binary; `app` uses random tokens and the actual bound endpoint. The driver checks CLI outputs/exit codes, persistence, calendar and u64 limits, overlaps/adjacency, stale revisions, cancellation order, locks, competing processes, 256 rows, browser form fields, rejected inputs, retained values, and MCP initialization/schema/results/errors/notification behavior and continued use after malformed or oversized requests. It also drives the SDK HTTP parser through stdin pipes to check Host, Origin, duplicate headers and framing rejection. On hosts permitting loopback binding it additionally runs live HTTP tests.

In this sandbox, binding 127.0.0.1 is denied with `Operation not permitted`; the app correctly returns error 5. Therefore live socket serving, browser interaction and visual appearance were not end-to-end verified here. Parser/action/rendering tests do not establish listener behavior. See `artifacts/selftest.txt` for the actual final assertion count and this explicit skip. Prior failures and corrections are retained in `artifacts/failure-*.txt` and `artifacts/HANDOVER.md`. No unseen acceptance tests, human trials, hardware qualification or performance claims are made.
