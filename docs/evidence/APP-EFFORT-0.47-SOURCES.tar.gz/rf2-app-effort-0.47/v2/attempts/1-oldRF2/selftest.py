"""Local black-box tests. Python is only a test driver; application runtime is RF2."""
import http.client as http_client
import datetime, fcntl, json, pathlib, re, socket, subprocess, tempfile, urllib.parse
ROOT = pathlib.Path(__file__).resolve().parent
checks = 0

def check(condition, message):
    global checks
    assert condition, message
    checks += 1

def run(*args, error=None):
    p = subprocess.run([str(ROOT/'app'), *map(str,args)], capture_output=True, text=True, timeout=10)
    data = json.loads(p.stdout)
    check(p.returncode == (0 if error is None else 2), (args,p.returncode,p.stdout,p.stderr))
    if error is not None: check(data == {'error': error}, (args,data,error))
    return data

with tempfile.TemporaryDirectory(prefix='selftest-', dir=ROOT) as td:
    db=pathlib.Path(td)/'rooms.db'
    run('list',db,error=404)
    state=run('init',db)
    check(state['revision']==1 and state['bookings']==[],state)
    run('init',db,error=17)
    state=run('reserve',db,1,18446744073709551615,1,'0001-01-01','00:00','01:00')
    check(state['bookings'][0]['day']==1,state)
    run('reserve',db,1,2,1,'0001-01-01','01:00','02:00',error=409)
    run('reserve',db,2,2,1,'0001-01-01','00:30','02:00',error=409)
    state=run('reserve',db,2,2,1,'0001-01-01','01:00','02:00')
    state=run('reserve',db,3,3,16,'9999-12-31','23:59','24:00')
    check(state['bookings'][-1]['day']==3652059,state)
    state=run('reserve',db,4,4,2,'0001-01-01','00:00','01:00')
    check([r['id'] for r in state['bookings']]==['18446744073709551615','2','3','4'],state)
    run('cancel',db,5,99,error=404)
    state=run('cancel',db,5,2)
    check([r['id'] for r in state['bookings']]==['18446744073709551615','3','4'],state)
    for id,room,date,start,end in [
        ('01','1','2024-01-01','09:00','10:00'),('0','1','2024-01-01','09:00','10:00'),
        ('18446744073709551616','1','2024-01-01','09:00','10:00'),
        ('5','0','2024-01-01','09:00','10:00'),('5','17','2024-01-01','09:00','10:00'),
        ('5','1','1900-02-29','09:00','10:00'),('5','1','2024-2-29','09:00','10:00'),
        ('5','1','0000-01-01','09:00','10:00'),('5','1','2024-01-01','24:00','24:00'),
        ('5','1','2024-01-01','9:00','10:00'),('5','1','2024-01-01','10:00','09:00'),
        ('5','1','2024-01-01','09:60','10:00'),('5','1','2024-01-01','09:00','24:01')]:
        run('reserve',db,6,id,room,date,start,end,error=22)
    check(run('list',db)==state,'rejected CLI changes modified state')
    state=run('reserve',db,6,5,1,'2000-02-29','09:00','10:00')
    check(state['bookings'][-1]['day']==datetime.date(2000,2,29).toordinal(),state)
    with open(db,'rb') as f:
        fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
        run('list',db,error=35)
    web=subprocess.Popen([str(ROOT/'app'),'serve',str(db)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    try:
        url=web.stdout.readline().strip()
        paired=None
        if url == '{"error":5}':
            web.wait(timeout=5)
            client,server=socket.socketpair()
            web=subprocess.Popen([str(ROOT/'http-test-app'),str(db)],stdin=server,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            server.close()
            harness_token=web.stdout.readline().strip()
            check(re.fullmatch('[a-f0-9]{32}',harness_token) is not None,'harness token')
            paired=client
            paired.settimeout(5)
            url='http://127.0.0.1:43210/'
            print('LIMIT: loopback bind denied; HTTP checks use socketpair with the actual RF2 request parser and dispatcher.')
        check(re.fullmatch(r'http://127\.0\.0\.1:\d+/',url) is not None,url)
        endpoint=urllib.parse.urlsplit(url)
        def http(method,path='/',data=None,headers=None):
            if paired:
                hs={'Host':endpoint.netloc, **(headers or {})}
                payload=(data or '').encode()
                if data is not None: hs['Content-Length']=str(len(payload))
                request=f'{method} {path} HTTP/1.1\r\n'+''.join(f'{k}: {v}\r\n' for k,v in hs.items())+'\r\n'
                paired.sendall(request.encode()+payload)
                response=http_client.HTTPResponse(paired)
                response.begin()
                status=response.status; body=response.read().decode()
                return status,body
            conn=http_client.HTTPConnection(endpoint.hostname,endpoint.port,timeout=5)
            conn.request(method,path,body=data,headers=headers or {})
            response=conn.getresponse(); body=response.read().decode(); status=response.status; conn.close()
            return status,body
        status,html=http('GET')
        check(status==200 and 'Study Rooms' in html and '2000-02-29' in html,'GET saved page')
        token=re.search(r'name=token value="([a-f0-9]{32})"',html).group(1)
        rev=re.search(r'name=rev value="(\d+)"',html).group(1)
        fields=dict(action='reserve',rev=rev,id='6',room='3',date='2024-02-29',start='09:00',end='10:00',token=token)
        headers={'Content-Type':'application/x-www-form-urlencoded','Origin':url[:-1]}
        status,html=http('POST','/action',urllib.parse.urlencode(fields),headers)
        check(status==200 and 'Saved to your workspace' in html,'web reserve')
        state=run('list',db)
        check(state['revision']==8 and state['bookings'][-1]['id']=='6',state)
        status,html=http('POST','/action',urllib.parse.urlencode(fields),headers)
        check('could not be saved' in html and 'value="8"' in html,'stale page refreshed')
        check('value="2024-02-29"' in html,'failed date retained')
        for body,hs in [
            (urllib.parse.urlencode({**fields,'rev':'8','token':'bad'}),headers),
            (urllib.parse.urlencode({**fields,'rev':'8'})+'&id=7',headers),
            (urllib.parse.urlencode({**fields,'rev':'8'})+'&unknown=1',headers),
            (urllib.parse.urlencode({**fields,'rev':'8'}),{**headers,'Origin':'http://evil.invalid'}),
            (urllib.parse.urlencode({**fields,'rev':'8'}),{**headers,'Host':'evil.invalid'}),
            (urllib.parse.urlencode({**fields,'rev':'8','date':'2024-02-30'}),headers),
            (urllib.parse.urlencode({**fields,'rev':'8','action':'cancel'}),headers),
        ]:
            http('POST','/action',body,hs)
            check(run('list',db)==state,'invalid browser request modified state')
        cancel=dict(action='cancel',rev='8',id='6',token=token)
        status,html=http('POST','/action',urllib.parse.urlencode(cancel),headers)
        check('Saved to your workspace' in html,'web cancel')
        check(run('list',db)['revision']==9,'web cancel persisted')
        check(http('GET','/unknown')[0]==404,'unknown route')
    finally:
        web.terminate(); web.wait(timeout=5)
    rpc=subprocess.Popen([str(ROOT/'app'),'mcp',str(db)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    def raw(line):
        rpc.stdin.write(line+'\n');rpc.stdin.flush()
        return json.loads(rpc.stdout.readline())
    def call(method,params=None,id=1):
        msg=dict(jsonrpc='2.0',id=id,method=method)
        if params is not None: msg['params']=params
        return raw(json.dumps(msg))
    try:
        answer=call('initialize',dict(protocolVersion='2025-11-25',capabilities={},clientInfo={'name':'test','version':'1'}))
        check(answer['result']['protocolVersion']=='2025-11-25',answer)
        rpc.stdin.write('{"jsonrpc":"2.0","method":"notifications/initialized"}\n');rpc.stdin.flush()
        check(call('ping')['result']=={},'ping')
        tools=call('tools/list')['result']['tools']
        check(len(tools)==1 and tools[0]['name']=='booking_list',tools)
        check(tools[0]['inputSchema']==dict(type='object',properties={},additionalProperties=False),tools)
        answer=call('tools/call',dict(name='booking_list',arguments={}))
        check(answer['result']['structuredContent']==run('list',db),answer)
        for params in [dict(name='booking_list'),dict(name='booking_list',arguments={'path':'x'}),dict(name='reserve',arguments={}),dict(name='booking_list',arguments=[])]:
            check(call('tools/call',params)['result']['isError'] is True,params)
        check('error' in raw('{bad'),'malformed JSON')
        check('error' in raw('{"jsonrpc":"2.0","id":1,"method":"ping","metho\\u0064":"tools/list"}'),'decoded duplicate key')
        check('error' in call('unknown'),'unknown method')
        check('error' in raw(' '*65537),'bounded line')
        check(call('ping',id='a\b\x00')['id']=='a\b\x00','escaped response ID')
        before=run('list',db)
        rpc.stdin.write('{"jsonrpc":"2.0","method":"tools/call","params":{"name":"reserve","arguments":{}}}\n');rpc.stdin.flush()
        check(call('ping')['result']=={},'connection survives notification and errors')
        check(run('list',db)==before,'MCP mutated state')
    finally:
        rpc.terminate();rpc.wait(timeout=5)
    # Cooperative revision race: exactly one of two processes can commit revision 9.
    racers=[subprocess.Popen([str(ROOT/'app'),'reserve',str(db),'9',str(id),'4','2024-01-01','09:00','10:00'],stdout=subprocess.PIPE,text=True) for id in (77,78)]
    results=[(p.communicate(timeout=10)[0],p.returncode) for p in racers]
    check(sorted(code for _,code in results)==[0,2],results)
    check(run('list',db)['revision']==10,'race revision')
    # A damaged journal must not be presented as an empty success.
    corrupt=pathlib.Path(td)/'corrupt.db';corrupt.write_bytes(b'broken')
    run('list',corrupt,error=9001)
print(f'PASS: {checks} local assertions (CLI, HTTP forms, MCP, locking and revision race).')
