# Study Rooms — RF2

A local reservation application with a JSON CLI, HTML browser interface and read-only JSON-RPC MCP interface. All application runtime code is RF2, compiled into the supplied native `app`. `launch.json` contains `["./app"]`.

## Build and run

Run from this directory on an Apple Silicon Mac:

```sh
# rf2c refuses to overwrite an existing output; remove only the generated app.
rm -f app
./rf2c main.flow app --opt
/usr/bin/codesign -s - app
./app init rooms.db
./app reserve rooms.db 1 1 2 2026-11-16 09:00 10:00
./app list rooms.db
./app cancel rooms.db 2 1
```

The reserve example returns revision 2 and booking `{"id":"1","room":2,"day":739936,"start":540,"finish":600}`. The SDK also supplies numeric `version:2`. A successful cancel returns revision 3 and an empty booking array. Each mutation must use the revision most recently read from the workspace.

```sh
./app serve rooms.db
```

Open the exact URL printed on the first line. The server chooses an ephemeral port on `127.0.0.1`; terminate with Control-C. The browser page displays current reservations, labelled inputs, explicit cancellation buttons and saved/error messages. Forms carry revision and process-local random CSRF values. Failed reservation values are retained when parsed; stale submissions reload saved state. CSS follows the system's light/dark preference, includes keyboard focus indicators, supports narrow screens and loads no external assets. End times use text input so `24:00` remains possible.

This execution sandbox denies listening socket binds (`EPERM`). Consequently the delivered browser listener could not be launched here. See testing below for the narrower HTTP coverage actually obtained. This is a local tool, with no authentication or public-server security claim.

## CLI contract

```text
./app init DB
./app list DB
./app reserve DB REV ID ROOM YYYY-MM-DD HH:MM HH:MM
./app cancel DB REV ID
./app serve DB
./app mcp DB
```

IDs are positive canonical decimal u64 strings, rooms are 1–16, dates span 0001-01-01 to 9999-12-31, and intervals are half-open on one calendar day. Adjacent reservations are allowed. `24:00` is an end time only. No timezone conversion or recurrence is performed. IDs remain strings in output, including values beyond JavaScript's exact integer range.

CLI failures exit 2 with an error JSON object. Invalid input is 22; existing creation paths or duplicate IDs are 17; missing paths/bookings are 404; stale revisions and overlap are 409; lock contention is 35. Other SDK/storage errors remain failures. Never assume an uncertain save error means a change definitely did not reach disk: reread the workspace.

## MCP

Configure an stdio client to run `./app mcp rooms.db` with this directory as working directory. There is no startup banner for an opened workspace. For example, send newline-delimited requests:

```json
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{},"clientInfo":{"name":"example","version":"1"}}}
{"jsonrpc":"2.0","method":"notifications/initialized"}
{"jsonrpc":"2.0","id":2,"method":"tools/list"}
{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"booking_list","arguments":{}}}
```

The sole tool is `booking_list`, with an empty object schema and no additional properties. It returns the saved state in `structuredContent` plus short text. `ping` is also supported. Notifications have no response and execute no tools. The parser rejects malformed JSON, invalid UTF-8 and duplicate decoded keys, including escaped duplicates. Lines are bounded to 65,536 bytes; overlong lines are drained and refused without closing the connection. No write, migration, execution, network or caller-supplied path tool exists. A missing/unreadable workspace causes startup failure; tool-time storage failures return `isError:true`.

## Storage and supplied SDK

`lib/store.flow`, `booking.flow`, `storage.flow`, `sha256.rf2`, `datetime.flow`, `forms.flow`, `transport.flow`, `json.flow`, `ui.flow`, `text.flow` and `io.flow` are supplied SDK foundations. `main.flow` implements the application commands, validation wiring, browser page, action admission and MCP protocol. It calls the same SDK storage/domain engine for every interface and does not replace the SDK journal format or locks.

The SDK stores an append-only, digest-chained native journal of complete snapshots. It uses cooperative shared/exclusive nonblocking file locks, revision comparisons, exclusive creation, fsync and parent-directory sync. It accepts regular single-link files and refuses final-component symlinks. This is not protection from a hostile same-user process renaming parent paths. The native implementation targets macOS ARM64 and Darwin system calls; it is not a portable Linux/Windows executable.

There are at most 256 current reservations, and the SDK journal has a 1 MiB lifetime limit. Repeated edits can exhaust the journal before 256 simultaneous reservations are reached. No compaction, migration, repair or recovery command is exposed. Corrupt or incomplete journals are errors, never empty successful workspaces. Keep independent backups; do not hand-edit codec bytes. Crash/power-loss durability was not tested.

SDK changes here simplify the shared page shell to remove unsupported navigation/appearance actions, allow the server to continue beyond the SDK's original 4,096-request stop, and escape all JSON control characters in returned string IDs. The CLI maps native missing-file errors to the required 404 code.

## Local self-tests

Python's standard library is used only to drive tests and generate a test harness; it is not an application runtime dependency.

```sh
python3 build-tests.py
python3 selftest.py
```

`build-tests.py` generates `http-test.flow` from the actual production source plus `http-harness.entry`, then compiles/signs `http-test-app`. When the production listener cannot bind, the tests connect this RF2 harness through a Unix socketpair. It runs the actual `form_request` and `app_dispatch` functions with a fixed synthetic loopback authority and a fresh random token. This exercises request parsing and response/form behavior, but does **not** verify TCP listening, ephemeral port selection, the accept loop or rendering in a real browser.

The delivered run passed **103 assertions** covering fresh-process persistence, ID/date/time boundaries, overlap/adjacency, room independence, cancellation order, rejected input without mutation, cooperative locks, a two-process revision race, browser reserve/cancel/stale handling and request rejection, MCP schema/read results/error recovery, decoded duplicate keys, oversized lines, escaped response IDs and corrupt storage refusal. Exact test output is in `artifacts/selftest-results.txt`. Actual development failures and remaining verification limits are recorded in `artifacts/HANDOVER.md`.

These are developer-run local checks. No external acceptance test, human usability trial, real-browser visual review, performance benchmark or universal platform qualification was performed.
