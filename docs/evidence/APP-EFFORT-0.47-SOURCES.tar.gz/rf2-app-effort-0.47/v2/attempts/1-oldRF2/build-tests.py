"""Rebuild the RF2-only socketpair harness from the production source."""
from pathlib import Path
import subprocess
root=Path(__file__).resolve().parent
source=(root/'main.flow').read_text().replace('fn main(argc,argv)','fn application_main(argc,argv)')
(root/'http-test.flow').write_text(source+'\n'+(root/'http-harness.entry').read_text())
target=root/'http-test-app'
if target.exists(): target.unlink()
subprocess.run(['./rf2c','http-test.flow','http-test-app','--opt'],cwd=root,check=True)
subprocess.run(['/usr/bin/codesign','-s','-','http-test-app'],cwd=root,check=True)
