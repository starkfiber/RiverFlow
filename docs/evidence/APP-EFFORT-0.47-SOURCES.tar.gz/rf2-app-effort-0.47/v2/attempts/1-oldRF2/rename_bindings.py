from pathlib import Path
p=Path('main.flow')
lines=p.read_text().splitlines()
import re
stack=[]; counter=0; output=[]
for line in lines:
    t=line.strip()
    if t.startswith('fn '): stack=[{}]
    if t.startswith('ok ') or t.startswith('err '):
        stack[-1]={}
        m=re.match(r'(\s*(?:ok|err) (?:own )?)(\w+)(.*)',line)
        old=m[2]; counter+=1; new=old+'_'+str(counter)
        stack[-1][old]=new
        line=m[1]+new+m[3]
    else:
        env={}
        for scope in stack: env.update(scope)
        # Replace identifiers only outside string literals.
        parts=re.split(r'("(?:\\.|[^"\\])*")',line)
        for i in range(0,len(parts),2):
            parts[i]=re.sub(r'\b\w+\b',lambda m:env.get(m[0],m[0]),parts[i])
        line=''.join(parts)
    output.append(line)
    if t.startswith(('handle ','if ','while ')): stack.append({})
    if t=='else': stack[-1]={}
    if t=='end' and stack: stack.pop()
p.write_text('\n'.join(output)+'\n')
