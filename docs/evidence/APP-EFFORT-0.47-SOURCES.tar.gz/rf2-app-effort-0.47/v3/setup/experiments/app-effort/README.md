# Application effort candidate0.47

This candidate addresses measured RF2 SDK construction friction. It is not a replacement for the published0.46 package yet.

- Statement-root `try` propagates matching scalar typed errors through ordinary cleanup.
- `lib/mcp.flow` supplies one reusable bounded legacy read-only tool dispatcher; application code supplies the selected-workspace callback.
- Exact API guide and source-extracted signatures reduce source hunting.
- Explicit journal and server budgets replace edits to implementation literals.
- Shared JSON escaping handles every ASCII control byte.

Prepare the compiler from the pinned0.46 source chain:

```sh
python3 experiments/app-effort/prepare.py /new/path/candidate
sh tools/build-program.sh /path/to/qualified0.46/rf2c /new/path/candidate/compiler.flow /new/path/build --opt
python3 experiments/app-effort/stage.py /new/path/app/lib
python3 experiments/app-effort/api-index.py /new/path/app/lib /new/path/app/SIGNATURES.md
```

Read [API.md](API.md) before authoring the entry. Stage supplies libraries, never a full Booking entry. [PROTOCOL.md](PROTOCOL.md) freezes the fresh oldRF2/newRF2/Python construction test. Six retained attempts are an exploratory SDK comparison, not general proof of lower token cost. `run.py` deliberately performs fresh Codex calls with actual JSONL usage; it is not a unit test or an automatic installation step. Read its protocol before explicitly running it.

New native tests: `RF2_TRY_COMPILER=/absolute/candidate/rf2c python3 tests/standalone/try_verify.py` and `app_effort_verify.py`. Qualification and comparison results will be recorded separately from the older historical experiment. Stable and public0.46 binaries remain unchanged.
