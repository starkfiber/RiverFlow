"""Local black-box checks. Python is test tooling only; app runtime is RF2."""
import datetime
import hashlib
import http.client
import json
import os
from pathlib import Path
import re
import select
import socket
import subprocess
import tempfile
import unittest
import urllib.parse

ROOT = Path(__file__).resolve().parent.parent
APP = str(ROOT / 'app')

class AppTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=ROOT / 'artifacts')
        self.db = str(Path(self.tmp.name) / 'rooms.db')
        self.call('init', self.db)

    def tearDown(self):
        self.tmp.cleanup()

    def call(self, *args, error=None):
        p = subprocess.run([APP, *map(str,args)], capture_output=True, timeout=15)
        self.assertEqual(p.returncode, 2 if error else 0, (args,p.stdout,p.stderr))
        obj = json.loads(p.stdout)
        if error:
            self.assertEqual(obj, {'error': error}, (args,obj))
        return obj

    def reserve(self, rev=1, id='1', room='1', date='2024-02-29', start='09:00', end='10:00', error=None):
        return self.call('reserve', self.db, rev, id, room, date, start, end, error=error)

    def digest(self):
        return hashlib.sha256(Path(self.db).read_bytes()).hexdigest()

    def test_cli_persistence_order_and_errors(self):
        self.call('init',self.db,error=17)
        self.call('list',self.db+'-missing',error=404)
        self.assertEqual(self.reserve()['bookings'],[{'id':'1','room':1,'day':datetime.date(2024,2,29).toordinal(),'start':540,'finish':600}])
        before=self.digest()
        self.reserve(rev=1,id='2',error=409)
        self.reserve(rev=2,id='2',start='09:30',error=409)
        self.reserve(rev=2,error=17)
        self.call('cancel',self.db,2,'99',error=404)
        self.assertEqual(before,self.digest())
        self.reserve(rev=2,id='2',start='10:00',end='11:00')
        self.reserve(rev=3,id='3',room='2')
        self.reserve(rev=4,id='4',date='2024-03-01')
        self.call('cancel',self.db,4,'1',error=409)
        result=self.call('cancel',self.db,5,'2')
        self.assertEqual([r['id'] for r in result['bookings']],['1','3','4'])
        self.assertEqual(result,self.call('list',self.db))

    def test_validation_and_extremes(self):
        before=self.digest()
        bads=[dict(id=x) for x in ['0','01','+1','-1','18446744073709551616','1x','']]
        bads += [dict(room=x) for x in ['0','17','01','18446744073709551616']]
        bads += [dict(rev=x) for x in ['0','01','18446744073709551616']]
        bads += [dict(date=x) for x in ['2023-02-29','1900-02-29','0000-01-01','10000-01-01','2024-2-29','2024-04-31','2024-01-00']]
        bads += [dict(start=x) for x in ['24:00','9:00','09:60','-1:00']]
        bads += [dict(end=x) for x in ['09:00','08:59','24:01','25:00']]
        for args in bads:
            with self.subTest(args=args): self.reserve(**args,error=22)
        self.assertEqual(before,self.digest())
        first=self.reserve(id='18446744073709551615',date='0001-01-01',start='00:00',end='24:00')
        self.assertEqual(first['bookings'][0]['day'],1)
        last=self.reserve(rev=2,id='2',date='9999-12-31',start='23:59',end='24:00')
        self.assertEqual(last['bookings'][1]['day'],3652059)
        self.call('cancel',self.db,3,'18446744073709551615')
        self.call('reserve',self.db,error=22)
        self.call('unknown',self.db,error=22)

    def test_capacity(self):
        for i in range(1,257):
            self.reserve(rev=i,id=str(i),room=str((i-1)%16+1),date=f'2024-03-{(i-1)//16+1:02d}')
        before=self.digest()
        self.reserve(rev=257,id='257',date='2025-01-01',error=27)
        self.assertEqual(before,self.digest())
        self.assertEqual(len(self.call('list',self.db)['bookings']),256)
        self.call('cancel',self.db,257,'1')
        self.reserve(rev=258,id='257',date='2025-01-01')

    def test_simultaneous_revision(self):
        args=[APP,'reserve',self.db,'1','1','1','2024-01-01','09:00','10:00']
        a=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        args[4]='2'
        b=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        ao=a.communicate(timeout=15)[0]; bo=b.communicate(timeout=15)[0]
        outcomes=[json.loads(ao),json.loads(bo)]
        self.assertEqual(sum('revision' in x for x in outcomes),1,outcomes)
        self.assertIn(next(x['error'] for x in outcomes if 'error' in x),(35,409))
        self.assertEqual(len(self.call('list',self.db)['bookings']),1)

    def test_corruption_refuses(self):
        data=bytearray(Path(self.db).read_bytes()); data[0]^=1
        Path(self.db).write_bytes(data)
        p=subprocess.run([APP,'list',self.db],capture_output=True,timeout=10)
        self.assertEqual(p.returncode,2)
        self.assertIn('error',json.loads(p.stdout))

    def test_http(self):
        self.http_checks(False)

    def test_http_socketpair(self):
        self.http_checks(True)

    def http_checks(self, socketpair):
        p=None if socketpair else subprocess.Popen([APP,'serve',self.db],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        try:
            if socketpair:
                url='http://127.0.0.1:12345/'
            else:
                probe=socket.socket()
                try:
                    probe.bind(('127.0.0.1',0))
                except PermissionError as e:
                    self.skipTest('Sandbox denies loopback bind: '+str(e))
                finally:
                    probe.close()
                self.assertTrue(select.select([p.stdout],[],[],10)[0], 'server did not announce URL')
                url=p.stdout.readline().decode().strip()
            self.assertRegex(url,r'^http://127\.0\.0\.1:\d+/$')
            port=urllib.parse.urlsplit(url).port
            origin=url[:-1]
            def request(method='GET',target='/',body=None,headers=None):
                if socketpair:
                    a,b=socket.socketpair()
                    child=subprocess.Popen([str(ROOT/'test-http'),self.db,str(b.fileno())],pass_fds=(b.fileno(),),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
                    b.close()
                    try:
                        nonce=child.stdout.readline().decode().strip()
                        self.assertRegex(nonce,r'^[0-9a-f]{32}$')
                        payload=(body or '').replace('TOKEN',nonce)
                        h={'Host':'127.0.0.1:12345'}
                        if method=='POST': h.update({'Origin':origin,'Content-Type':'application/x-www-form-urlencoded','Content-Length':str(len(payload.encode()))})
                        if headers: h.update(headers)
                        wire=f'{method} {target} HTTP/1.1\r\n'+''.join(f'{k}: {v}\r\n' for k,v in h.items())+'\r\n'+payload
                        a.sendall(wire.encode()); a.settimeout(10)
                        response=b''
                        while True:
                            chunk=a.recv(65536)
                            if not chunk: break
                            response+=chunk
                        child.wait(timeout=10)
                        self.assertEqual(child.returncode,0,child.stderr.read())
                        head,html=response.split(b'\r\n\r\n',1)
                        return int(head.split(b' ')[1]),html.decode()
                    finally:
                        a.close(); child.stdout.close(); child.stderr.close()
                        if child.poll() is None: child.kill();child.wait()
                c=http.client.HTTPConnection('127.0.0.1',port,timeout=8)
                h={'Origin':origin,'Content-Type':'application/x-www-form-urlencoded'}
                if headers: h.update(headers)
                c.request(method,target,body,h)
                r=c.getresponse(); result=(r.status,r.read().decode()); c.close(); return result
            status,page=request()
            self.assertEqual(status,200)
            for field in ['room','date','start','end','id']:
                self.assertIn('name="'+field+'"',page)
            token=re.search(r'name=token value="([^"]+)"',page).group(1)
            self.assertEqual(len(token),32)
            if socketpair: token='TOKEN'
            fields={'action':'reserve','rev':'1','id':'7','room':'3','date':'2024-02-29','start':'09:00','end':'10:00','token':token}
            before=self.digest()
            cases=[(dict(fields,token='x'),None),(dict(fields),{'Origin':'http://evil.invalid'}),(dict(fields,extra='x'),None)]
            for f,h in cases:
                status,_=request('POST','/action',urllib.parse.urlencode(f),h)
                self.assertIn(status,[400,403]); self.assertEqual(before,self.digest())
            for extra in ['&room=4','&%72oom=4','&token='+token]:
                status,_=request('POST','/action',urllib.parse.urlencode(fields)+extra)
                self.assertIn(status,[400,403]); self.assertEqual(before,self.digest())
            status,_=request(headers={'Host':'evil.invalid'})
            self.assertIn(status,[400,403]); self.assertEqual(before,self.digest())
            status,page=request('POST','/action',urllib.parse.urlencode(fields))
            self.assertEqual(status,200); self.assertIn('Saved to your workspace',page)
            self.assertIn('2024-02-29',page); self.assertIn('Cancel',page)
            self.assertEqual(self.call('list',self.db)['revision'],2)
            before=self.digest()
            fields.update(id='8',room='4')
            status,page=request('POST','/action',urllib.parse.urlencode(fields))
            self.assertEqual(status,200); self.assertIn('could not be saved',page)
            self.assertIn('value="8"',page); self.assertIn('name=rev value="2"',page)
            self.assertEqual(before,self.digest())
            fields.update(rev='2',room='3',start='09:30')
            status,page=request('POST','/action',urllib.parse.urlencode(fields))
            self.assertIn('could not be saved',page); self.assertIn('value="09:30"',page)
            self.assertEqual(before,self.digest())
            fields.update(room='<script>')
            status,page=request('POST','/action',urllib.parse.urlencode(fields))
            self.assertIn('&lt;script&gt;',page); self.assertNotIn('<script>',page)
            cancel={'action':'cancel','rev':'2','id':'7','token':token}
            status,page=request('POST','/action',urllib.parse.urlencode(cancel))
            self.assertEqual(status,200); self.assertIn('No reservations yet',page)
            self.assertEqual(self.call('list',self.db)['revision'],3)
            status,_=request('GET','/other'); self.assertEqual(status,404)
            status,_=request('POST','/action',urllib.parse.urlencode(dict(cancel,unknown='1')))
            self.assertIn(status,[400,403])
        finally:
            if p is not None:
                if p.poll() is None: p.terminate()
                p.communicate(timeout=10)

    def test_mcp(self):
        self.reserve()
        before=self.digest()
        p=subprocess.Popen([APP,'mcp',self.db],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        try:
            def send(obj):
                raw=obj if isinstance(obj,str) else json.dumps(obj)
                p.stdin.write(raw.encode()+b'\n'); p.stdin.flush()
            def recv():
                self.assertTrue(select.select([p.stdout],[],[],10)[0],'MCP response timeout')
                return json.loads(p.stdout.readline())
            send({'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'selftest','version':'1'}}})
            self.assertEqual(recv()['result']['protocolVersion'],'2025-11-25')
            send({'jsonrpc':'2.0','method':'notifications/initialized'})
            send({'jsonrpc':'2.0','id':2,'method':'tools/list'})
            tools=recv()['result']['tools']; self.assertEqual(len(tools),1)
            self.assertEqual(tools[0]['name'],'booking_list')
            self.assertEqual(tools[0]['inputSchema'],{'type':'object','properties':{},'additionalProperties':False})
            send({'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'booking_list','arguments':{}}})
            result=recv()['result']; self.assertFalse(result.get('isError',False))
            self.assertEqual(result['structuredContent'],self.call('list',self.db))
            cases=['{"jsonrpc":"2.0","id":4,"method":"ping","m\\u0065thod":"tools/list"}', '{bad',
                   {'jsonrpc':'2.0','id':5,'method':'unknown'},
                   {'jsonrpc':'2.0','id':6,'method':'tools/call','params':{'name':'booking_list','arguments':{'path':'x'}}},
                   {'jsonrpc':'2.0','id':7,'method':'tools/call','params':{'name':'cancel','arguments':{}}},
                   {'jsonrpc':'2.0','id':8,'method':'tools/call','params':{'name':'booking_list'}},
                   'x'*65537]
            for case in cases:
                send(case); response=recv(); self.assertTrue('error' in response or response.get('result',{}).get('isError'),response)
                send({'jsonrpc':'2.0','id':9,'method':'ping'}); self.assertIn('result',recv())
            send({'jsonrpc':'2.0','method':'tools/call','params':{'name':'booking_list','arguments':{}}})
            send({'jsonrpc':'2.0','id':10,'method':'ping'}); self.assertEqual(recv()['id'],10)
            self.assertEqual(before,self.digest())
            Path(self.db).unlink()
            send({'jsonrpc':'2.0','id':11,'method':'tools/call','params':{'name':'booking_list','arguments':{}}})
            self.assertTrue(recv()['result']['isError'])
        finally:
            p.stdin.close(); p.wait(timeout=10); p.stdout.close(); p.stderr.close()

if __name__=='__main__':
    unittest.main(verbosity=2)
