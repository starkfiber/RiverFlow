# Exact SDK signatures

Read API.md for contracts; these signatures are extracted from the supplied source.

## app-server.flow

```flow
fn app_policy()
fn app_request_budget(limit):IO
fn app_more(requests)
fn app_form(fd,allowed,values:FormValues):IO
fn app_serve():IO
```

## booking.flow

```flow
text CalendarTitle(IO,64)
record Booking(id:u64,room:u64,day:u64,start:u64,finish:u64)
collection Bookings(IO,256,Booking)
record CalendarMeta(title:own CalendarTitle)
record Calendar(meta:own CalendarMeta,bookings:own Bookings,revision:u64)
result CalendarReady(own Calendar,u64)
fn calendar_create():CalendarReady
fn booking_add(bookings:Bookings,requested:Booking):IO
```

## datetime.flow

```flow
fn date_leap(year)
fn date_month_days(year,month)
fn date_valid(key)
fn date_parse(p,n):IO
fn date_ordinal(key):IO
fn time_parse(p,n,allow_end):IO
fn time_overlap(a,b,c,d)
fn date_fixed(out:Writer,value,width)
fn date_format(out:Writer,key)
fn time_format(out:Writer,minute)
```

## forms.flow

```flow
array FormValues(u64,32)
fn form_request(fd)
fn form_token()
fn form_session():IO
fn form_key(p,n)
fn form_unquote(p,n,dst,cap,multiline):IO
fn form_parse(p,n,allowed,values:FormValues):IO
fn form_hidden(out:Writer,revision)
fn form_theme_cookie(p,n)
```

## io.flow

```flow
result IO(u64,u64)
record Writer(data:u64,capacity:u64,used:u64,error:u64)
fn io_size(p)
fn io_copy(dst,src,n)
fn io_regular(path,data,limit):IO
fn io_write_all(fd,p,n):IO
fn writer_reset(out:Writer)
fn writer_bytes(out:Writer,p,n)
fn writer_text(out:Writer,p)
fn writer_number(out:Writer,value)
```

## json.flow

```flow
fn j_slen(p)
fn j_state()
fn j_fail(code)
fn j_whitespace(c)
fn j_skip(p, endp)
fn j_hex(c)
fn j_digit(c)
fn j_token(i)
fn j_json_string(t)
fn j_json_value(depth)
fn j_digits_end(p, endp)
fn j_json_number_tail(t, start, p, endp, idx)
fn j_same_string(a, b)
fn j_matches(t, text)
fn j_field(t, name)
fn j_utf8(p, n)
fn j_number_u32(t)
fn j_json_parse(p, n)
```

## mcp.flow

```flow
fn mcp_bytes(p,n)
fn mcp_say(text)
fn mcp_number(n)
fn mcp_quote(p,n)
fn mcp_line()
fn mcp_id_valid(id)
fn mcp_object(t,names)
fn mcp_equal(a,b,n)
fn mcp_id_capture(id)
fn mcp_reply()
fn mcp_error(code,message)
fn mcp_compact(p,n)
fn mcp_tool_result()
fn mcp_request(bytes,server,version,tool,description)
fn mcp_serve(server,version,tool,description):IO
```

## output.rf2

```flow
fn output_length(p)
fn output_bytes(fd,p,n)
fn output_text(p)
fn output_number(n)
fn output_error(n)
```

## sha256.rf2

```flow
fn rotate(v, n)
fn sha256_software(src, n)
fn sha256_initialize()
fn sha256_accelerated(src, n)
fn sha256_arm_available()
fn sha256(src,n)
```

## storage.flow

```flow
fn storage_open(path,create,writing):IO
fn storage_read(fd,data,limit):IO
fn storage_sync(fd)
fn storage_truncate(fd,size)
fn storage_append(fd,data,n,previous):IO
fn storage_checksum(p,n)
```

## store.flow

```flow
record StoreState(revision:u64,bytes:u64,version:u64,tail:u64,digest:u64,committed:u64,result:u64)
record StoreRequest(action:u64,expected:u64,id:u64,room:u64,day:u64,start:u64,finish:u64)
result StoredRows(own Bookings,u64)
fn store_policy()
fn store_limit()
fn store_configure(limit):IO
fn store_data()
fn store_equal(a,b,n)
fn store_schema(version)
fn store_magic(version)
fn store_prefix_number(frame,remaining,offset,value)
fn store_incomplete(frame,remaining,state:StoreState)
fn store_decode(data,n,state:StoreState):StoredRows
fn store_snapshot(fd,rows:Bookings,state:StoreState,version):IO
fn store_json(rows:Bookings,state:StoreState,out:Writer)
fn store_apply(fd,rows:Bookings,request:StoreRequest,state:StoreState):IO
fn store_locked(fd,request:StoreRequest,state:StoreState,out:Writer):IO
fn store_parent_sync(path):IO
fn store_abort_creation(path,fd):IO
fn store_execute(path,request:StoreRequest,out:Writer,state:StoreState):IO
fn store_view(path,state:StoreState):StoredRows
fn store_operation(path,request:StoreRequest,out:Writer):IO
```

## text.flow

```flow
array TextPrefix(u64,256)
record TextInfo(status:u64,scalars:u64,lines:u64,words:u64)
record TextMatches(status:u64,count:u64,first:u64,last:u64)
record TextSpan(start:u64,length:u64)
record TextCursor(next:u64,line:u64,done:u64,status:u64)
fn text_space(c)
fn text_equal(a,n,b,m)
fn text_trim(p,n,out:TextSpan)
fn text_measure(p,n,out:TextInfo)
fn text_fold(c,fold)
fn text_search(p,n,q,m,fold,prefix:TextPrefix,out:TextMatches)
fn text_line(p,n,index,out:TextSpan)
fn text_next_line(p,n,cursor:TextCursor,out:TextSpan)
fn text_hex(c)
fn text_parse_u64(p,n,maximum):IO
fn text_decode(p,n,dst,cap):IO
fn text_html(p,n,dst,cap):IO
fn writer_html(out:Writer,p,n)
fn writer_json(out:Writer,p,n)
```

## transport.flow

```flow
fn globals()
fn size(p)
fn copy(dst,src,n)
fn same(p,n,text)
fn key(p,n,text)
fn find(p,n,text,count)
fn reset_output()
fn text(p)
fn decimal(value)
fn unsigned(p,n,max)
fn elapsed(start)
fn wait_ready(fd,event,start)
fn receive(fd,p,n,start)
fn send(fd,p,n,start)
fn respond(fd,status,mime)
fn finish_connection(fd)
```

## ui.flow

```flow
fn ui_begin(out:Writer,title)
fn ui_end(out:Writer)
fn ui_stat(out:Writer,label,value,detail)
fn ui_notice(out:Writer,error,saved)
fn ui_input(out:Writer,name,label,kind,value,bytes,hint)
fn ui_action(out:Writer,revision,action,label)
fn ui_response(fd,out:Writer,status)
fn app_bad(fd,status)
fn ui_date_key(ordinal)
fn ui_next_id(rows:Bookings)
fn ui_css()
fn ui_theme_class()
fn ui_appearance(out:Writer)
```
