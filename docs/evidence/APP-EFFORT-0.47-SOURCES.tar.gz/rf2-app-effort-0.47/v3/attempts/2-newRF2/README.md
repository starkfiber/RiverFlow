# Study Rooms — native RF2 application

A local reservation workspace for 16 study rooms, with a CLI, browser interface and read-only MCP server. Runtime application code is RF2: `main.flow` is the executable entry and `study.flow` implements commands, validation, forms, HTML rendering and the MCP callback. `launch.json` selects `["./app"]`.

## Build and run

The supplied compiler targets this Mac's ARM64/Darwin environment. No packages or network assets are needed.

```sh
# The compiler refuses to overwrite an existing output. Preserve it before rebuilding:
mv app artifacts/app-previous
./rf2c main.flow app --compact --opt
codesign -s - app
```

On a clean source copy without `app`, omit the `mv` command. Choose a new backup filename if it already exists. The delivered executable is already compiled and ad-hoc signed.

Working example (use a workspace filename that does not exist):

```sh
./app init example.db
./app reserve example.db 1 1 2 2026-11-16 09:00 10:00
./app list example.db
./app cancel example.db 2 1
```

Initialization returns revision 1. Each successful mutation advances the revision; use the latest saved revision for the next command. For example, the reserve above returns revision 2 and a booking with ID `"1"`, room `2`, day ordinal `739936`, start `540`, and finish `600`. JSON also includes the SDK's numeric `version` field. CLI failures print `{"error":CODE}` and exit 2. Missing files map to 404; invalid numeric syntax/range maps to 22. Other storage failures remain failures.

```sh
./app serve example.db
```

When permitted to bind a local socket, this prints its exact ephemeral `http://127.0.0.1:PORT/` URL first and serves until terminated. Open that URL in a browser. The page has labelled fields, explicit cancellation buttons, current revision, saved reservations, keyboard focus styles, responsive layout and system light/dark colors. Dates are `YYYY-MM-DD`; times are `HH:MM`. The end may be `24:00`. A failed reservation retains input, shows an explanation and reloads the current saved revision. IDs are editable positive canonical decimal u64 values. Host/POST Origin checks and unpredictable process-local CSRF tokens protect the local form endpoint. This is a local app, with no public-server or authentication claim.

```sh
./app mcp example.db
```

This runs newline-delimited JSON-RPC on stdin/stdout, without a banner. It supports legacy protocol `2025-11-25`, initialize, initialized notifications, ping, tools/list and tools/call. Exactly one read-only tool, `booking_list`, accepts an explicit empty arguments object. For example, after initialization:

```json
{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"booking_list","arguments":{}}}
```

It returns saved state as `structuredContent` plus short text. There are no path or mutation arguments. Malformed/duplicate-key requests and unsupported calls are rejected; callback storage failures produce `isError:true` tool results.

## Storage and SDK boundaries

The supplied `lib/` SDK implements booking ownership/domain operations, Gregorian/time parsing, bounded durable journal storage, locking and revisions, HTTP framing/form admission, and the restricted MCP protocol. The app uses those APIs rather than rewriting or bypassing storage. The MCP callback performs only a list operation on the launch-selected path. Browser operations use the same storage API as CLI operations.

Workspaces hold at most 256 current rows, in insertion order. Cancellation removes the exact ID. Same-room/day intervals are half-open: adjacent bookings are valid and overlap is refused. Dates span 0001-01-01 through 9999-12-31. No timezone conversion or recurrence is implemented.

Every process configures a 4 MiB maximum journal. This is bounded snapshot history, not an unbounded database or compactor: a long mutation history can reach the byte limit before the row limit. Preserve the original journal on corruption or uncertain saves; refresh before retrying, since an uncertain write may have committed. Do not hand-edit journal bytes or hashes. No migration, backup UI, cloud service or multi-machine storage claim is made.

RF2's supplied SDK uses trusted raw system pointers and native Darwin APIs. The executable is not portable to Linux, Windows or Intel Macs. Source portability and full memory safety have not been demonstrated. The server retains the SDK's eight-connection and bounded request/deadline limits; the app explicitly removes its default total-request-count cap.

## Actual verification

```sh
# Build the optional socket-pair test entry (new output path required):
./rf2c test-http.flow test-http --compact --opt
codesign -s - test-http
python3 tests/selftest.py
```

Python is standard-library test tooling only; it is not part of the application runtime. `test-http.flow` is a test-only entry that imports the actual app implementation and exercises the actual SDK HTTP parser/dispatcher over inherited Unix socket pairs. It generates a real session token per request and sets a fixed test endpoint; it is not selected by `launch.json`.

Latest recorded run: **8 test groups, 7 passed, 1 skipped** (`artifacts/selftest-second.log`). Checks cover fresh-process persistence, insertion order, cancellation, duplicate IDs, overlap and adjacency, independent rooms/days, stale revisions, numeric/date/time boundaries, u64 maximum ID, full-day/end-of-day reservations, 256-row capacity, a simultaneous revision race, corrupt storage, MCP protocol errors/recovery/notifications/read-only behavior, and HTTP form operations/security/retained input over socket pairs.

**Live loopback serving could not be tested in this execution sandbox.** The initial HTTP test received `{"error":5}` from serve; an independent Python socket bind returned `PermissionError: Operation not permitted`. The later suite explicitly skips that live transport test in this environment and runs the socket-pair checks. No actual browser rendering, live listener lifecycle, or external acceptance/grader result is claimed. Run the suite in an environment allowing loopback bind to exercise the live HTTP group.

Failures are retained: `build-failure-01.log` (parameter limit), `build-failure-02.log` (record placement), `build-failure-03.log` (explicit result return), `build-failure-04.log` (compiler refuses existing output), and `artifacts/selftest-first.log` (denied live bind). The source compiler errors were corrected before the successful build. `build.log` and `artifacts/build-test-http.log` record successful native builds.
