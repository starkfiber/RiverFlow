# Study Rooms

A Python standard-library application for reserving 16 local study rooms. Includes a JSON CLI, responsive browser interface with light/dark styles, and read-only newline JSON-RPC MCP access. Runtime entry: `app.py`; machine-readable entry: `launch.json`.

## Build and launch

Run from this directory with Python 3.9 or newer. No installation or third-party dependencies are needed. The application is interpreted; the build check compiles bytecode:

```sh
PYTHONPYCACHEPREFIX="$PWD/.pycache" python3 -m py_compile app.py booking_sdk.py mcp_sdk.py test_app.py
```

A working CLI example using a new filename:

```sh
python3 app.py init my-rooms.sqlite
python3 app.py reserve my-rooms.sqlite 1 1 2 2026-11-16 09:00 10:00
python3 app.py list my-rooms.sqlite
python3 app.py cancel my-rooms.sqlite 2 1
```

The reservation command returns:

```json
{"revision":2,"bookings":[{"id":"1","room":2,"day":739936,"start":540,"finish":600}]}
```

`init` refuses existing paths. Always supply the last saved revision for writes. Conflicts require reading the current list and reviewing before retrying. Each successful write increments revision; cancellation preserves the order of remaining rows. IDs are positive canonical decimal strings through 18446744073709551615. Dates are exact Gregorian YYYY-MM-DD, times exact HH:MM. End 24:00 is supported. Intervals are half-open, so adjacent sessions are allowed. Maximum current reservations: 256.

CLI command forms:

```text
init DB
list DB
reserve DB REV ID ROOM DATE START END
cancel DB REV ID
serve DB
mcp DB
```

Failures return exit status 2 and an `error` JSON object. Public codes include invalid 22, exists 17, missing 404, conflict/stale 409, busy 35; other storage failures retain numeric error codes. Success never precedes the SDK transaction result.

## Browser

```sh
python3 app.py serve my-rooms.sqlite
```

Open the exact first-line `http://127.0.0.1:PORT/` URL. The server uses an ephemeral loopback port and the selected existing workspace only. Stop with Ctrl-C. The page has labelled reservation inputs, a saved reservation table, explicit cancellation buttons and a refresh link. Enter 24:00 as plain text when needed. Failed reserve values are retained; stale forms show refreshed saved state. POSTs require the exact endpoint Host and Origin, the current revision and a process-local unpredictable CSRF token. Duplicate/unknown fields and malformed forms refuse without a write. No external assets or scripts are loaded.

## MCP

```sh
python3 app.py mcp my-rooms.sqlite
```

Only JSON-RPC goes to stdout. Send one JSON object per newline. Initialize with protocol `2025-11-25`, clientInfo name/version and capabilities, then send `notifications/initialized`. Exactly one tool is advertised: `booking_list`, with no parameters. Call using explicit empty arguments:

```json
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{},"clientInfo":{"name":"example","version":"1"}}}
{"jsonrpc":"2.0","method":"notifications/initialized"}
{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}
{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"booking_list","arguments":{}}}
```

The tool returns the selected workspace in structuredContent and short text content. Storage failures return isError:true. Invalid protocol arguments return JSON-RPC errors. Ping is supported. Duplicate decoded JSON keys, oversized lines (over 65536 bytes), malformed JSON, unknown tools and supplied tool arguments refuse; subsequent valid requests remain usable. No mutation or arbitrary-path tool exists.

## Storage and SDKs

`booking_sdk.py` is the supplied unchanged domain/storage SDK. It uses SQLite transactions, FULL synchronous writes, revision checks and immediate write locks. All application operations call it. The app normalizes SDK missing-path code 2 to 404 and capacity code 27 to invalid 22. `mcp_sdk.py` is the supplied unchanged generic protocol helper; the app supplies its selected-path, read-only callback. Neither SDK is a complete application frontend.

The workspace is an SQLite file, not an RF2 journal. Keep it on a local writable filesystem with SQLite locking support and room for transient journal files. Avoid editing its tables manually. For portable copies, stop users/writers first and copy the database safely; no schema migration or recovery utility is supplied. This is a local single-workspace tool, with no public-server authentication, hostile same-user path isolation, timezone conversion or recurring bookings. The server is synchronous and intended for local use, not production internet traffic.

## Verification and limits

```sh
PYTHONPYCACHEPREFIX="$PWD/.pycache" python3 -m unittest -v test_app
```

Seven tests passed in the final run. Coverage includes fresh-process persistence, exact state shapes, insertion order, adjacency/overlap, different rooms/days, stale revisions, ID/date/time limits, capacity, SQLite busy/corrupt failures, concurrent writers, HTTP handlers, and MCP parsing/recovery/tool errors. Tests create temporary databases inside `artifacts/` and remove them.

**Live HTTP serving was not verified:** this execution sandbox denies binding a loopback socket (`PermissionError`, errno 1). The HTTP test first attempts a real server; under this denial it exercises the actual request handlers in process with synthetic HTTP headers/body streams and a nonbinding server stub. That verifies application responses and writes, not socket transport or visual rendering. No browser visual trial was performed.

Initial build failed because macOS Python selected a cache outside the workspace. The documented local cache fixes that. The initial HTTP test failed on the socket restriction; a later test failed when improved OS-error handling changed the startup diagnostic to JSON, and the fallback detection was corrected. Original failures are retained in `artifacts/build-initial-failure.txt`, `artifacts/test-run-1.txt`, `artifacts/test-run-3.txt` and `artifacts/http-bind-limit.txt`. Final evidence is `artifacts/test-final.txt`, `artifacts/build-final.txt` and `artifacts/example-output.txt`. No external grader was run and no unseen acceptance result is claimed.
