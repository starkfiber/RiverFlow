"""Local acceptance-style checks, independent of any external grader."""
import datetime
import contextlib
import io
from email.message import Message
from unittest.mock import patch
import app
import http.client
import json
import os
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from urllib.parse import urlencode, urlsplit
from booking_sdk import execute

ROOT = Path(__file__).resolve().parent
ENV = dict(os.environ, PYTHONPYCACHEPREFIX=str(ROOT / '.pycache'))


class AppTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=ROOT / 'artifacts')
        self.db = str(Path(self.temp.name) / 'rooms.sqlite')
        self.cli('init', self.db)

    def tearDown(self):
        self.temp.cleanup()

    def cli(self, *args, error=None):
        result = subprocess.run([sys.executable, 'app.py', *args], cwd=ROOT, env=ENV,
                                capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 2 if error else 0, result.stderr + result.stdout)
        self.assertEqual(result.stderr, '')
        data = json.loads(result.stdout)
        if error:
            self.assertEqual(data, {'error': error})
        return data

    def reserve(self, revision, id='1', room='1', day='2026-11-16', start='09:00', end='10:00', error=None):
        return self.cli('reserve', self.db, str(revision), id, room, day, start, end, error=error)

    def test_cli_persistence_and_conflicts(self):
        self.cli('init', self.db, error=17)
        self.assertEqual(self.cli('list', self.db), {'revision':1, 'bookings':[]})
        first = self.reserve(1)
        self.assertEqual(first['bookings'][0], dict(id='1',room=1,day=datetime.date(2026,11,16).toordinal(),start=540,finish=600))
        self.assertEqual(first, self.cli('list', self.db))
        self.reserve(2, id='2', start='09:59', end='11:00', error=409)
        self.reserve(1, id='2', error=409)
        self.reserve(2, error=17)
        self.reserve(2, id='2', start='10:00', end='11:00')
        self.reserve(3, id='3', room='2')
        self.reserve(4, id='4', day='2026-11-17')
        self.cli('cancel', self.db, '5', '999', error=404)
        state = self.cli('cancel', self.db, '5', '2')
        self.assertEqual([b['id'] for b in state['bookings']], ['1','3','4'])
        self.cli('cancel', self.db, '5', '1', error=409)
        self.assertEqual(state, self.cli('list', self.db))
        self.cli('list', self.db + '.missing', error=404)
        self.assertFalse(Path(self.db + '.missing').exists())

    def test_concurrent_revision_and_corrupt_storage(self):
        command = [sys.executable, 'app.py', 'reserve', self.db, '1']
        first = subprocess.Popen(command + ['1','1','2026-11-16','09:00','10:00'], cwd=ROOT,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        second = subprocess.Popen(command + ['2','2','2026-11-16','09:00','10:00'], cwd=ROOT,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        outputs=[]
        for process in (first,second):
            out,err=process.communicate(timeout=10)
            self.assertEqual(err,'')
            outputs.append((process.returncode,json.loads(out)))
        self.assertEqual(sum(code==0 for code,data in outputs),1)
        refused=[data for code,data in outputs if code!=0][0]
        self.assertIn(refused['error'],[35,409])
        self.assertEqual(self.cli('list',self.db)['revision'],2)
        corrupt=str(Path(self.temp.name)/'corrupt.sqlite')
        Path(corrupt).write_bytes(b'not a SQLite database')
        self.cli('list',corrupt,error=9001)

    def test_validation_boundaries(self):
        for kwargs in [dict(id='0'),dict(id='01'),dict(id='18446744073709551616'),dict(id='١'),
                       dict(room='0'),dict(room='17'),dict(day='2026-2-01'),dict(day='2025-02-29'),
                       dict(day='0000-01-01'),dict(start='9:00'),dict(start='24:00'),dict(end='24:01'),
                       dict(end='09:00'),dict(start='10:01'),dict(start='09:60')]:
            with self.subTest(kwargs=kwargs):
                self.reserve(1, error=22, **kwargs)
        self.reserve(1,id='18446744073709551615',room='16',day='0001-01-01',start='00:00',end='24:00')
        self.reserve(2,id='2',day='9999-12-31',start='23:59',end='24:00')
        self.cli('cancel', self.db, '0', '2', error=22)
        self.cli('unknown', self.db, error=22)
        self.cli('reserve', self.db, error=22)

    def test_capacity_and_busy(self):
        for index in range(256):
            execute(self.db,'reserve',expected=index+1,id=str(index+1),room=1,day=index+1,start=0,finish=1)
        self.reserve(257,id='257',error=22)
        self.assertEqual(len(self.cli('list',self.db)['bookings']),256)
        connection = sqlite3.connect(self.db, isolation_level=None)
        try:
            connection.execute('BEGIN EXCLUSIVE')
            self.cli('cancel',self.db,'257','1',error=35)
        finally:
            connection.rollback(); connection.close()

    def test_http(self):
        proc = subprocess.Popen([sys.executable,'app.py','serve',self.db], cwd=ROOT,env=ENV,
                                stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            url = proc.stdout.readline().strip()
            fallback = not url or url == '{"error":1}'
            if fallback:
                print('HTTP: socket binding denied; exercising handlers in process.', file=sys.stderr)
                diagnostic = proc.stderr.read()
                if not url:
                    self.assertIn('PermissionError', diagnostic)
                    (ROOT / 'artifacts/http-bind-limit.txt').write_text(diagnostic)
                else:
                    self.assertEqual(proc.wait(timeout=5), 2)
                class NoSocketServer:
                    def __init__(self, address, handler):
                        self.server_address = ('127.0.0.1', 45678)
                        self.handler = handler
                        self.endpoint = ''
                        self.handlers = []
                    def serve_forever(self): pass
                    def server_close(self): pass
                fake = None
                def make_server(address, handler):
                    nonlocal fake
                    fake = NoSocketServer(address, handler)
                    return fake
                output = io.StringIO()
                with patch.object(app, 'HTTPServer', make_server), contextlib.redirect_stdout(output):
                    app.browser(self.db)
                url = output.getvalue().strip()
            self.assertRegex(url,r'^http://127\.0\.0\.1:[0-9]+/$')
            parsed = urlsplit(url)
            def request(method, path='/', body=None, headers=None):
                if fallback:
                    instance = object.__new__(fake.handler)
                    instance.server = fake
                    instance.command = method
                    instance.path = path
                    instance.request_version = 'HTTP/1.1'
                    instance.requestline = method + ' ' + path + ' HTTP/1.1'
                    instance.close_connection = False
                    instance.headers = Message()
                    supplied = dict(headers or {})
                    supplied.setdefault('Host',parsed.netloc)
                    payload = (body or '').encode()
                    if body is not None:
                        supplied.setdefault('Content-Length',str(len(payload)))
                    for key,value in supplied.items():
                        instance.headers[key]=value
                    instance.rfile=io.BytesIO(payload)
                    instance.wfile=io.BytesIO()
                    getattr(instance,'do_'+method)()
                    response=instance.wfile.getvalue().decode()
                    head,content=response.split('\r\n\r\n',1)
                    return int(head.split()[1]),content
                con = http.client.HTTPConnection('127.0.0.1',parsed.port,timeout=5)
                try:
                    con.request(method,path,body=body,headers=headers or {})
                    res=con.getresponse(); return res.status,res.read().decode()
                finally:
                    con.close()
            status, body = request('GET')
            self.assertEqual(status,200)
            for label in ['Reservation ID','Room (1–16)','Date (YYYY-MM-DD)','Start (HH:MM)','End (HH:MM']:
                self.assertIn(label,body)
            token=re.search(r'name="token" value="([a-f0-9]+)"',body)[1]
            fields=dict(action='reserve',rev='1',id='1',room='1',date='2026-11-16',start='09:00',end='10:00',token=token)
            headers={'Origin':url.rstrip('/'),'Content-Type':'application/x-www-form-urlencoded'}
            before=Path(self.db).read_bytes()
            for data, hdr in [(urlencode(dict(fields,token='wrong')),headers),
                              (urlencode(fields)+'&room=2',headers),
                              (urlencode(fields)+'&unknown=1',headers),
                              (urlencode(fields),dict(headers,Origin='http://evil.invalid')),
                              (urlencode(fields),{'Content-Type':headers['Content-Type']}),
                              (urlencode(fields)+'&%72oom=2',headers),
                              ('action=%ZZ',headers),
                              (urlencode(dict(fields,token='非ASCII')),headers)]:
                with self.subTest(data=data,hdr=hdr):
                    status,body=request('POST','/action',data,hdr)
                    self.assertIn(status,[400,403]); self.assertEqual(Path(self.db).read_bytes(),before)
            self.assertEqual(request('GET',headers={'Host':'evil.invalid'})[0],400)
            status,body=request('POST','/action',urlencode(fields),headers)
            self.assertEqual(status,200); self.assertIn('Reservation saved.',body)
            stale=dict(fields,id='2',start='10:00',end='11:00')
            status,body=request('POST','/action',urlencode(stale),headers)
            self.assertIn('stale',body); self.assertIn('Revision 2',body)
            self.assertIn('value="11:00"',body)
            overlap=dict(stale,rev='2',start='09:30')
            self.assertIn('overlaps',request('POST','/action',urlencode(overlap),headers)[1])
            cancel=dict(action='cancel',rev='2',id='1',token=token)
            self.assertIn('cancelled',request('POST','/action',urlencode(cancel),headers)[1])
            self.assertEqual(self.cli('list',self.db),dict(revision=3,bookings=[]))
            invalid=dict(fields,rev='3',id='<script>alert(1)</script>')
            status,body=request('POST','/action',urlencode(invalid),headers)
            self.assertEqual(status,400)
            self.assertIn('&lt;script&gt;',body)
            self.assertNotIn('<script>',body)
            self.assertEqual(self.cli('list',self.db),dict(revision=3,bookings=[]))
        finally:
            proc.terminate(); proc.wait(timeout=5)
            proc.stdout.close(); proc.stderr.close()

    def test_mcp(self):
        messages=[
            dict(jsonrpc='2.0',id=1,method='initialize',params=dict(protocolVersion='2025-11-25',capabilities={},clientInfo=dict(name='tests',version='1'))),
            dict(jsonrpc='2.0',method='notifications/initialized'),
            dict(jsonrpc='2.0',id=2,method='tools/list',params={}),
            dict(jsonrpc='2.0',id=3,method='tools/call',params=dict(name='booking_list',arguments={})),
            dict(jsonrpc='2.0',id=4,method='tools/call',params=dict(name='booking_list',arguments={'path':'elsewhere'})),
            dict(jsonrpc='2.0',id=5,method='tools/call',params=dict(name='reserve',arguments={})),
            dict(jsonrpc='2.0',method='tools/call',params=dict(name='reserve',arguments={})),
        ]
        source='\n'.join(json.dumps(m) for m in messages)+'\n'
        source+='{"jsonrpc":"2.0","id":6,"method":"ping","m\\u0065thod":"tools/list"}\n'
        source+='not json\n'+'x'*65537+'\n'
        source+=json.dumps(dict(jsonrpc='2.0',id=7,method='ping'))+'\n'
        result=subprocess.run([sys.executable,'app.py','mcp',self.db],cwd=ROOT,env=ENV,input=source,text=True,capture_output=True,timeout=10)
        self.assertEqual(result.returncode,0,result.stderr)
        replies=[json.loads(line) for line in result.stdout.splitlines()]
        byid={r['id']:r for r in replies if r['id'] is not None}
        self.assertEqual(byid[1]['result']['protocolVersion'],'2025-11-25')
        tools=byid[2]['result']['tools']; self.assertEqual(len(tools),1)
        self.assertEqual(tools[0]['name'],'booking_list')
        self.assertEqual(tools[0]['inputSchema'],dict(type='object',properties={},additionalProperties=False))
        self.assertEqual(byid[3]['result']['structuredContent'],dict(revision=1,bookings=[]))
        self.assertFalse(byid[3]['result']['isError'])
        self.assertIn('error',byid[4]); self.assertIn('error',byid[5])
        self.assertEqual(sum('error' in r for r in replies),5)
        self.assertEqual(byid[7]['result'],{})
        self.assertEqual(self.cli('list',self.db),dict(revision=1,bookings=[]))

    def test_mcp_storage_failure(self):
        source='\n'.join(json.dumps(m) for m in [
            dict(jsonrpc='2.0',id=1,method='initialize',params=dict(protocolVersion='2025-11-25',capabilities={},clientInfo=dict(name='test',version='1'))),
            dict(jsonrpc='2.0',method='notifications/initialized'),
            dict(jsonrpc='2.0',id=2,method='tools/call',params=dict(name='booking_list',arguments={}))])+'\n'
        result=subprocess.run([sys.executable,'app.py','mcp',self.db+'.missing'],cwd=ROOT,env=ENV,input=source,text=True,capture_output=True,timeout=10)
        response=json.loads(result.stdout.splitlines()[-1])['result']
        self.assertTrue(response['isError']); self.assertNotIn('structuredContent',response)


if __name__=='__main__':
    unittest.main(verbosity=2)
