"""Study Rooms: local CLI, browser forms, and read-only MCP."""
import datetime as dt
import html
import json
import re
import secrets
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qsl
from booking_sdk import execute, BookingError
from mcp_sdk import serve as mcp_serve


def number(value):
    if not isinstance(value, str) or not re.fullmatch(r'[0-9]+', value) or len(value) > 20:
        raise BookingError(22)
    return int(value)


def date_value(value):
    if not re.fullmatch(r'[0-9]{4}-[0-9]{2}-[0-9]{2}', value):
        raise BookingError(22)
    try:
        return dt.date.fromisoformat(value).toordinal()
    except ValueError:
        raise BookingError(22)


def time_value(value, end=False):
    if not re.fullmatch(r'[0-9]{2}:[0-9]{2}', value):
        raise BookingError(22)
    hour, minute = map(int, value.split(':'))
    if end and hour == 24 and minute == 0:
        return 1440
    if hour > 23 or minute > 59:
        raise BookingError(22)
    return hour * 60 + minute


def run(path, action, fields=None):
    fields = fields or {}
    args = {}
    if action in ('reserve', 'cancel'):
        args.update(expected=number(fields['rev']), id=fields['id'])
    if action == 'reserve':
        args.update(room=number(fields['room']), day=date_value(fields['date']),
                    start=time_value(fields['start']), finish=time_value(fields['end'], True))
    try:
        return execute(path, action, **args)
    except BookingError as exc:
        # Normalize SDK filesystem/capacity codes to the public application contract.
        raise BookingError({2: 404, 27: 22}.get(exc.code, exc.code)) from exc


def clock(minutes):
    return f'{minutes // 60:02d}:{minutes % 60:02d}'


CSS = '''
:root{color-scheme:light dark;--bg:#f4f6fa;--card:#fff;--ink:#17253b;--muted:#526179;--line:#c5cfdd;--accent:#2453a6}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.5 system-ui,sans-serif}main{max-width:1000px;margin:auto;padding:32px 20px}header{margin-bottom:28px}h1{font-size:2.2rem;margin:0}h2{margin-top:0}p{color:var(--muted)}section{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:24px;margin:20px 0}.fields{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}label{display:flex;flex-direction:column;gap:6px;font-weight:600}input,select,button{font:inherit;border:1px solid var(--line);border-radius:6px;padding:10px;min-width:0}button{background:var(--accent);color:white;cursor:pointer;margin-top:16px;font-weight:600}button.cancel{background:transparent;color:var(--ink);margin:0}input:focus-visible,select:focus-visible,button:focus-visible{outline:3px solid #e39816;outline-offset:3px}.table{overflow-x:auto}table{width:100%;border-collapse:collapse;text-align:left}th,td{padding:12px 8px;border-bottom:1px solid var(--line);white-space:nowrap}.notice{border-left:5px solid var(--accent);padding:16px;background:var(--card)}small{color:var(--muted)}@media(max-width:650px){.fields{grid-template-columns:1fr}main{padding:20px 12px}section{padding:16px}}@media(prefers-color-scheme:dark){:root{--bg:#111a28;--card:#192538;--ink:#edf2fa;--muted:#b5c4d8;--line:#4c5d75;--accent:#376dc4}}
'''
MESSAGES = {22: 'Invalid input. Check the ID, room, date and time range.',
            17: 'That reservation ID already exists. Choose another ID.',
            404: 'The reservation or workspace was not found.',
            409: 'The form is stale or this room overlaps another booking. Review the refreshed list and try again.',
            35: 'The workspace is busy. Wait a moment and retry.'}


def page(state, token, values=None, message=''):
    esc = lambda x: html.escape(str(x), quote=True)
    values = values or {}
    hidden = f'<input type="hidden" name="rev" value="{state["revision"]}"><input type="hidden" name="token" value="{token}">'
    fields = ''
    for name, label, placeholder in [('id','Reservation ID','1'),('room','Room (1–16)','1'),('date','Date (YYYY-MM-DD)','2026-11-16'),('start','Start (HH:MM)','09:00'),('end','End (HH:MM; up to 24:00)','10:00')]:
        fields += f'<label for="{name}">{label}<input id="{name}" name="{name}" value="{esc(values.get(name,""))}" placeholder="{placeholder}" required maxlength="{20 if name == "id" else 10}"></label>'
    rows = ''
    for b in state['bookings']:
        rows += f'<tr><td>{esc(b["id"])}</td><td>{b["room"]}</td><td>{dt.date.fromordinal(b["day"]).isoformat()}</td><td>{clock(b["start"])}–{clock(b["finish"])}</td><td><form method="post" action="/action">{hidden}<input type="hidden" name="action" value="cancel"><input type="hidden" name="id" value="{esc(b["id"])}"><button class="cancel" aria-label="Cancel reservation {esc(b["id"])}">Cancel</button></form></td></tr>'
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Study Rooms</title><style>{CSS}</style></head><body><main><header><small>YOUR LOCAL STUDY SPACE</small><h1>Study Rooms</h1><p>Reserve a quiet room, one session at a time. Rooms 1–16 · same-day reservations.</p></header>{f'<div class="notice" role="status">{esc(message)}</div>' if message else ''}<section><h2>Reserve a room</h2><p>Use a unique positive reservation ID. Adjacent sessions are welcome; overlapping sessions in the same room are refused.</p><form method="post" action="/action">{hidden}<input type="hidden" name="action" value="reserve"><div class="fields">{fields}</div><button>Reserve room</button></form></section><section><h2>Saved reservations</h2><p>Revision {state['revision']} · {len(state['bookings'])}/256 reservations · <a href="/">Refresh</a></p>{'<div class="table"><table><thead><tr><th>ID</th><th>Room</th><th>Date</th><th>Time</th><th>Action</th></tr></thead><tbody>'+rows+'</tbody></table></div>' if rows else '<p>No reservations yet. Choose a room and time above.</p>'}</section><small>Local workspace only. Times are local labels; no timezone conversion.</small></main></body></html>'''


def browser(path):
    # Refuse an unavailable workspace before announcing a URL.
    run(path, 'list')
    token = secrets.token_hex(16)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def send(self, status, body):
            data = body.encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'")
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(data)

        def host_ok(self):
            return self.headers.get_all('Host', []) == [self.server.endpoint]

        def render(self, status=200, values=None, message=''):
            try:
                state = run(path, 'list')
                self.send(status, page(state, token, values, message))
            except BookingError as exc:
                self.send(503, f'<h1>Workspace unavailable</h1><p>Error {exc.code}. Retry after checking the workspace.</p>')

        def do_GET(self):
            if not self.host_ok():
                self.send(400, 'Invalid Host'); return
            if self.path != '/':
                self.send(404, 'Not found'); return
            self.render()

        def do_POST(self):
            self.close_connection = True
            if not self.host_ok() or self.headers.get_all('Origin', []) != ['http://' + self.server.endpoint]:
                self.send(403, 'Invalid Host or Origin. Open the announced local URL.'); return
            if self.path != '/action':
                self.send(404, 'Not found'); return
            try:
                lengths = self.headers.get_all('Content-Length', [])
                if len(lengths) != 1 or not re.fullmatch(r'[0-9]{1,5}', lengths[0]):
                    raise ValueError()
                length = int(lengths[0])
                if length > 8192 or self.headers.get('Transfer-Encoding') is not None:
                    raise ValueError()
                if self.headers.get('Content-Type','').split(';')[0].strip().lower() != 'application/x-www-form-urlencoded':
                    raise ValueError()
                raw = self.rfile.read(length)
                if len(raw) != length:
                    raise ValueError()
                source = raw.decode('utf-8', 'strict')
                if re.search(r'%(?![0-9a-fA-F]{2})', source):
                    raise ValueError()
                pairs = parse_qsl(source, keep_blank_values=True, strict_parsing=True, encoding='utf-8', errors='strict', max_num_fields=12)
                fields = dict(pairs)
                expected = {'action','rev','id','token'}
                if fields.get('action') == 'reserve':
                    expected |= {'room','date','start','end'}
                elif fields.get('action') != 'cancel':
                    raise ValueError()
                if len(fields) != len(pairs) or set(fields) != expected:
                    raise ValueError()
                if not secrets.compare_digest(fields['token'].encode(), token.encode()):
                    self.render(403, fields, 'Invalid form token. Retry using this refreshed form.'); return
            except (ValueError, UnicodeError):
                self.render(400, message='Malformed form. Use the labelled form below.'); return
            try:
                run(path, fields['action'], fields)
                self.render(message='Reservation saved.' if fields['action'] == 'reserve' else 'Reservation cancelled.')
            except BookingError as exc:
                self.render(400 if exc.code == 22 else 200, fields, MESSAGES.get(exc.code, f'Storage error {exc.code}. Refresh before retrying.'))
    server = HTTPServer(('127.0.0.1', 0), Handler)
    server.endpoint = f'127.0.0.1:{server.server_address[1]}'
    print('http://' + server.endpoint + '/', flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()


def main(argv):
    try:
        if len(argv) < 2:
            raise BookingError(22)
        action, path, *args = argv
        counts = {'init':0,'list':0,'reserve':6,'cancel':2,'serve':0,'mcp':0}
        if action not in counts or len(args) != counts[action]:
            raise BookingError(22)
        if action == 'serve':
            browser(path); return 0
        if action == 'mcp':
            mcp_serve('study-rooms', '1.0.0', 'booking_list', 'Read the selected study-room workspace.', lambda: run(path, 'list'))
            return 0
        fields = dict(zip(('rev','id','room','date','start','end'), args))
        result = run(path, action, fields)
        print(json.dumps(result, separators=(',', ':')))
        return 0
    except BookingError as exc:
        print(json.dumps({'error': exc.code}, separators=(',', ':')))
        return 2
    except OSError as exc:
        print(json.dumps({'error': exc.errno or 5}, separators=(',', ':')))
        return 2
    except (ValueError, KeyError, OverflowError):
        print('{"error":22}')
        return 2


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
