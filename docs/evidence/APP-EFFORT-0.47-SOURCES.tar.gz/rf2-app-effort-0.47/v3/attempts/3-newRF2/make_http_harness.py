"""Generate the RF2 HTTP test harness from current application source."""
from pathlib import Path
root = Path(__file__).resolve().parent
source = (root / "main.flow").read_text()
source = source.replace("fn main(argc,argv)", "fn cli_main_unused(argc,argv)")
(root / "http-harness.flow").write_text(source + "\n" + (root / "http-test-entry.flow").read_text())
