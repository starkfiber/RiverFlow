"""Local black-box checks; Python is test tooling, never application runtime."""
import fcntl
import subprocess, json, tempfile, pathlib, urllib.request, urllib.error, urllib.parse, re, concurrent.futures, time, hashlib, socket, http.client as http_client
ROOT=pathlib.Path(__file__).resolve().parent
count=0

def check(value, message):
 global count
 assert value, message
 count+=1

def cli(*args, error=None):
 p=subprocess.run([str(ROOT/'app'),*map(str,args)],capture_output=True,text=True,timeout=12)
 try: data=json.loads(p.stdout)
 except Exception: raise AssertionError((args,p.returncode,p.stdout,p.stderr))
 check(p.returncode==(2 if error else 0),('exit',args,p.returncode,data))
 if error: check(data=={'error':error},('error',args,data,error))
 return data

def rpc(proc,obj):
 line=obj if isinstance(obj,str) else json.dumps(obj)
 proc.stdin.write(line+'\n');proc.stdin.flush()
 answer=proc.stdout.readline()
 check(bool(answer), 'MCP closed')
 return json.loads(answer)

with tempfile.TemporaryDirectory(prefix='study-test-',dir=ROOT) as tmp:
 db=pathlib.Path(tmp)/'rooms.db'
 check(cli('init',db)['revision']==1,'init revision')
 cli('init',db,error=17)
 cli('list',pathlib.Path(tmp)/'missing',error=404)
 cli('unknown',pathlib.Path(tmp)/'missing',error=22)
 cli('list',db,'extra',error=22)
 cli('reserve',db,error=22)
 with open(db,'rb') as locked:
  fcntl.flock(locked,fcntl.LOCK_EX|fcntl.LOCK_NB)
  cli('list',db,error=35)
  cli('reserve',db,1,900,1,'2024-01-01','09:00','10:00',error=35)
  fcntl.flock(locked,fcntl.LOCK_UN)

 cli('reserve',db,1,1,1,'2024-02-29','09:00','10:00')
 cli('reserve',db,2,2,1,'2024-02-29','09:30','10:30',error=409)
 cli('reserve',db,1,2,1,'2024-02-29','10:00','11:00',error=409)
 cli('reserve',db,2,1,2,'2024-02-29','10:00','11:00',error=17)
 cli('reserve',db,2,2,1,'2024-02-29','10:00','11:00')
 cli('reserve',db,3,3,2,'2024-02-29','09:00','10:00')
 cli('reserve',db,4,4,1,'2024-03-01','09:00','10:00')
 cli('reserve',db,5,'18446744073709551615',16,'9999-12-31','23:59','24:00')
 cli('reserve',db,6,6,16,'0001-01-01','00:00','00:01')
 baseline=cli('list',db)
 invalid=[('0','1','2024-02-29','09:00','10:00'),('01','1','2024-02-29','09:00','10:00'),('18446744073709551616','1','2024-02-29','09:00','10:00'),('7','17','2024-02-29','09:00','10:00'),('7','01','2024-02-29','09:00','10:00'),('7','1','1900-02-29','09:00','10:00'),('7','1','2024-2-29','09:00','10:00'),('7','1','0000-01-01','09:00','10:00'),('7','1','2024-02-29','24:00','24:00'),('7','1','2024-02-29','9:00','10:00'),('7','1','2024-02-29','10:00','09:00'),('7','1','2024-02-29','10:00','10:00'),('7','1','2024-02-29','09:00','24:01')]
 for fields in invalid: cli('reserve',db,7,*fields,error=22)
 check(cli('list',db)==baseline,'invalid commands unchanged')
 cli('cancel',db,7,999,error=404)
 cli('cancel',db,6,1,error=409)
 canceled=cli('cancel',db,7,2)
 check([b['id'] for b in canceled['bookings']]==['1','3','4','18446744073709551615','6'],'insertion order')
 # Concurrent optimistic revisions: exactly one may commit.
 def race(i):
  p=subprocess.run([str(ROOT/'app'),'reserve',str(db),'8',str(i),'3','2025-01-01','09:00','10:00'],capture_output=True,text=True,timeout=12)
  return p.returncode,json.loads(p.stdout)
 with concurrent.futures.ThreadPoolExecutor(2) as pool: results=list(pool.map(race,[70,71]))
 check(sum(code==0 for code,data in results)==1,('CAS race',results))
 check(all(code==0 or data['error'] in (35,409) for code,data in results),'race refusal')
 # HTTP parser and app over inherited Unix socketpair: TCP bind is sandbox-denied.
 parent,child=socket.socketpair()
 parent.settimeout(8)
 server=subprocess.Popen([str(ROOT/'http-harness'),str(db),str(child.fileno())],pass_fds=(child.fileno(),),stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 child.close()
 try:
  url='http://127.0.0.1:12345/'
  check(server.poll() is None,'HTTP harness process running; test endpoint is synthetic')
  def http(path='/',body=None,headers=None):
   hdr={'Origin':url[:-1]}
   if headers: hdr.update(headers)
   data=urllib.parse.urlencode(body).encode() if isinstance(body,(dict,list)) else body
   hdr.setdefault('Host','127.0.0.1:12345')
   if data is not None:
    hdr['Content-Type']='application/x-www-form-urlencoded'
    hdr['Content-Length']=str(len(data))
   request=('POST' if data is not None else 'GET')+' '+path+' HTTP/1.1\r\n'+''.join(k+': '+v+'\r\n' for k,v in hdr.items())+'\r\n'
   parent.sendall(request.encode()+(data or b''))
   response=http_client.HTTPResponse(parent);response.begin()
   return response.status,response.read().decode()
  status,html=http()
  check(status==200 and 'Study Rooms' in html and '2024-02-29' in html,'GUI saved rows')
  token=re.search(r'name=token value="([^"]+)"',html).group(1)
  rev=re.search(r'name=rev value="?(\d+)',html).group(1)
  form=dict(action='reserve',rev=rev,id='80',room='5',date='2027-01-01',start='09:00',end='10:00',token=token)
  raw=db.read_bytes()
  missing=dict(form);del missing['end']
  for badform in [missing,dict(form,action='delete'),dict(action='cancel',rev=rev,id='1',token=token,room='1'),b'action=reserve&token=%ZZ']:
   check(http('/action',badform)[0] in (400,403),'malformed/incomplete fields')
   check(db.read_bytes()==raw,'bad form unchanged')
  status,invalid_html=http('/action',dict(form,id='<bad>'))
  check(status==200 and '&lt;bad&gt;' in invalid_html and 'Check the booking details' in invalid_html,'invalid retained escaped HTML')
  check(db.read_bytes()==raw,'invalid domain unchanged')

  for variant in [dict(form,token='bad'),dict(form,extra='x'),list(form.items())+[('room','5')]]:
   check(http('/action',variant)[0] in (400,403),'bad form status')
   check(db.read_bytes()==raw,'rejected form journal unchanged')
  check(http('/action',form,{'Origin':'http://evil.invalid'})[0] in (400,403),'origin rejected')
  check(db.read_bytes()==raw,'origin unchanged')
  check(http('/',headers={'Host':'evil.invalid'})[0] in (400,403),'host rejected')
  status,html=http('/action',form)
  check(status==200 and 'Saved to your workspace' in html,'web reserve success')
  check(cli('list',db)['bookings'][-1]['id']=='80','web durable')
  status,html=http('/action',dict(form,id='81'))
  check(status==200 and 'could not be saved' in html and 'value="81"' in html,'stale retained')
  fresh=cli('list',db)['revision']
  check(f'value="{fresh}"' in html,'fresh revision rendered')
  status,html=http('/action',dict(form,rev=str(fresh),id='82',start='09:30'))
  check('could not be saved' in html and 'value="09:30"' in html,'overlap retained')
  status,html=http('/action',dict(action='cancel',rev=str(fresh),id='80',token=token))
  check(status==200 and 'Saved to your workspace' in html,'web cancel success')
  check(all(b['id']!='80' for b in cli('list',db)['bookings']),'cancel persisted')
  check(http('/unknown')[0]==404,'route rejected')
  check(http('/other',form)[0]==404,'post route rejected')

 finally:
  parent.close();server.terminate();server.wait(timeout=5)
 # Read-only MCP protocol / malformed recovery.
 before=db.read_bytes()
 proc=subprocess.Popen([str(ROOT/'app'),'mcp',str(db)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 try:
  init=rpc(proc,dict(jsonrpc='2.0',id=1,method='initialize',params={'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'selftest','version':'1'}}))
  check(init['result']['protocolVersion']=='2025-11-25','MCP initialize')
  proc.stdin.write('{"jsonrpc":"2.0","method":"notifications/initialized"}\n');proc.stdin.flush()
  check('result' in rpc(proc,dict(jsonrpc='2.0',id=2,method='ping')),'ping')
  tools=rpc(proc,dict(jsonrpc='2.0',id=3,method='tools/list'))['result']['tools']
  check(len(tools)==1 and tools[0]['name']=='booking_list','one tool')
  check(tools[0]['inputSchema']=={'type':'object','properties':{},'additionalProperties':False},'schema')
  call=dict(jsonrpc='2.0',id=4,method='tools/call',params={'name':'booking_list','arguments':{}})
  listed=rpc(proc,call)['result']
  check(listed['structuredContent']==cli('list',db),'MCP saved state')
  for bad in ['{bad json','{"jsonrpc":"2.0","id":5,"method":"ping","metho\\u0064":"ping"}',dict(jsonrpc='2.0',id=6,method='unknown'),dict(call,params={'name':'booking_list','arguments':{'path':'x'}}),dict(call,params={'name':'booking_list'}),dict(call,params={'name':'write','arguments':{}}),'x'*65537]:
   check('error' in rpc(proc,bad),'MCP rejection')
   check('result' in rpc(proc,dict(jsonrpc='2.0',id=8,method='ping')),'MCP usable after refusal')
  proc.stdin.write(json.dumps(dict(jsonrpc='2.0',method='tools/call',params={'name':'booking_list','arguments':{}}))+'\n');proc.stdin.flush()
  check('result' in rpc(proc,dict(jsonrpc='2.0',id=9,method='ping')),'notification produces no response')
 finally:
  proc.stdin.close();proc.wait(timeout=5)
 check(db.read_bytes()==before,'MCP read-only bytes')
 # Tool callback failure stays an MCP tool error, with a live connection.
 errorproc=subprocess.Popen([str(ROOT/'app'),'mcp',str(db)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 try:
  rpc(errorproc,dict(jsonrpc='2.0',id=100,method='initialize',params={'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'selftest','version':'1'}}))
  errorproc.stdin.write('{"jsonrpc":"2.0","method":"notifications/initialized"}\n');errorproc.stdin.flush()
  with open(db,'rb') as locked:
   fcntl.flock(locked,fcntl.LOCK_EX|fcntl.LOCK_NB)
   failed=rpc(errorproc,dict(jsonrpc='2.0',id=11,method='tools/call',params={'name':'booking_list','arguments':{}}))
   check(failed['result']['isError'] is True,'MCP tool storage failure')
  check('result' in rpc(errorproc,dict(jsonrpc='2.0',id=12,method='ping')),'MCP survives tool error')
 finally:
  errorproc.stdin.close();errorproc.wait(timeout=5)

 # Capacity and full-size output through both storage paths.
 cap=pathlib.Path(tmp)/'capacity.db';cli('init',cap)
 for i in range(1,257):cli('reserve',cap,i,i,1,'2028-01-01',f'{(i-1)//60:02}:{(i-1)%60:02}',f'{i//60:02}:{i%60:02}')
 check(len(cli('list',cap)['bookings'])==256,'256 capacity durable')
 fullproc=subprocess.Popen([str(ROOT/'app'),'mcp',str(cap)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 try:
  rpc(fullproc,dict(jsonrpc='2.0',id=100,method='initialize',params={'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'selftest','version':'1'}}))
  fullproc.stdin.write('{"jsonrpc":"2.0","method":"notifications/initialized"}\n');fullproc.stdin.flush()
  full=rpc(fullproc,dict(jsonrpc='2.0',id=13,method='tools/call',params={'name':'booking_list','arguments':{}}))
  check(len(full['result']['structuredContent']['bookings'])==256,'MCP full capacity output')
 finally:
  fullproc.stdin.close();fullproc.wait(timeout=5)

 cli('reserve',cap,257,257,2,'2028-01-01','00:00','00:01',error=27)
 # Corruption must stay a failure.
 corrupt=pathlib.Path(tmp)/'corrupt.db';corrupt.write_bytes(b'not a journal')
 p=subprocess.run([str(ROOT/'app'),'list',str(corrupt)],capture_output=True,text=True,timeout=10)
 check(p.returncode==2 and 'error' in json.loads(p.stdout),'corrupt failure')
print(f'PASS: {count} assertions; CLI, durable state, locks/CAS, HTTP via Unix socketpair, MCP, capacity, corruption. TCP bind not verified (sandbox EPERM).')
