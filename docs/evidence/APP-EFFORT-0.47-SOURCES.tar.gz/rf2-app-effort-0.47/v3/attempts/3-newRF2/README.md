# Study Rooms — RF2

A native local reservation application with a CLI, responsive browser interface and read-only MCP server. Application runtime source is `main.flow`, written in RF2. It uses the supplied `lib/*.flow` development SDK for domain storage, dates, HTTP framing/form admission and MCP protocol handling. The SDK is a foundation: command routing, application validation, page composition, actions and selected-workspace callbacks are implemented here.

## Build and launch

The supplied compiler targets this Mac's ARM64/Darwin environment. No package installation is required. From this directory:

```sh
# Compiler requires the output path to be absent; choose a fresh output name.
./rf2c main.flow app.rebuilt --compact --opt
codesign -s - app.rebuilt
mv app.rebuilt app
codesign --verify app
```

`launch.json` is `["./app"]`. The delivered `app` is compiled and ad-hoc signed. It needs no Python or Node runtime.

A working CLI example (choose an unused filename):

```sh
./app init my-study.db
./app reserve my-study.db 1 1 3 2026-11-16 09:00 10:00
./app list my-study.db
./app cancel my-study.db 2 1
```

The reservation response is:

```json
{"revision":2,"version":2,"bookings":[{"id":"1","room":3,"day":739936,"start":540,"finish":600}]}
```

Commands are `init DB`, `list DB`, `reserve DB REV ID ROOM DATE START END`, `cancel DB REV ID`, `serve DB`, and `mcp DB`. Supply the revision from the latest saved response. Success returns saved state JSON and exit 0. Failure returns `{"error":CODE}` and exit 2. Invalid input is 22, existing ID/path 17, missing file/ID 404, stale revision/overlap 409, busy lock 35. Other storage failures remain failures, including capacity 27, corruption 9001 and uncertain saves 9002. After an uncertain save, list the workspace before retrying.

IDs are positive canonical decimal u64 strings; rooms are 1–16. Dates are exactly YYYY-MM-DD, years 0001–9999; times are exactly HH:MM. Intervals are same-day and half-open. Adjacent bookings are allowed. Only an end may be 24:00. Reservation order is insertion order. Cancellation removes the exact ID. There are at most 256 current reservations.

## Browser

```sh
./app serve my-study.db
```

Open the exact `http://127.0.0.1:PORT/` URL printed on the first line. The server selects an ephemeral port and keeps serving until terminated (Ctrl-C). It opens only the selected existing workspace. It has labelled fields, light/dark CSS, keyboard focus styles, retained failed input, current revisions, readable dates/times and explicit cancellation buttons. The reservation form suggests an unused ID.

Forms POST to `/action`. Host and POST Origin must match the selected endpoint; each form includes a process-local unpredictable CSRF token. Duplicate, unknown, missing and malformed fields refuse before storage. Stale or overlapping requests show an explanation and reload actual saved rows; failed reserve inputs remain visible. Invalid admission returns 400/403. Domain errors can return an explanatory page with status 200. Storage read failures return 500. This is a local loopback application, not a public authenticated service. No external assets or scripts are used.

## Read-only MCP

```sh
./app mcp my-study.db
```

Use newline JSON-RPC on stdin/stdout, with no stdout banner. Initialize using protocol `2025-11-25`, send `notifications/initialized`, then `tools/list` or:

```json
{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"booking_list","arguments":{}}}
```

The sole tool is `booking_list`; its schema is an object with no properties and `additionalProperties:false`. Explicit `{}` arguments are required. It returns saved state as `structuredContent` and short text. The callback only calls SDK list storage; it cannot accept paths or perform writes. Unknown methods/tools/arguments, malformed JSON, duplicate decoded keys and oversized request lines refuse without poisoning subsequent requests. Lines are bounded to 65536 bytes. Storage callback failures use `isError:true`. This is the SDK's bounded legacy MCP subset, not a claim of every MCP protocol feature.

## Actual self-tests

`selftest.py` is Python standard-library **test tooling only**. Production remains RF2. The native test harness compiles current RF2 app code with a test-only entry that feeds the real HTTP parser and dispatcher over an inherited Unix socketpair. Generate/build it and run:

```sh
python3 make_http_harness.py
./rf2c http-harness.flow http-harness.rebuilt --compact --opt
codesign -s - http-harness.rebuilt
mv http-harness.rebuilt http-harness
python3 selftest.py
```

Latest result: **409 assertions passed**, recorded in `selftest.log`. Checks cover CLI reopening/durability, exclusive init, canonical/overflow input, date/time boundaries, overlap/adjacency, room/day independence, insertion order, exact cancellation, stale revisions, concurrent writers, real advisory lock contention, corrupted files, 256-row capacity, HTTP rendering/forms/token/origin/Host/route refusal, unchanged journal bytes on rejection, retained escaped inputs, MCP initialization/schema/results/protocol errors/oversized lines/notifications/recovery, storage tool errors and full-capacity MCP output. `http-harness.flow` is generated test source; `http-test-entry.flow` and `make_http_harness.py` preserve its generation recipe.

The raw bind diagnostic is retained in `environment-limit.log`.

**Environment limit:** an actual `serve` launch returned error 5. An independent socket bind to 127.0.0.1 returned `PermissionError(1, Operation not permitted)`. The sandbox therefore prevented testing the TCP bind/listen/accept path. HTTP tests instead used Unix socketpairs with the real SDK parser and app dispatcher; they do not prove live TCP serving. No interactive browser visual review, human trial, hardware qualification, unseen acceptance test or external grader result is claimed.

## Storage and portability

The SDK owns locking, optimistic revision checks, journal schema, snapshots and durability. All processes select a 4 MiB journal budget before the first operation. This is a bounded snapshot journal: repeated edits can exhaust its history budget even with fewer than 256 live rows. There is no compaction, migration or automatic recovery tool in this app. Keep workspace backups; never hand-edit the journal. Older SDK readers with lower budgets may refuse larger files. SDK file access expects regular single-link files and refuses symlinks. Paths are explicitly chosen by the operator, not a directory-containment security boundary.

RF2 and the raw-pointer/system SDK are trusted Mac ARM64 code, not a portable or fully memory-safe application platform. There is no timezone conversion, recurring schedule, multi-user authentication or public deployment claim. Server request sizes, connection counts and deadlines remain SDK-bounded even though total request count is unlimited.

## Evidence and failures

`build.log` and `harness-build.log` record successful native builds. `build-failure-01.log` through `build-failure-05.log` retain compiler failures: excessive parameters, record scope, missing final result return, invalid record-field `try` assignment, and attempted overwrite of an existing compiler output. These were corrected; the compiler's output-file rule requires an absent destination.

`selftest-failure-01.log` records the TCP bind limitation. `selftest-failure-02.log` records a test helper naming collision (`http` shadowed `http.client`). `selftest-failure-03.log` records a test incorrectly calling an MCP tool before initialization; the test was corrected to perform the handshake. `selftest-pass-01.log` preserves the earlier 376-assertion pass. `tool-rejection.log` preserves a tool-level rejection of a cleanup command; verification used a fresh output and preserved the previous binary instead. None of these logs represents an external acceptance run. `HANDOVER.md` summarizes the delivered state and remaining verification.
