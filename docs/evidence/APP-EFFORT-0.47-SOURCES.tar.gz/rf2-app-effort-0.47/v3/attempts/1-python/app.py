"""Local Study Rooms CLI, browser UI and read-only MCP entry point."""
import datetime as dt
import html
import json
import re
import secrets
import sys
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import parse_qsl
from booking_sdk import execute, BookingError
from mcp_sdk import serve as mcp_serve


def run(path, action, **kw):
    try:
        return execute(path, action, **kw)
    except BookingError as exc:
        # Normalize missing workspace and exhausted capacity to the public contract.
        raise BookingError({2: 404, 27: 22}.get(exc.code, exc.code)) from exc


def number(value):
    if not isinstance(value, str) or not re.fullmatch(r'[0-9]{1,20}', value):
        raise BookingError(22)
    return int(value)


def day(value):
    if not re.fullmatch(r'[0-9]{4}-[0-9]{2}-[0-9]{2}', value):
        raise BookingError(22)
    try:
        return dt.date.fromisoformat(value).toordinal()
    except ValueError:
        raise BookingError(22)


def minute(value, end=False):
    if end and value == '24:00':
        return 1440
    if not re.fullmatch(r'(?:[01][0-9]|2[0-3]):[0-5][0-9]', value):
        raise BookingError(22)
    return int(value[:2]) * 60 + int(value[3:])


def mutate(path, fields):
    kw = dict(expected=number(fields['rev']), id=fields['id'])
    if fields['action'] == 'reserve':
        kw.update(room=number(fields['room']), day=day(fields['date']),
                  start=minute(fields['start']), finish=minute(fields['end'], True))
    return run(path, fields['action'], **kw)


def clock(n):
    return f'{n // 60:02d}:{n % 60:02d}'


MESSAGES = {22: 'Invalid input. Use a positive decimal ID, room 1–16, a valid date, and an end later than the start.',
            17: 'That reservation ID already exists. Choose another ID.',
            404: 'The reservation or workspace was not found. Refresh and check the selected workspace.',
            409: 'The form is stale or the room overlaps an existing reservation. Review the refreshed list and try again.',
            35: 'The workspace is busy. Wait briefly, refresh, and try again.'}


def page(state, token, message='', failed=None):
    esc = lambda s: html.escape(str(s), quote=True)
    fields = dict(id='', room='1', date=dt.date.today().isoformat(), start='09:00', end='10:00')
    if failed:
        fields.update({k: v for k, v in failed.items() if k in fields})
    def hidden(name, value):
        return f'<input type="hidden" name="{name}" value="{esc(value)}">'
    common = hidden('rev', state['revision']) + hidden('token', token)
    rows = ''
    for row in state['bookings']:
        rows += ('<tr><td>' + esc(row['id']) + '</td><td>' + str(row['room']) + '</td><td>'
                 + dt.date.fromordinal(row['day']).isoformat() + '</td><td>' + clock(row['start'])
                 + '–' + clock(row['finish']) + '</td><td><form method="post" action="/action">'
                 + hidden('action', 'cancel') + common + hidden('id', row['id'])
                 + '<button class="cancel" type="submit">Cancel <span class="sr">reservation '
                 + esc(row['id']) + '</span></button></form></td></tr>')
    inputs = ''
    for name, label, kind in [('id', 'Reservation ID', 'text'), ('room', 'Room (1–16)', 'number'),
                              ('date', 'Date (YYYY-MM-DD)', 'text'), ('start', 'Start (HH:MM)', 'text'),
                              ('end', 'End (HH:MM, up to 24:00)', 'text')]:
        extra = ' min="1" max="16"' if name == 'room' else ''
        inputs += f'<label>{label}<input name="{name}" type="{kind}" value="{esc(fields[name])}" required{extra}></label>'
    return f'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Study Rooms</title><style>
:root{{color-scheme:light dark;--bg:#f2f5f7;--panel:#fff;--ink:#172d3a;--line:#c8d4db;--accent:#165c78}}*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:16px system-ui,sans-serif;line-height:1.5}}main{{max-width:1050px;margin:auto;padding:32px 20px}}h1{{font-size:2.4rem;margin:0}}h2{{margin-top:0}}.sub{{color:var(--accent)}}section{{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:24px;margin-top:24px}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:16px}}label{{display:flex;flex-direction:column;gap:6px;font-weight:600}}input,button{{font:inherit;border:1px solid var(--line);border-radius:6px;padding:10px}}input{{width:100%;background:var(--panel);color:var(--ink)}}button{{background:var(--accent);color:white;cursor:pointer;font-weight:600}}.grid button{{align-self:end}}:focus-visible{{outline:3px solid #e59726;outline-offset:3px}}.cancel{{background:var(--panel);color:var(--ink)}}.notice{{padding:16px;border:2px solid var(--accent);border-radius:8px}}.scroll{{overflow-x:auto}}table{{width:100%;border-collapse:collapse;text-align:left}}th,td{{padding:12px 8px;border-bottom:1px solid var(--line);white-space:nowrap}}.sr{{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%)}}a{{color:var(--accent)}}@media(prefers-color-scheme:dark){{:root{{--bg:#101d25;--panel:#192c37;--ink:#e6eff4;--line:#45606e;--accent:#79c9e6}}button{{color:#10242d}}}}@media(max-width:500px){{main{{padding:20px 12px}}section{{padding:16px}}h1{{font-size:2rem}}}}
</style><main><header><p class="sub">A quiet place to focus</p><h1>Study Rooms</h1><p>16 rooms · Same-day reservations · Revision {state['revision']}</p></header>
{('<p class="notice" role="status">' + esc(message) + '</p>') if message else ''}
<section><h2>Reserve a room</h2><p>Choose an unused positive numeric ID. Adjacent times are welcome; overlapping bookings are refused. Times use the 24-hour clock.</p>
<form class="grid" method="post" action="/action">{hidden('action','reserve')}{common}{inputs}<button type="submit">Reserve room</button></form></section>
<section><h2>Saved reservations ({len(state['bookings'])}/256)</h2><p><a href="/">Refresh saved state</a></p>
{('<div class="scroll"><table><thead><tr><th>ID</th><th>Room</th><th>Date</th><th>Time</th><th>Action</th></tr></thead><tbody>' + rows + '</tbody></table></div>') if rows else '<p>No reservations yet. Choose a room above to get started.</p>'}</section><p>Local workspace only. No timezone conversion or recurring bookings.</p></main></html>'''


def browser(path):
    run(path, 'list')
    token = secrets.token_hex(16)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def output(self, status, body):
            data = body.encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'")
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(data)

        def host_ok(self):
            return self.headers.get_all('Host') == [endpoint]

        def render(self, status=200, message='', failed=None):
            try:
                self.output(status, page(run(path, 'list'), token, message, failed))
            except BookingError as exc:
                self.output(503, '<h1>Workspace unavailable</h1><p>Error ' + str(exc.code) + '. Refresh to retry; do not assume an operation succeeded.</p>')

        def do_GET(self):
            if not self.host_ok():
                self.output(403, 'Invalid Host'); return
            if self.path != '/':
                self.output(404, 'Not found'); return
            self.render()

        def do_POST(self):
            if not self.host_ok() or self.headers.get_all('Origin') != ['http://' + endpoint]:
                self.output(403, 'Invalid Host or Origin. Return to the local application.'); return
            if self.path != '/action':
                self.output(404, 'Not found'); return
            try:
                lengths = self.headers.get_all('Content-Length') or []
                if len(lengths) != 1 or not re.fullmatch(r'[0-9]{1,6}', lengths[0]) or self.headers.get('Transfer-Encoding'):
                    raise ValueError()
                length = int(lengths[0])
                if length > 8192 or self.headers.get_content_type() != 'application/x-www-form-urlencoded':
                    raise ValueError()
                raw = self.rfile.read(length).decode('utf-8', 'strict')
                if re.search(r'%(?![0-9a-fA-F]{2})', raw):
                    raise ValueError()
                pairs = parse_qsl(raw, keep_blank_values=True, strict_parsing=True, encoding='utf-8', errors='strict', max_num_fields=10)
                fields = dict(pairs)
                expected = {'action', 'rev', 'id', 'token'}
                if fields.get('action') == 'reserve':
                    expected |= {'room', 'date', 'start', 'end'}
                elif fields.get('action') != 'cancel':
                    raise ValueError()
                if len(fields) != len(pairs) or set(fields) != expected:
                    raise ValueError()
                if not secrets.compare_digest(fields['token'].encode(), token.encode()):
                    self.output(403, 'Invalid form token. Refresh the local page.'); return
            except (ValueError, UnicodeError):
                self.output(400, 'Malformed form. Refresh the local page and try again.'); return
            try:
                mutate(path, fields)
                self.render(message='Reservation saved.' if fields['action'] == 'reserve' else 'Reservation cancelled.')
            except BookingError as exc:
                self.render(message=f'Error {exc.code}: ' + MESSAGES.get(exc.code, 'Storage failed. Refresh saved state before retrying.'), failed=fields)
    server = HTTPServer(('127.0.0.1', 0), Handler)
    endpoint = '127.0.0.1:' + str(server.server_address[1])
    print('http://' + endpoint + '/', flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()


def main(args):
    try:
        if len(args) < 2:
            raise BookingError(22)
        action, path = args[:2]
        if action in ('init', 'list') and len(args) == 2:
            result = run(path, action)
        elif action == 'reserve' and len(args) == 8:
            result = mutate(path, dict(zip(('rev', 'id', 'room', 'date', 'start', 'end'), args[2:]), action=action))
        elif action == 'cancel' and len(args) == 4:
            result = mutate(path, dict(action=action, rev=args[2], id=args[3]))
        elif action == 'serve' and len(args) == 2:
            browser(path); return 0
        elif action == 'mcp' and len(args) == 2:
            mcp_serve('study-rooms', '1.0.0', 'booking_list', 'Read saved reservations in the selected workspace.', lambda: run(path, 'list'))
            return 0
        else:
            raise BookingError(22)
        print(json.dumps(result, separators=(',', ':')))
        return 0
    except BookingError as exc:
        print(json.dumps({'error': exc.code}, separators=(',', ':')))
        return 2
    except (OSError, ValueError):
        print('{"error":5}')
        return 2


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
