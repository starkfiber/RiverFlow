# Study Rooms

A local Python application with a CLI, browser reservation interface, and read-only newline JSON-RPC MCP interface. Runtime uses only Python's standard library and the supplied SDKs. `launch.json` selects `["python3","app.py"]`.

## Build and run

Python 3.9 or newer is sufficient. No installation or package download is required. From this directory:

```sh
PYTHONPYCACHEPREFIX="$PWD/.pycache" python3 -m py_compile app.py booking_sdk.py mcp_sdk.py test_app.py
python3 app.py init rooms.sqlite
python3 app.py reserve rooms.sqlite 1 1 4 2026-11-16 09:00 10:00
python3 app.py list rooms.sqlite
python3 app.py cancel rooms.sqlite 2 1
```

The reserve example returns:

```json
{"revision":2,"bookings":[{"id":"1","room":4,"day":739936,"start":540,"finish":600}]}
```

`init` exclusively creates a new database and refuses an existing path. `list` reads the durable saved revision. Reserve and cancel require that exact revision, so reread the state after a conflict. Successful writes increment the revision once. Failures return `{"error":CODE}` and exit 2. Common codes are invalid 22, exists 17, missing 404, stale/overlap 409, and busy 35. Other storage failures remain failures. The frontend normalizes the SDK's missing-path code 2 to 404 and capacity code 27 to invalid 22; corruption/uncertain-write codes remain visible.

IDs are canonical positive decimal strings up to u64 max. Rooms are 1–16; dates use Gregorian `YYYY-MM-DD` from 0001 through 9999. Times use `HH:MM`; `24:00` is permitted only as an end. Reservations are half-open, so adjacent intervals are allowed. There are at most 256 current bookings, in insertion order. No timezone conversion or recurrence is performed.

## Browser

```sh
python3 app.py serve rooms.sqlite
```

Open the exact `http://127.0.0.1:PORT/` URL printed on the first line. The port is assigned by the OS. The server runs until interrupted. It exposes only the chosen existing database and two routes: `/` and `/action`. The page includes labelled fields, explicit cancellation buttons, responsive layout, keyboard focus styles, light/dark CSS, saved revisions and useful errors. Failed reservations retain their input while the saved list refreshes. There are no external assets or scripts.

Forms carry an unpredictable process-local CSRF token. POST requires the exact endpoint Origin and Host; duplicate, unknown or malformed fields are rejected without writing. Restarting the server invalidates old form tokens. This is a local tool, not a public server or authentication system. The single-threaded stdlib HTTP server is intended for cooperative local use, not hostile-client service or production deployment.

## Read-only MCP

```sh
python3 app.py mcp rooms.sqlite
```

Use newline-delimited JSON-RPC, not HTTP or Content-Length framing. Initialize using protocol `2025-11-25`, send `notifications/initialized`, then request `tools/list` or call the only advertised tool:

```json
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{},"clientInfo":{"name":"example","version":"1"}}}
{"jsonrpc":"2.0","method":"notifications/initialized"}
{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"booking_list","arguments":{}}}
```

`booking_list` returns saved state as `structuredContent` plus short text. It accepts only an explicit empty arguments object. There are no write, path-selection, execution, network or migration tools. Tool storage errors return `isError:true`. Malformed/oversized requests and duplicate decoded JSON keys are rejected; the connection remains usable. Request lines are limited to 65536 bytes excluding the newline. Stdout contains protocol responses only.

## Storage and supplied SDKs

`booking_sdk.py` is the supplied, unchanged domain/storage SDK. All interfaces use its `execute` API for validation, SQLite transactions, revision comparison and locking; the app never bypasses those transactions. The format is SQLite, not an RF2 journal. Keep the database on a local writable filesystem. This application makes no cross-runtime journal compatibility, hostile same-user path-isolation, encryption, backup or migration guarantee. Filesystem/SQLite failures can require inspection; reread saved state before retrying an uncertain write.

`mcp_sdk.py` is the supplied generic read-only protocol helper. The app supplies a fixed-workspace callback. One small modification rejects nonempty ping parameters. No third-party libraries or prebuilt app are used.

## Validation and limits

```sh
PYTHONPYCACHEPREFIX="$PWD/.pycache" python3 -m unittest -v test_app
```

The self-tests exercise fresh-process persistence, insertion order, adjacency/overlap, stale revisions, cancellation, ID/date/time limits, 256-booking capacity, SQLite busy handling, competing writes, missing/corrupt storage, MCP schema/read results/error recovery, duplicate keys, request size limits, notifications, and tool errors. HTTP handler checks feed actual HTTP bytes through the application handler using in-memory streams, covering form rendering, Host/Origin/token rejection, duplicate/unknown fields, escaping, retained input, stale state and cancellation.

This execution sandbox forbids binding even a loopback socket. The original live HTTP test failed, and a minimal socket-bind probe confirmed `PermissionError`. The final suite explicitly skips the live-network check in that environment. Real browser rendering and live serving on an unrestricted Mac have not been verified. No human trials or unseen acceptance/grader results are claimed.

`artifacts/test-output.txt` contains the final local test results. `artifacts/first-test-output.txt` preserves the initial failed suite, and `artifacts/FAILURES.md` records the cache and socket restrictions and the MCP correction. The initial compilation failed because this Mac's configured default bytecode cache was outside the allowed directory; the documented build redirects that cache locally. `artifacts/example.sqlite` is the exercised CLI example, not a required application asset.
