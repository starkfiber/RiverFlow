"""Local integration checks; no external services or packages."""
import datetime
import contextlib
import io
import socket
from unittest.mock import patch
import app
import http.client
import json
import os
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import tempfile
import unittest
import urllib.parse

ROOT = Path(__file__).resolve().parent
ENV = dict(os.environ, PYTHONPYCACHEPREFIX=str(ROOT / '.pycache'))

class ApplicationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=ROOT)
        self.db = str(Path(self.temp.name) / 'rooms.db')
        self.cli('init', want={'revision': 1, 'bookings': []})

    def tearDown(self):
        self.temp.cleanup()

    def cli(self, action, *args, error=None, want=None):
        p = subprocess.run([sys.executable, 'app.py', action, self.db, *map(str,args)], cwd=ROOT, env=ENV, capture_output=True, text=True)
        self.assertEqual(p.returncode, 2 if error is not None else 0, p.stderr + p.stdout)
        obj = json.loads(p.stdout)
        if error is not None: self.assertEqual(obj, {'error': error})
        if want is not None: self.assertEqual(obj, want)
        return obj

    def reserve(self, rev=1, id='1', room=1, date='2026-11-16', start='09:00', end='10:00', **kw):
        return self.cli('reserve', rev, id, room, date, start, end, **kw)

    def test_persistence_overlap_order_and_stale(self):
        self.cli('init', error=17)
        a = self.reserve()
        self.assertEqual(a['bookings'][0], dict(id='1',room=1,day=datetime.date(2026,11,16).toordinal(),start=540,finish=600))
        self.cli('list', want=a)
        self.reserve(rev=1, id='2', start='10:00', end='11:00', error=409)
        self.reserve(rev=2, id='2', start='09:59', end='11:00', error=409)
        self.reserve(rev=2, error=17)
        self.reserve(rev=2, id='2', start='10:00', end='11:00')
        self.reserve(rev=3, id='3', room=2)
        self.reserve(rev=4, id='4', date='2026-11-17')
        self.cli('cancel', 4, '1', error=409)
        self.cli('cancel', 5, '99', error=404)
        state = self.cli('cancel', 5, '2')
        self.assertEqual(state['revision'], 6)
        self.assertEqual([r['id'] for r in state['bookings']], ['1','3','4'])
        self.cli('list', want=state)

    def test_validation_and_boundaries(self):
        cases = [dict(id='0'),dict(id='01'),dict(id='18446744073709551616'),dict(id='١'),dict(room=0),dict(room=17),dict(date='2026-2-01'),dict(date='2025-02-29'),dict(date='0000-01-01'),dict(start='9:00'),dict(start='24:00'),dict(end='24:01'),dict(end='09:00'),dict(start='10:01')]
        for values in cases:
            with self.subTest(values=values): self.reserve(**values,error=22)
        self.cli('list', want={'revision':1,'bookings':[]})
        self.reserve(id='18446744073709551615',date='0001-01-01',start='00:00',end='24:00')
        self.reserve(rev=2,id='2',date='9999-12-31',start='23:59',end='24:00')

    def test_capacity_and_lock(self):
        for i in range(256):
            self.reserve(rev=i+1,id=str(i+1),date=(datetime.date(2026,1,1)+datetime.timedelta(days=i)).isoformat())
        self.reserve(rev=257,id='257',date='2027-01-01',error=22)
        connection=sqlite3.connect(self.db)
        try:
            connection.execute('BEGIN IMMEDIATE')
            self.cli('cancel',257,'1',error=35)
        finally: connection.close()
        self.assertEqual(self.cli('list')['revision'],257)

    def test_concurrent_revision(self):
        commands=[[sys.executable,'app.py','reserve',self.db,'1',str(i),'1','2026-11-16','09:00','10:00'] for i in (1,2)]
        processes=[subprocess.Popen(command,cwd=ROOT,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True) for command in commands]
        results=[]
        for process in processes:
            stdout,stderr=process.communicate(timeout=5)
            self.assertFalse(stderr)
            results.append((process.returncode,json.loads(stdout)))
        self.assertEqual(sum(code==0 for code,result in results),1)
        loser=next(result for code,result in results if code!=0)
        self.assertIn(loser['error'],(35,409))
        state=self.cli('list')
        self.assertEqual(state['revision'],2)
        self.assertEqual(len(state['bookings']),1)

    def test_missing_and_corrupt(self):
        original=self.db
        self.db=str(Path(self.temp.name)/'missing.db')
        self.cli('list',error=404)
        Path(self.db).write_text('invalid sqlite')
        self.cli('list',error=9001)
        self.db=original

    def test_live_http(self):
        probe=socket.socket()
        try:
            probe.bind(('127.0.0.1',0))
        except PermissionError:
            self.skipTest('Sandbox denies loopback bind; HTTP handler tested in memory separately')
        finally:
            probe.close()
        p=subprocess.Popen([sys.executable,'app.py','serve',self.db],cwd=ROOT,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            url=p.stdout.readline().strip()
            self.assertRegex(url,r'^http://127\.0\.0\.1:[0-9]+/$')
            endpoint=urllib.parse.urlsplit(url)
            connection=http.client.HTTPConnection(endpoint.hostname,endpoint.port,timeout=5)
            connection.request('GET','/')
            response=connection.getresponse()
            self.assertEqual(response.status,200)
            self.assertIn(b'Study Rooms',response.read())
            connection.close()
        finally:
            p.terminate();p.wait(timeout=5);p.stdout.close();p.stderr.close()

    def test_http_handler(self):
        handlers=[]
        class Server:
            server_address=('127.0.0.1',43210)
            def __init__(self,address,handler): handlers.append(handler)
            def serve_forever(self): pass
            def server_close(self): pass
        with patch.object(app,'HTTPServer',Server), contextlib.redirect_stdout(io.StringIO()):
            app.browser(self.db)
        handler=handlers[0]
        url='http://127.0.0.1:43210/'
        class Wire:
            def __init__(self,data): self.input=io.BytesIO(data);self.output=io.BytesIO()
            def makefile(self,mode,*args): return self.input if 'r' in mode else self.output
            def sendall(self,data): self.output.write(data)
        def request(method,path='/',body=None,headers=None):
            headers=dict(headers or {})
            headers.setdefault('Host','127.0.0.1:43210')
            data=(body or '').encode()
            if body is not None: headers['Content-Length']=str(len(data))
            raw=(method+' '+path+' HTTP/1.0\r\n'+''.join(k+': '+v+'\r\n' for k,v in headers.items())+'\r\n').encode()+data
            wire=Wire(raw)
            handler(wire,('127.0.0.1',12345),Server)
            head,content=wire.output.getvalue().split(b'\r\n\r\n',1)
            return int(head.split()[1]),content.decode()
        status,body=request('GET')
        self.assertEqual(status,200)
        self.assertIn('name="date"',body)
        token=re.search(r'name="token" value="([0-9a-f]+)"',body).group(1)
        headers={'Origin':url[:-1],'Content-Type':'application/x-www-form-urlencoded'}
        fields=dict(action='reserve',rev='1',id='1',room='1',date='2026-11-16',start='09:00',end='10:00',token=token)
        def post(values,extra='',head=None):
            return request('POST','/action',urllib.parse.urlencode(values)+extra,headers if head is None else head)
        for values,extra,head in [(dict(fields,token='bad'),'',None),(fields,'&id=2',None),(fields,'&unknown=x',None),(fields,'',dict(headers,Origin='http://evil.invalid')),(fields,'',dict(headers,Host='evil.invalid'))]:
            status,_=post(values,extra,head)
            self.assertIn(status,(400,403))
            self.cli('list',want={'revision':1,'bookings':[]})
        status,body=post(fields)
        self.assertEqual(status,200);self.assertIn('Reservation saved.',body)
        status,body=post(dict(fields,id='2',room='3',start='12:00',end='13:00'))
        self.assertIn('Error 409',body);self.assertIn('Revision 2',body);self.assertIn('value="12:00"',body)
        self.assertEqual(len(self.cli('list')['bookings']),1)
        status,body=post(dict(fields,rev='2',id='2',start='<script>',end='11:00'))
        self.assertIn('&lt;script&gt;',body);self.assertNotIn('value="<script>"',body)
        status,body=post(dict(action='cancel',rev='2',id='1',token=token))
        self.assertIn('Reservation cancelled.',body)
        self.cli('list',want={'revision':3,'bookings':[]})
        self.assertEqual(request('GET',headers={'Host':'evil.invalid'})[0],403)
        self.assertEqual(request('GET','/elsewhere')[0],404)

    def test_mcp_protocol_and_recovery(self):
        self.reserve()
        messages=[
            dict(jsonrpc='2.0',id=1,method='initialize',params=dict(protocolVersion='2025-11-25',capabilities={},clientInfo=dict(name='tests',version='1'))),
            dict(jsonrpc='2.0',method='notifications/initialized'),
            dict(jsonrpc='2.0',id=2,method='tools/list'),
            dict(jsonrpc='2.0',id=3,method='tools/call',params=dict(name='booking_list',arguments={})),
            dict(jsonrpc='2.0',id=4,method='tools/call',params=dict(name='booking_list',arguments={'path':'other'})),
            dict(jsonrpc='2.0',method='tools/call',params=dict(name='reserve',arguments={})),
        ]
        raw='\n'.join(json.dumps(x) for x in messages)+'\n'
        raw+='{"jsonrpc":"2.0","id":5,"method":"ping","params":{"x":1,"\\u0078":2}}\n'
        raw+='x'*65537+'\n'
        raw+='broken\n'
        raw+=json.dumps(dict(jsonrpc='2.0',id=6,method='unknown'))+'\n'
        raw+=json.dumps(dict(jsonrpc='2.0',id=7,method='ping'))+'\n'
        p=subprocess.run([sys.executable,'app.py','mcp',self.db],cwd=ROOT,env=ENV,input=raw,text=True,capture_output=True,timeout=10)
        self.assertEqual(p.returncode,0,p.stderr)
        out=[json.loads(x) for x in p.stdout.splitlines()]
        self.assertEqual(out[0]['result']['protocolVersion'],'2025-11-25')
        tools=out[1]['result']['tools'];self.assertEqual(len(tools),1)
        self.assertEqual(tools[0]['inputSchema'],dict(type='object',properties={},additionalProperties=False))
        self.assertEqual(out[2]['result']['structuredContent'],self.cli('list'))
        self.assertIn('error',out[3])
        for item in out[4:8]: self.assertIn('error',item)
        self.assertEqual(out[-1],dict(jsonrpc='2.0',id=7,result={}))
        # Unknown ping arguments must be refused, then a valid ping must recover.
        ping_input='\n'.join(json.dumps(x) for x in [dict(jsonrpc='2.0',id=1,method='ping',params={'unexpected':True}),dict(jsonrpc='2.0',id=2,method='ping',params={})])+'\n'
        ping=subprocess.run([sys.executable,'app.py','mcp',self.db],cwd=ROOT,env=ENV,input=ping_input,text=True,capture_output=True,timeout=5)
        ping_out=[json.loads(x) for x in ping.stdout.splitlines()]
        self.assertIn('error',ping_out[0]);self.assertEqual(ping_out[1]['result'],{})
        self.assertEqual(self.cli('list')['revision'],2)
        # Callback failures are tool failures, and subsequent ping remains usable.
        Path(self.db).write_bytes(b'corrupt')
        raw='\n'.join(json.dumps(x) for x in messages[:2]+[messages[3],dict(jsonrpc='2.0',id=9,method='ping')])+'\n'
        p=subprocess.run([sys.executable,'app.py','mcp',self.db],cwd=ROOT,env=ENV,input=raw,text=True,capture_output=True)
        out=[json.loads(x) for x in p.stdout.splitlines()]
        self.assertTrue(out[1]['result']['isError']);self.assertEqual(out[2]['result'],{})

if __name__=='__main__': unittest.main(verbosity=2)
