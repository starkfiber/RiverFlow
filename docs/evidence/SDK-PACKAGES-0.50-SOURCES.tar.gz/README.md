# RF2 0.50 source evidence

Original four authoring deliveries, frozen SDK A and post-study SDK B/current source are distinct. No provider traces, credentials, native images or private user documents are included. Use the source hashes in SOURCE-MANIFEST.json. The study was interrupted by a disclosed controller correction after attempt2; original grades/usage are unchanged.

With the exact public0.46 native compiler, compile compiler/bridge.flow to bridge/program with --compact --opt and sign it. Then use that bridge to compile compiler/compiler.flow to candidate/program with the same flags and sign it. The qualified candidate SHA is4e47ea8be4bfd81ba12eae606f3ea9321f940957a33d67a88559c1f99f65597c. See current/experiments/sdk-packages/build.py and its pins. Current source can also be overlaid on the pinned repository baseb57952d.

For each original RF2 attempt, use that candidate to compile main.flow to a new app with --compact --opt --sdk-root ABSOLUTE/ORIGINAL-ATTEMPT/sdk and sign it; run from the attempt directory. Python entries use the supplied stdlib helpers. Invoke study/grade.py ATTEMPT NEW-REPORT for the original80-control oracle. Supplementary output faults and SDK B repairs are separate; do not revise original scores. Native app runtime needs no Python/Node.
