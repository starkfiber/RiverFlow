# Passage Desk

A read-only Python 3 application for reviewing one local UTF-8 text file.
Uses only the standard library and the supplied `text_sdk.py` and `mcp_sdk.py`.
The application entry, report assembly, HTML renderer and command tests are
implemented in `app.py` and `test_app.py`. No build or installation is required.
Python 3.9 compatible; run from this directory. `launch.json` selects
`["python3","app.py"]`.

Run the three commands with exactly a command, file path and query:

```sh
python3 app.py report example.txt ana
python3 app.py html example.txt ana > report.html
python3 app.py mcp example.txt ana
```

The first command emits:

```json
{"schema":"passage-desk.v1","bytes":7,"scalars":7,"lines":1,"words_ascii_breaks":1,"query":"ana","matches":2,"first_byte":1}
```

Quote paths and queries containing spaces or shell metacharacters. HTML is a
standalone UTF-8 document with embedded responsive CSS, an escaped visible query,
accessible metric table and a local heading link. It contains no source-file
text, scripts or external resources. Shell redirection saves the report; the
application itself only reads the selected file and writes stdout/stderr.

MCP uses newline-delimited JSON-RPC on stdin/stdout, with no banner. To exercise
it manually, start the `mcp` command and send these lines:

```json
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{},"clientInfo":{"name":"local-client","version":"1"}}}
{"jsonrpc":"2.0","method":"notifications/initialized"}
{"jsonrpc":"2.0","id":2,"method":"tools/list"}
{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"passage_report","arguments":{}}}
{"jsonrpc":"2.0","id":4,"method":"ping"}
```

Exactly one read-only tool, `passage_report`, is advertised. Its only permitted
arguments are an explicit empty object. File and query are fixed by launch;
every callback rereads the selected file. A failed read or validation produces
`isError:true` without `structuredContent`; fixing the file permits a subsequent
successful call on the same connection. Notifications never invoke the callback.
Malformed JSON, duplicate decoded keys and oversized lines are refused without
preventing a later ping. EOF exits successfully. This is the supplied bounded
legacy protocol, version `2025-11-25`, with no authentication or modern protocol
compatibility claim.

Limits and metric definitions:

- Selected content is read with a 1,048,576-byte limit. Empty files are valid.
  Final-component symlinks, directories, FIFOs and missing files are refused.
  Parent directories are trusted. Captures are sequential reads, not atomic
  filesystem snapshots.
- Content and query must be strict UTF-8. NUL and C0 controls are refused except
  TAB, LF and CR. Queries must contain 1–128 encoded UTF-8 bytes.
- Search counts overlapping exact byte substrings without normalization or case
  folding. Offsets are zero-based bytes; absence is JSON `null` or HTML `none`.
- Scalars count Unicode code points, not graphemes. Lines count LF bytes plus
  one for nonempty content lacking a final LF. CR alone does not break a line.
  Words split only at TAB, LF, CR and ASCII space; Unicode whitespace remains
  part of a word.
- CLI validation/read failures exit 2 with a stderr diagnostic and no stdout
  result. Results are assembled before output. Output failures also exit 2 where
  catchable, but bytes already sent cannot be rolled back. Success exits 0.
- MCP request lines and serialized callback payloads are capped at 65,536 bytes
  by the supplied helper. No directory discovery, file writes or network access
  is provided by the application.

Run the command-level self-tests:

```sh
python3 -m unittest -v test_app
```

Tests invoke the actual launcher and cover byte/scalar/line/word semantics,
overlaps, Unicode, both size boundaries, input and path refusals, argument count,
HTML structure/escaping, broken output and the interactive MCP lifecycle with
failed-read recovery and framing recovery. Test fixtures are temporary files
inside this directory and are removed afterward. See `VALIDATION.md` and
`validation.txt` for the retained local outcome and initial test failure.
No unseen grader results, human trials or other-platform qualification are
claimed. The supplied helpers were not modified.
