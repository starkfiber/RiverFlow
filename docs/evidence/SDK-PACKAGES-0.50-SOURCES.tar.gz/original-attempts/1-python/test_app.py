"""Local command-level contract checks; no external grader or packages."""
import html.parser
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest


ROOT = Path(__file__).resolve().parent
LAUNCH = json.loads((ROOT / "launch.json").read_text(encoding="utf-8"))


class Document(html.parser.HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.tags = []
        self.attributes = []
        self.texts = {}
        self.active = None
        self.declarations = []

    def handle_decl(self, declaration):
        self.declarations.append(declaration.lower())

    def handle_starttag(self, tag, attrs):
        self.tags.append(tag)
        self.attributes.extend(attrs)
        identity = dict(attrs).get("id")
        if identity:
            self.active = identity
            self.texts[identity] = ""

    def handle_data(self, data):
        if self.active:
            self.texts[self.active] += data

    def handle_endtag(self, tag):
        self.active = None


class Commands(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="passage-tests-", dir=str(ROOT))
        self.directory = Path(self.temporary.name)
        self.file = self.directory / "选定 passage.txt"
        self.file.write_bytes(b"")

    def tearDown(self):
        self.temporary.cleanup()

    def run_app(self, command="report", query="a", path=None, stdin=None):
        return subprocess.run(LAUNCH + [command, str(self.file if path is None else path), query],
                              cwd=str(ROOT), input=stdin, stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, timeout=10)

    def success(self, data, query, expected):
        self.file.write_bytes(data)
        process = self.run_app(query=query)
        self.assertEqual((process.returncode, process.stderr), (0, b""))
        self.assertTrue(process.stdout.endswith(b"\n"))
        self.assertEqual(process.stdout.count(b"\n"), 1)
        self.assertEqual(json.loads(process.stdout), dict(schema="passage-desk.v1", query=query, **expected))

    def test_empty(self):
        self.success(b"", "a", dict(bytes=0, scalars=0, lines=0, words_ascii_breaks=0,
                                     matches=0, first_byte=None))

    def test_unicode_and_overlaps(self):
        data = "é banana\t猫\r\nA\u00a0B\n".encode("utf-8")
        self.success(data, "ana", dict(bytes=20, scalars=16, lines=2,
                                      words_ascii_breaks=4, matches=2, first_byte=4))

    def test_cr_line_and_exact_matching(self):
        self.success(b"aaa\rAA", "aa", dict(bytes=6, scalars=6, lines=1,
                                           words_ascii_breaks=2, matches=2, first_byte=0))
        self.success("e\u0301 É".encode(), "é", dict(bytes=6, scalars=4, lines=1,
                                                     words_ascii_breaks=2, matches=0, first_byte=None))

    def test_byte_limit(self):
        self.success(b"x" * 1048576, "y", dict(bytes=1048576, scalars=1048576, lines=1,
                                              words_ascii_breaks=1, matches=0, first_byte=None))
        self.file.write_bytes(b"x" * 1048577)
        self.assert_failure(self.run_app())

    def assert_failure(self, process):
        self.assertEqual(process.returncode, 2)
        self.assertEqual(process.stdout, b"")
        self.assertTrue(process.stderr.strip())

    def test_invalid_text_and_queries(self):
        for data in (b"\xff", b"\xc0\x80", b"\xed\xa0\x80", b"a\x00b", b"\x01", b"\x0b", b"\x1f"):
            self.file.write_bytes(data)
            for command in ("report", "html"):
                with self.subTest(data=data, command=command):
                    self.assert_failure(self.run_app(command))
        self.file.write_bytes(b"a")
        for query in ("", "a" * 129, "é" * 65, "\x01", "\x0b"):
            self.assert_failure(self.run_app(query=query))
        self.assertEqual(self.run_app(query="é" * 64).returncode, 0)

    def test_nonregular_paths(self):
        link = self.directory / "link"
        link.symlink_to(self.file)
        fifo = self.directory / "fifo"
        os.mkfifo(str(fifo))
        for path in (link, fifo, self.directory, self.directory / "missing"):
            for command in ("report", "html"):
                with self.subTest(path=path, command=command):
                    self.assert_failure(self.run_app(command, path=path))

    def test_argument_count(self):
        for args in ([], ["report"], ["report", str(self.file)],
                     ["report", str(self.file), "a", "extra"], ["unknown", str(self.file), "a"]):
            process = subprocess.run(LAUNCH + args, cwd=str(ROOT), capture_output=True, timeout=10)
            self.assert_failure(process)

    def test_html(self):
        query = '<script a="x">&\'猫\t\n'
        self.file.write_bytes(b"PRIVATE SOURCE CONTENT")
        process = self.run_app("html", query)
        self.assertEqual((process.returncode, process.stderr), (0, b""))
        markup = process.stdout.decode("utf-8")
        document = Document()
        document.feed(markup)
        self.assertIn("doctype html", document.declarations)
        self.assertEqual(document.tags.count("h1"), 1)
        self.assertEqual(document.tags.count("td"), 6)
        self.assertIn("caption", document.tags)
        self.assertIn("title", document.tags)
        self.assertIn(("lang", "en"), document.attributes)
        self.assertIn(("name", "viewport"), document.attributes)
        self.assertEqual(document.texts["query"], query)
        for key, value in dict(bytes="22", scalars="22", lines="1", words="3",
                               matches="0", first_byte="none").items():
            self.assertEqual(document.texts[key], value)
        self.assertNotIn("PRIVATE SOURCE CONTENT", markup)
        self.assertFalse(set(document.tags) & {"script", "iframe", "img", "link"})
        self.assertFalse(any(key.lower().startswith("on") for key, value in document.attributes))
        self.assertEqual([value for key, value in document.attributes if key == "href"], ["#report-heading"])

    def test_broken_output(self):
        process = subprocess.Popen(LAUNCH + ["report", str(self.file), "a"], cwd=str(ROOT),
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        process.stdout.close()
        stderr = process.stderr.read()
        process.stderr.close()
        self.assertEqual(process.wait(timeout=10), 2)
        self.assertIn(b"passage-desk:", stderr)


    # Use a separate process and bounded reads for actual newline JSON-RPC.
    def test_mcp_lifecycle_and_recovery(self):
        process = subprocess.Popen(LAUNCH + ["mcp", str(self.file), "ana"], cwd=str(ROOT),
                                   stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.addCleanup(lambda: process.poll() is None and process.kill())

        def send(request):
            process.stdin.write(json.dumps(request).encode() + b"\n")
            process.stdin.flush()

        def receive():
            import select
            ready, _, _ = select.select([process.stdout], [], [], 5)
            self.assertTrue(ready, "MCP response timeout")
            return json.loads(process.stdout.readline())

        def request(identity, method, params=None):
            body = dict(jsonrpc="2.0", id=identity, method=method)
            if params is not None:
                body["params"] = params
            send(body)
            return receive()

        self.assertEqual(request(1, "ping")["result"], {})
        self.assertIn("error", request(2, "tools/list"))
        initialized = request(3, "initialize", dict(protocolVersion="2025-11-25", capabilities={},
                                                   clientInfo=dict(name="self-test", version="1")))
        self.assertEqual(initialized["result"]["protocolVersion"], "2025-11-25")
        send(dict(jsonrpc="2.0", method="notifications/initialized"))
        tools = request(4, "tools/list")["result"]["tools"]
        self.assertEqual(len(tools), 1)
        self.assertEqual(tools[0]["name"], "passage_report")
        self.assertEqual(tools[0]["inputSchema"], dict(type="object", properties={}, additionalProperties=False))
        call = dict(name="passage_report", arguments={})
        self.file.write_bytes(b"banana")
        expected = json.loads(self.run_app(query="ana").stdout)
        self.assertEqual(request(5, "tools/call", call)["result"]["structuredContent"], expected)
        self.file.write_bytes(b"\xff")
        failed = request(6, "tools/call", call)["result"]
        self.assertTrue(failed["isError"])
        self.assertNotIn("structuredContent", failed)
        self.file.unlink()
        self.assertTrue(request(7, "tools/call", call)["result"]["isError"])
        self.file.write_bytes(b"ana ana")
        recovered = request(8, "tools/call", call)["result"]
        self.assertFalse(recovered["isError"])
        self.assertEqual(recovered["structuredContent"], json.loads(self.run_app(query="ana").stdout))
        for params in (dict(name="other", arguments={}), dict(name="passage_report"),
                       dict(name="passage_report", arguments=None),
                       dict(name="passage_report", arguments={"path": "other"})):
            self.assertIn("error", request(9, "tools/call", params))
        self.assertIn("error", request(10, "unknown"))
        # Notifications must produce neither a callback result nor a response.
        send(dict(jsonrpc="2.0", method="tools/call", params=call))
        self.assertEqual(request(11, "ping")["id"], 11)
        for raw in (b"{broken}\n", b'{"jsonrpc":"2.0","id":1,"method":"ping","metho\\u0064":"ping"}\n',
                    b"x" * 70000 + b"\n", b"\xff\n"):
            process.stdin.write(raw)
            process.stdin.flush()
            self.assertIn("error", receive())
            self.assertEqual(request(12, "ping")["result"], {})
        process.stdin.close()
        self.assertEqual(process.wait(timeout=10), 0)
        self.assertEqual(process.stdout.read(), b"")
        self.assertEqual(process.stderr.read(), b"")
        process.stdout.close()
        process.stderr.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
