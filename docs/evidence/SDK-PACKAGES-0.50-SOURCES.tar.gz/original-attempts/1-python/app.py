"""Passage Desk: bounded, read-only local text reports."""
import html
import json
import sys

from mcp_sdk import serve
from text_sdk import measure, read_regular, search


def query_bytes(query):
    encoded = query.encode("utf-8", "strict")
    if not 1 <= len(encoded) <= 128:
        raise ValueError("query must be 1..128 UTF-8 bytes")
    measure(encoded)
    return encoded


def report(path, query):
    encoded = query_bytes(query)
    data = read_regular(path, limit=1048576)
    metrics = measure(data)
    found = search(data, encoded)
    return {
        "schema": "passage-desk.v1",
        "bytes": len(data),
        "scalars": metrics["scalars"],
        "lines": metrics["lines"],
        "words_ascii_breaks": metrics["words_ascii_breaks"],
        "query": query,
        "matches": found["matches"],
        "first_byte": found["first_byte"],
    }


def render_html(result):
    rows = []
    for label, element_id, key in (
        ("UTF-8 bytes", "bytes", "bytes"),
        ("Unicode scalars", "scalars", "scalars"),
        ("Lines (LF breaks)", "lines", "lines"),
        ("Words (ASCII breaks)", "words", "words_ascii_breaks"),
        ("Overlapping matches", "matches", "matches"),
        ("First match byte offset", "first_byte", "first_byte"),
    ):
        value = result[key]
        text = "none" if value is None else str(value)
        rows.append('<tr><th scope="row">{}</th><td id="{}">{}</td></tr>'.format(
            label, element_id, text))
    return '''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Passage Desk — Text review</title>
<style>
:root { color-scheme: light; font-family: system-ui, sans-serif; color: #192c38; background: #f3f6f7; }
* { box-sizing: border-box; }
body { margin: 0; padding: clamp(1rem, 5vw, 4rem); line-height: 1.6; }
main { max-width: 48rem; margin: auto; padding: clamp(1rem, 4vw, 3rem); background: white; border: 1px solid #c4d1d6; border-radius: 1rem; }
h1 { margin: .5rem 0; font-size: clamp(2rem, 6vw, 3rem); line-height: 1.2; }
.eyebrow { color: #345c66; font-weight: 650; letter-spacing: .08em; text-transform: uppercase; font-size: .8rem; }
a { color: #075666; text-underline-offset: .2em; }
a:focus-visible, h1:focus { outline: 3px solid #985414; outline-offset: 5px; }
#query { white-space: pre-wrap; overflow-wrap: anywhere; padding: 1rem; background: #edf3f4; border-left: 4px solid #167080; }
table { width: 100%; border-collapse: collapse; margin: 1.5rem 0; }
caption { text-align: left; font-weight: 650; padding-bottom: .6rem; }
th, td { padding: .75rem .4rem; border-bottom: 1px solid #c4d1d6; }
th { text-align: left; font-weight: 500; }
td { text-align: right; font-variant-numeric: tabular-nums; }
.note { color: #435d68; font-size: .9rem; }
@media (max-width: 30rem) { body { padding: .6rem; } th { width: 72%; } }
</style>
</head>
<body>
<main>
<a href="#report-heading">Jump to report heading</a>
<p class="eyebrow">Passage Desk / Local text review</p>
<h1 id="report-heading" tabindex="-1">Text review</h1>
<p>Exact query</p>
<div id="query">''' + html.escape(result["query"], quote=True) + '''</div>
<table>
<caption>Captured text metrics</caption>
<tbody>''' + "\n".join(rows) + '''</tbody>
</table>
<p class="note">Offsets start at zero and count UTF-8 bytes. Matches include overlaps.
Words split only at ASCII space, tab, carriage return and line feed.</p>
<p class="note">This report describes one sequential file capture. Source text is not included.</p>
</main>
</body>
</html>
'''


def diagnostic(message):
    try:
        sys.stderr.write("passage-desk: {}\n".format(message))
        sys.stderr.flush()
    except (OSError, UnicodeError):
        pass


def main(argv):
    try:
        if len(argv) != 4 or argv[1] not in ("report", "html", "mcp"):
            raise ValueError("usage: app.py {report|html|mcp} FILE QUERY")
        command, path, query = argv[1:]
        query_bytes(query)
        if command == "mcp":
            serve("passage-desk", "1.0.0", "passage_report",
                  "Read metrics for the launch-selected file and exact query.",
                  lambda: report(path, query))
        else:
            result = report(path, query)
            output = (render_html(result) if command == "html" else
                      json.dumps(result, ensure_ascii=False, allow_nan=False,
                                 separators=(",", ":")) + "\n")
            sys.stdout.buffer.write(output.encode("utf-8", "strict"))
            sys.stdout.buffer.flush()
        return 0
    except (OSError, UnicodeError, ValueError) as exc:
        diagnostic(str(exc))
        # Closing after a failed flush prevents a second shutdown flush from
        # replacing exit status 2. A transport may already have emitted bytes.
        try:
            sys.stdout.close()
        except (OSError, UnicodeError):
            pass
        return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
