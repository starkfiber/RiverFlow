# Local validation record

The first `python3 -m unittest -v test_app` run executed 19 cases and failed
twice on the same incorrect test expectation (inherited by both test classes).
The sample `é banana\t猫\r\nA B\n` is 20 UTF-8 bytes, not the expected 21.
It has 16 scalars: the non-ASCII characters add four bytes beyond their scalar
count (é adds one, 猫 adds two, and NBSP adds one). The application returned 20.
Corrected that expected value and removed duplicate inherited test execution.
No application change was required for this failure.

Final command output is retained in `validation.txt`. These are local self-tests,
not external grader results or cross-platform qualification.

## Verified handover

- Runtime: local `python3 --version` returned `Python 3.9.6`.
- Final `python3 -m unittest -v test_app` exited 0: 10 tests passed in 1.017s.
  Tests launch the actual `launch.json` command for report, HTML and MCP.
- `python3 app.py report example.txt ana` exited 0 and returned
  `{"schema":"passage-desk.v1","bytes":7,"scalars":7,"lines":1,"words_ascii_breaks":1,"query":"ana","matches":2,"first_byte":1}`.
- `python3 app.py html example.txt ana > example-report.html` exited 0;
  `example-report.html` is the retained standalone export. HTML structure and
  escaping were also checked by the command-level HTML parser test.
- Delivered `app.py`, `test_app.py`, `launch.json`, `README.md`, example input,
  example export and these validation records. Supplied helpers and contracts
  were left unchanged. No remote services, installs, delegation or shared
  compute were used.
- No unresolved local test failures remain. No external grader was accessed.
  Cross-platform behavior, browser visual inspection and concurrent-write
  snapshot consistency were not qualified. Future checks should use these
  local receipts and retain the bounded sequential-capture limitation.
