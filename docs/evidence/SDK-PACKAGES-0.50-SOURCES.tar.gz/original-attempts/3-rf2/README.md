# Passage Desk

A native Mac ARM64 RF2 application for read-only text review. The application entry, JSON report assembly and standalone HTML renderer are in `main.flow`. The supplied SDK provides bounded file I/O, UTF-8 measurement, overlapping search, output escaping and legacy MCP transport. No runtime interpreter or network service is needed.

## Build and launch

From this directory, using the supplied compiler and SDK:

```sh
./rf2c main.flow app.new --compact --opt --sdk-root "$PWD/sdk" --diagnostic-json
codesign -s - app.new
codesign --verify --verbose app.new
mv app.new app
```

The compiler requires a new output filename. Replace the existing image only after successful compilation and signing. Delivered `app` was compiled, ad-hoc signed and executed locally. `launch.json` contains exactly `["./app"]`; append the three application arguments when launching.

```sh
./app report sample.txt ana
./app html sample.txt ana > report.html
./app mcp sample.txt ana
```

The included `sample.txt` contains `banana` followed by LF. Its report is:

```json
{"schema":"passage-desk.v1","bytes":7,"scalars":7,"lines":1,"words_ascii_breaks":1,"query":"ana","matches":2,"first_byte":1}
```

`report` emits one JSON object and newline. `html` emits a standalone UTF-8 document with embedded responsive CSS, an escaped query, six metrics and a keyboard-focusable heading link. Redirection in these examples is performed by the shell; the application does not create reports on disk itself. Source file contents are not embedded in HTML.

## Read-only MCP

Launch with a fixed file and query; send one JSON-RPC object per line on stdin. Stdout has protocol messages only. Example input:

```json
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{},"clientInfo":{"name":"local-client","version":"1"}}}
{"jsonrpc":"2.0","method":"notifications/initialized"}
{"jsonrpc":"2.0","id":2,"method":"tools/list"}
{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"passage_report","arguments":{}}}
{"jsonrpc":"2.0","id":4,"method":"ping"}
```

The single advertised tool is `passage_report`, with no properties and `additionalProperties:false`. Arguments must be explicitly `{}`. It rereads the selected file on every callback. File or validation failures produce `isError:true` without successful structured content; correcting the file permits a later successful call in the same session. Invalid requests use JSON-RPC errors. Malformed JSON, decoded duplicate keys and oversized lines leave a later ping usable. Notifications do not trigger callbacks. EOF exits successfully. This is the supplied legacy `2025-11-25` transport; there is no authentication or general modern MCP compatibility claim.

## Definitions and bounds

- Exactly three arguments: command, file, query. Quote paths and queries containing spaces.
- Only regular files are admitted. A final symlink, directory, FIFO or missing path is rejected. Parent path components are trusted.
- Each capture reads at most 1,048,576 bytes, using one extra byte to detect overflow. Captures are sequential reads, not atomic snapshots.
- Text and query require strict UTF-8, with no NUL or C0 controls except TAB, LF and CR. Queries contain 1–128 UTF-8 bytes; the shell/argv interface cannot represent embedded NUL.
- Matching uses exact bytes with overlaps, without normalization or case folding. First offsets are zero-based bytes; absence is JSON `null` and HTML `none`.
- Scalars are Unicode code points. Lines count LF plus a final nonempty unterminated line. Only TAB/LF/CR/ASCII space separate words.
- JSON and HTML are fully assembled before publishing. CLI argument/read/validation/output errors exit 2 and attempt a stderr diagnostic. Already-written transport bytes cannot be rolled back.
- Known limit: the immutable supplied MCP transport calls `exit(1)` on a transport write failure. A closed MCP stdout was actually tested and returned 1, differing from the task's requested output-failure status 2. CLI report output with closed stdout correctly returned 2. Broken-pipe signal behavior was not qualified. The supplied helper was left unchanged.
- This image is for the supplied Mac ARM64 Systems environment. No other platform or human accessibility/browser qualification is claimed.

## Local verification

```sh
./tests/run.sh
./tests/extra.sh
```

The shell test harness uses locally available `jq`, standard shell utilities and the actual signed `./app`; it installs nothing. `tests/run.sh` passed 32 checks, including full report equality, Unicode paths/scalars/offsets, line and word rules, overlapping matches, empty and maximum-size files, malformed UTF-8 and controls, file admission, HTML structure/escaping, CLI output failure and a live MCP session with file changes, error recovery, protocol refusals and EOF. `tests/extra.sh` checks query escaping, input integrity and Unicode query byte bounds, and records the inherited MCP write-failure deviation.

Evidence and failed attempts are retained under ignored `artifacts/`: build receipts, numbered test logs, generated fixtures, report HTML/JSON, MCP transcripts, initial incomplete-initialize failure and the handover. Early test failures were corrected expectations (19-byte Unicode fixture and an overbroad HTML regex); an unavailable `/dev/full` test was replaced with closed stdout. No external grader was accessed, and no unseen grading result is claimed.
