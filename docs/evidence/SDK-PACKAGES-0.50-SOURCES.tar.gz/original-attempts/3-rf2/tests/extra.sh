#!/bin/bash
set -eu
cd "$(dirname "$0")/.."
w="$PWD/artifacts/extra"
mkdir -p "$w"
printf 'quotes " and \\ plus\ttab\rCR\n雪\n' > "$w/input"
shasum -a 256 "$w/input" > "$w/before.sha256"
query=$'" and \\ plus\t'
./app report "$w/input" "$query" > "$w/report.json"
jq -e --arg q "$query" '.query==$q and .matches==1 and .first_byte==7' "$w/report.json" >/dev/null
./app html "$w/input" "$query" > "$w/report.html"
shasum -a 256 "$w/input" > "$w/after.sha256"
cmp "$w/before.sha256" "$w/after.sha256"
printf 'PASS: quoted/backslash/control query JSON roundtrip and unchanged input\n'
q128=$(printf '😀%.0s' {1..32})
./app report "$w/input" "$q128" | jq -e '.query|utf8bytelength==128' >/dev/null
q132="${q128}😀"
set +e
./app report "$w/input" "$q132" > "$w/too-long.out" 2> "$w/too-long.err"
status=$?
set -e
[ "$status" = 2 ] && [ ! -s "$w/too-long.out" ] && [ -s "$w/too-long.err" ]
printf 'PASS: Unicode query byte-length boundary\n'
# Record an inherited helper limitation rather than pretending this passes.
set +e
printf '%s\n' '{"jsonrpc":"2.0","id":1,"method":"ping"}' | ./app mcp "$w/input" x 1>&- 2> "$w/mcp-output-error.err"
status=$?
set -e
printf 'Observed MCP closed-stdout status: %s (task requests 2; supplied helper exits 1).\n' "$status"
[ "$status" = 1 ]
