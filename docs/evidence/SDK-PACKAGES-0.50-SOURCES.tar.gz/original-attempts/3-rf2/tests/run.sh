#!/bin/bash
set -eu
cd "$(dirname "$0")/.."
work="$PWD/artifacts/selftest"
mkdir -p "$work"
passes=0
check() { passes=$((passes+1)); printf 'ok %s - %s\n' "$passes" "$1"; }
fail() { printf 'FAIL: %s\n' "$*" >&2; exit 1; }
reject() {
 set +e
 ./app "$@" > "$work/rejected.out" 2> "$work/rejected.err"
 status=$?
 set -e
 [ "$status" = 2 ] || fail "expected exit 2: $* (got $status)"
 [ ! -s "$work/rejected.out" ] || fail "unexpected stdout: $*"
 [ -s "$work/rejected.err" ] || fail "missing diagnostic: $*"
 check "reject $*"
}
printf 'banana\n' > "$work/plain.txt"
./app report "$work/plain.txt" ana > "$work/report.json"
jq -e '. == {schema:"passage-desk.v1",bytes:7,scalars:7,lines:1,words_ascii_breaks:1,query:"ana",matches:2,first_byte:1}' "$work/report.json" >/dev/null
check 'exact report and overlapping matches'
printf '雪😀 é\tA\rB\n尾' > "$work/space 雪.txt"
./app report "$work/space 雪.txt" '😀' > "$work/unicode.json"
jq -e '.bytes==19 and .scalars==11 and .lines==2 and .words_ascii_breaks==5 and .matches==1 and .first_byte==3' "$work/unicode.json" >/dev/null
check 'Unicode path/scalars, combining mark, CR, TAB and byte offset'
: > "$work/empty"
./app report "$work/empty" a | jq -e '.bytes==0 and .scalars==0 and .lines==0 and .words_ascii_breaks==0 and .matches==0 and .first_byte==null' >/dev/null
check 'empty file and absent offset'
printf 'a\302\240b' > "$work/nbsp"
./app report "$work/nbsp" b | jq -e '.words_ascii_breaks==1 and .scalars==3 and .first_byte==3' >/dev/null
check 'non-ASCII whitespace remains in word'
printf 'aaa' > "$work/overlap"
./app report "$work/overlap" aa | jq -e '.matches==2 and .first_byte==0 and .lines==1' >/dev/null
check 'overlapping matches without trailing LF'
./app html "$work/plain.txt" '<>&"雪' > "$work/report.html"
grep -q '<!doctype html>' "$work/report.html"
grep -q '<html lang="en">' "$work/report.html"
grep -q 'id="query">&lt;&gt;&amp;&quot;雪</span>' "$work/report.html"
[ "$(grep -o '<td id=' "$work/report.html" | wc -l | tr -d ' ')" = 6 ]
for pair in bytes:7 scalars:7 lines:1 words:1 matches:0 first_byte:none; do
 grep -q "id=\"${pair%:*}\">${pair#*:}</td>" "$work/report.html"
done
if grep -Ei '<script|<iframe|https?://|[[:space:]]on[a-z]+=' "$work/report.html"; then fail 'unsafe HTML'; fi
check 'standalone HTML structure, six metrics and escaping'
reject
reject report "$work/plain.txt"
reject report "$work/plain.txt" a extra
reject unknown "$work/plain.txt" a
reject report "$work/plain.txt" ''
long=$(printf '%129s' '' | tr ' ' x)
reject report "$work/plain.txt" "$long"
query128=$(printf '%128s' '' | tr ' ' x)
./app report "$work/plain.txt" "$query128" | jq -e '.matches==0' >/dev/null
check '128 byte query accepted'
reject report "$work/plain.txt" $'\001'
reject report "$work/plain.txt" $'\300\257'
reject report "$work/missing" a
reject report "$work" a
rm -f "$work/link" "$work/fifo"
ln -s plain.txt "$work/link"
mkfifo "$work/fifo"
reject report "$work/link" a
reject report "$work/fifo" a
for bytes in '\000' '\001' '\300\257' '\355\240\200' '\364\220\200\200' '\342\202'; do
 printf '%b' "$bytes" > "$work/invalid"
 reject report "$work/invalid" a
done
head -c 1048576 /dev/zero | tr '\000' a > "$work/max"
./app report "$work/max" aa | jq -e '.bytes==1048576 and .matches==1048575' >/dev/null
check '1 MiB accepted with all overlaps'
printf a >> "$work/max"
reject report "$work/max" a
set +e
./app report "$work/plain.txt" a 1>&- 2> "$work/full.err"
status=$?
set -e
[ "$status" = 2 ] || fail "output failure status $status"
check 'output failure returns 2'
# A live stdin pipe allows file replacement between tool calls.
rm -f "$work/input"
mkfifo "$work/input"
exec 9<> "$work/input"
printf 'banana\n' > "$work/live"
./app mcp "$work/live" ana < "$work/input" > "$work/mcp.jsonl" 2> "$work/mcp.err" 9>&- &
pid=$!
trap 'kill "$pid" 2>/dev/null || true' EXIT
send() { printf '%s\n' "$1" >&9; }
wait_lines() {
 for ((i=0;i<200;i++)); do
  count=$(wc -l < "$work/mcp.jsonl")
  if [ "$count" -ge "$1" ]; then return; fi
  sleep 0.01
 done
 fail "MCP timed out waiting for $1 lines"
}
send '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{},"clientInfo":{"name":"selftest","version":"1"}}}'
send '{"jsonrpc":"2.0","method":"notifications/initialized"}'
send '{"jsonrpc":"2.0","id":2,"method":"tools/list"}'
send '{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"passage_report","arguments":{}}}'
wait_lines 3
jq -se '.[0].result.protocolVersion=="2025-11-25" and (.[1].result.tools|length)==1 and .[1].result.tools[0].name=="passage_report" and .[1].result.tools[0].inputSchema=={type:"object",properties:{},additionalProperties:false} and .[2].result.structuredContent.matches==2' "$work/mcp.jsonl" >/dev/null
check 'MCP initialize, initialized, tool schema and callback'
printf '\000' > "$work/live"
send '{"jsonrpc":"2.0","id":4,"method":"tools/call","params":{"name":"passage_report","arguments":{}}}'
wait_lines 4
jq -se '.[3].result.isError==true and (.[3].result|has("structuredContent")|not)' "$work/mcp.jsonl" >/dev/null
printf 'ana ana' > "$work/live"
send '{"jsonrpc":"2.0","id":5,"method":"tools/call","params":{"name":"passage_report","arguments":{}}}'
wait_lines 5
jq -se '.[4].result.structuredContent.bytes==7 and .[4].result.structuredContent.matches==2 and .[4].result.structuredContent.first_byte==0' "$work/mcp.jsonl" >/dev/null
check 'MCP rereads, returns tool error, and recovers after file correction'
send '{broken'
send '{"jsonrpc":"2.0","id":6,"method":"ping","m\u0065thod":"ping"}'
head -c 66000 /dev/zero | tr '\000' x >&9
printf '\n' >&9
send '{"jsonrpc":"2.0","id":7,"method":"unknown"}'
send '{"jsonrpc":"2.0","id":8,"method":"tools/call","params":{"name":"wrong","arguments":{}}}'
send '{"jsonrpc":"2.0","id":9,"method":"tools/call","params":{"name":"passage_report","arguments":{"path":"x"}}}'
send '{"jsonrpc":"2.0","id":10,"method":"tools/call","params":{"name":"passage_report"}}'
send '{"jsonrpc":"2.0","id":11,"method":"ping"}'
wait_lines 13
jq -se 'length==13 and ([.[5:12][]|has("error")]|all) and .[12].id==11 and .[12].result=={}' "$work/mcp.jsonl" >/dev/null
check 'MCP malformed/duplicate/oversized/invalid requests recover to ping'
printf '\000' > "$work/live"
send '{"jsonrpc":"2.0","method":"tools/call","params":{"name":"passage_report","arguments":{}}}'
send '{"jsonrpc":"2.0","id":12,"method":"ping"}'
wait_lines 14
jq -se 'length==14 and .[13].id==12 and .[13].result=={}' "$work/mcp.jsonl" >/dev/null
exec 9>&-
wait "$pid"
trap - EXIT
check 'notification emits no callback response; EOF exits zero'
printf 'PASS: %s checks\n' "$passes"
