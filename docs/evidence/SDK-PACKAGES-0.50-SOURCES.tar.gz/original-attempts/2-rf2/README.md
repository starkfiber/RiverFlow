# Passage Desk

A native RF2 read-only text review tool for macOS ARM64. The application produces exact JSON measurements, a standalone HTML report, or a launch-selected legacy MCP session. `launch.json` is exactly `["./app"]`.

## Build

From this directory, using the supplied compiler and SDK:

```sh
./rf2c main.flow app.new --compact --opt --sdk-root "$PWD/sdk" --diagnostic-json
codesign -s - app.new
codesign --verify --strict app.new
mv app.new app
```

The compiler requires a new output filename. Replace the existing executable only after compilation and signing succeed. No runtime interpreter, package installation or remote service is needed. A signed `app` is included.

## Run

Exactly three application arguments are required:

```sh
./app report 'sample text 雪.txt' ana
./app html 'sample text 雪.txt' ana > review.html
./app mcp 'sample text 雪.txt' ana
```

The included sample produces:

```json
{"schema":"passage-desk.v1","bytes":19,"scalars":17,"lines":2,"words_ascii_breaks":4,"query":"ana","matches":2,"first_byte":1}
```

HTML is a standalone UTF-8 document with embedded responsive styles, a keyboard-accessible heading link, escaped query text and a captioned metrics table. It contains no source-file text, scripts or remote assets. Open the exported document in a browser; this application does not start a web server. Shell redirection creates the export; the application itself writes only to its standard streams.

MCP reads newline-delimited JSON-RPC from stdin. Send `initialize` with `protocolVersion`, `capabilities` and `clientInfo`, followed by `notifications/initialized`. It advertises protocol `2025-11-25` and exactly one tool, `passage_report`, whose arguments must be an explicit empty object:

```json
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{},"clientInfo":{"name":"local-client","version":"1"}}}
{"jsonrpc":"2.0","method":"notifications/initialized"}
{"jsonrpc":"2.0","id":2,"method":"tools/list"}
{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"passage_report","arguments":{}}}
```

The file and query come only from launch arguments. Every tool callback rereads the file. Callback failures return `isError:true` without successful `structuredContent`; a corrected file can succeed in the same session. Notifications never invoke the callback. Malformed JSON, decoded duplicate keys and oversized request lines produce errors while preserving the connection for subsequent valid requests. EOF exits zero.

## Measurement and safety limits

- Selected files must be regular files; final-component symlinks, directories, FIFOs and missing files are refused. Parent directories are trusted. Reads are bounded to 1,048,576 bytes plus one overflow-detection byte. Empty files are valid.
- Captures are sequential reads, not atomic filesystem snapshots. Concurrent edits can affect a capture.
- File text and query require strict UTF-8. NUL and C0 controls other than TAB, LF and CR are rejected. Query length is 1–128 encoded bytes.
- Matching uses exact bytes, includes overlaps and performs no case folding or normalization. First offsets are zero-based byte offsets; absent offsets are JSON `null` or HTML `none`.
- Scalars count code points. Lines use LF only, with a final nonempty unterminated line counted. Words split only at ASCII space, TAB, LF and CR.
- MCP input lines are capped at 65,536 bytes; response storage is also bounded to 65,536 bytes. Shared parser limits apply. This is a local legacy interface, without authentication or a modern-protocol compatibility claim.
- Invalid launch arguments, validation/read failures and transport failures exit 2 with a short stderr diagnostic. CLI validation failures publish no success output. Already-written transport bytes cannot be rolled back. Darwin pipe handling prevents SIGPIPE from bypassing the application's error return.

## Source and verification

`main.flow` owns argument handling, bounded capture composition, report assembly and HTML rendering. `transport.flow` owns checked MCP framing and response publication, using supplied JSON parsing, object/id validation and text helpers. Supplied SDK/compiler files were not edited. The SDK's generic serving loop is not used because its transport error path exits 1; the application loop propagates errors to exit 2.

Run the retained shell self-tests (macOS shell tools and `jq` are required for tests only):

```sh
./tests/run.sh > artifacts/tests.stdout 2> artifacts/tests.stderr
```

The final signed executable passed 44 local checks: exact metrics, overlaps, Unicode offsets, empty and boundary-sized files, invalid UTF-8/control rejection, path admission, query bounds, HTML structure/escaping, source-byte preservation, signature verification, MCP lifecycle and rereads, callback recovery, invalid requests, duplicate keys, oversized-line recovery, notification silence, EOF, closed streams and broken-pipe handling. Raw outputs and JSON-RPC receipts are under `artifacts/`.

Preserved failures include a sandbox-denied process-substitution logger, an initial SIGPIPE exit, an invalid zero-byte `head` test invocation, and a local-module compilation attempt missing its required `module` header. These were corrected and the final executable was rebuilt, signed and retested. One interim test invocation exercised the previous executable after the module compilation failed; only the final successful build's test receipts establish the delivered result.

No external grader was accessed. HTML was structurally checked, not visually inspected in a browser or tested with assistive technology. Qualification is limited to this local macOS ARM64 environment; no other-platform or hardware-readiness claim is made. Provider token usage was not available to the application author.
