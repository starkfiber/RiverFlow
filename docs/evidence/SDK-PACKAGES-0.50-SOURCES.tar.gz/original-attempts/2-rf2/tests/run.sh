#!/bin/bash
set -eu
cd "$(dirname "$0")/.."
work="$PWD/artifacts/selftest"
mkdir -p "$work"
passed=0
check() { passed=$((passed+1)); echo "ok $passed - $1"; }
expect_report() {
  ./app report "$work/input" "$1" > "$work/actual.json"
  printf '%s\n' "$2" > "$work/expected.json"
  cmp "$work/expected.json" "$work/actual.json"
  check "$3"
}
refuse() {
  set +e
  ./app "$@" > "$work/refused.stdout" 2> "$work/refused.stderr"
  rc=$?
  set -e
  test "$rc" = 2
  test ! -s "$work/refused.stdout"
  test -s "$work/refused.stderr"
  check "refused: $*"
}
printf 'banana\n雪 & <tag>\n' > "$work/input"
expect_report ana '{"schema":"passage-desk.v1","bytes":19,"scalars":17,"lines":2,"words_ascii_breaks":4,"query":"ana","matches":2,"first_byte":1}' 'UTF-8 and overlapping search'
printf '' > "$work/input"
expect_report a '{"schema":"passage-desk.v1","bytes":0,"scalars":0,"lines":0,"words_ascii_breaks":0,"query":"a","matches":0,"first_byte":null}' 'empty file'
printf 'aaaaa' > "$work/input"
expect_report aaa '{"schema":"passage-desk.v1","bytes":5,"scalars":5,"lines":1,"words_ascii_breaks":1,"query":"aaa","matches":3,"first_byte":0}' 'three overlaps'
printf 'é😀\302\240x\tq\rZ\n' > "$work/input"
expect_report 😀 '{"schema":"passage-desk.v1","bytes":14,"scalars":9,"lines":1,"words_ascii_breaks":3,"query":"😀","matches":1,"first_byte":2}' 'code points, byte offset and non-ASCII whitespace'
refuse
refuse report
refuse other "$work/input" a
refuse report "$work/input" a extra
refuse report "$work/input" ''
long_query=$(printf '%0129d' 0)
refuse report "$work/input" "$long_query"
refuse report "$work/input" $'\xff'
refuse report "$work/input" $'\001'
refuse report "$work/missing" a
refuse report "$work" a
ln -sf input "$work/symlink"
refuse report "$work/symlink" a
rm -f "$work/fifo"
mkfifo "$work/fifo"
refuse report "$work/fifo" a
for bytes in '\377' '\300\257' '\355\240\200' '\364\220\200\200' '\342\202' '\000' '\001' '\013'; do
  printf "$bytes" > "$work/input"
  refuse report "$work/input" a
done
# Exactly 1 MiB succeeds; one byte more refuses.
dd if=/dev/zero bs=1048576 count=1 2>/dev/null | tr '\000' a > "$work/input"
./app report "$work/input" aa > "$work/limit.json"
jq -e '.bytes==1048576 and .scalars==1048576 and .matches==1048575 and .first_byte==0' "$work/limit.json" >/dev/null
check '1 MiB limit and large overlap count'
printf a >> "$work/input"
refuse report "$work/input" a
printf 'safe text' > "$work/input"
query=$'<>&"\047雪\t\n'
./app html "$work/input" "$query" > "$work/report.html"
for fragment in '<!doctype html>' '<html lang="en">' '<title>' '<h1 ' '<caption>' 'id="bytes"' 'id="scalars"' 'id="lines"' 'id="words"' 'id="matches"' 'id="first_byte">none' 'id="query">&lt;&gt;&amp;' '雪' 'name="viewport"' ':focus-visible'; do
  rg -F "$fragment" "$work/report.html" >/dev/null
done
! rg -i '<script|<iframe|https?://| on[a-z]+=' "$work/report.html"
check 'standalone HTML structure and escaping'
cp "$work/input" "$work/file with spaces 雪.txt"
./app report "$work/file with spaces 雪.txt" safe > "$work/spaces.json"
jq -e '.matches==1 and .first_byte==0' "$work/spaces.json" >/dev/null
check 'Unicode and spaced path'
# A live bidirectional session proves rereads and recovery.
rm -f "$work/requests" "$work/responses"
mkfifo "$work/requests" "$work/responses"
./app mcp "$work/input" aa < "$work/requests" > "$work/responses" 2> "$work/mcp.stderr" &
server=$!
trap 'kill "$server" 2>/dev/null || true' EXIT
exec 3> "$work/requests"
exec 4< "$work/responses"
receive() { IFS= read -r -t 5 reply <&4; printf '%s\n' "$reply" >> "$work/mcp.jsonl"; printf '%s\n' "$reply" | jq -e "$1" >/dev/null; }
: > "$work/mcp.jsonl"
printf '%s\n' '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{},"clientInfo":{"name":"selftest","version":"1"}}}' >&3
receive '.id==1 and .result.protocolVersion=="2025-11-25"'
printf '%s\n' '{"jsonrpc":"2.0","method":"notifications/initialized"}' '{"jsonrpc":"2.0","id":2,"method":"tools/list"}' >&3
receive '.id==2 and (.result.tools|length)==1 and .result.tools[0].name=="passage_report" and .result.tools[0].inputSchema.additionalProperties==false and .result.tools[0].inputSchema.properties=={}'
printf aaaa > "$work/input"
printf '%s\n' '{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"passage_report","arguments":{}}}' >&3
receive '.id==3 and .result.structuredContent.matches==3 and .result.structuredContent.bytes==4'
printf '\377' > "$work/input"
printf '%s\n' '{"jsonrpc":"2.0","id":4,"method":"tools/call","params":{"name":"passage_report","arguments":{}}}' >&3
receive '.id==4 and .result.isError==true and (.result|has("structuredContent")|not)'
printf aaaaa > "$work/input"
printf '%s\n' '{"jsonrpc":"2.0","id":5,"method":"tools/call","params":{"name":"passage_report","arguments":{}}}' >&3
receive '.id==5 and .result.structuredContent.matches==4 and .result.structuredContent.bytes==5'
check 'MCP initialize, list, callback failure and recovery with reread'
for request in '{bad' '{"jsonrpc":"2.0","id":6,"method":"ping","metho\u0064":"ping"}' '{"jsonrpc":"2.0","id":7,"method":"missing"}' '{"jsonrpc":"2.0","id":8,"method":"tools/call","params":{"name":"other","arguments":{}}}' '{"jsonrpc":"2.0","id":9,"method":"tools/call","params":{"name":"passage_report"}}' '{"jsonrpc":"2.0","id":10,"method":"tools/call","params":{"name":"passage_report","arguments":{"x":1}}}'; do
 printf '%s\n' "$request" >&3
 receive 'has("error")'
done
check 'MCP malformed JSON, decoded duplicate keys and invalid requests'
# Oversized input is drained, and the next ping still works.
dd if=/dev/zero bs=70000 count=1 2>/dev/null | tr '\000' x >&3
printf '\n' >&3
receive 'has("error")'
printf '%s\n' '{"jsonrpc":"2.0","method":"tools/call","params":{"name":"passage_report","arguments":{}}}' '{"jsonrpc":"2.0","id":11,"method":"ping"}' >&3
receive '.id==11 and has("result")'
check 'MCP oversized-line recovery and notification silence'
exec 3>&-
wait "$server"
exec 4<&-
trap - EXIT
check 'MCP EOF exit zero'
codesign --verify --strict app
check 'native signature verification'
refuse mcp "$work/input" ''
refuse html "$work/input" $'\xff'
for command in report html; do
 set +e
 ./app "$command" "$work/input" aa 1>&- 2> "$work/$command-output-error.stderr"
 rc=$?
 set -e
 test "$rc" = 2
 test -s "$work/$command-output-error.stderr"
 check "$command closed-output failure exits 2"
done
set +e
(sleep 0.1; exec ./app report "$work/input" aa) 2> "$work/broken-pipe.stderr" | true
statuses=("${PIPESTATUS[@]}")
set -e
test "${statuses[0]}" = 2
test -s "$work/broken-pipe.stderr"
check 'broken output pipe exits 2 with diagnostic'
printf '%s\n' '{"jsonrpc":"2.0","id":90,"method":"ping"}' > "$work/ping.jsonl"
set +e
./app mcp "$work/input" aa < "$work/ping.jsonl" 1>&- 2> "$work/mcp-output-error.stderr"
rc=$?
set -e
test "$rc" = 2
test -s "$work/mcp-output-error.stderr"
check 'MCP closed-output failure exits 2'
set +e
./app mcp "$work/input" aa 0<&- > "$work/mcp-input-error.stdout" 2> "$work/mcp-input-error.stderr"
rc=$?
set -e
test "$rc" = 2
test ! -s "$work/mcp-input-error.stdout"
test -s "$work/mcp-input-error.stderr"
check 'MCP transport read failure exits 2'
printf 'aa\rbb\r' > "$work/input"
expect_report bb '{"schema":"passage-desk.v1","bytes":6,"scalars":6,"lines":1,"words_ascii_breaks":2,"query":"bb","matches":1,"first_byte":3}' 'CR is only a word separator'
printf 'AAAA é e\314\201' > "$work/input"
./app report "$work/input" a > "$work/case.json"
jq -e '.matches==0 and .first_byte==null' "$work/case.json" >/dev/null
./app report "$work/input" é > "$work/normalization.json"
jq -e '.matches==1 and .first_byte==5' "$work/normalization.json" >/dev/null
check 'exact case and no Unicode normalization'
query128=$(printf '%0128d' 0)
printf '%s' "$query128" > "$work/input"
./app report "$work/input" "$query128" > "$work/query128.json"
jq -e '.bytes==128 and .matches==1 and .first_byte==0' "$work/query128.json" >/dev/null
check '128-byte query accepted'
before=$(cksum "$work/input")
./app report "$work/input" 00 > "$work/readonly.json"
./app html "$work/input" 00 > "$work/readonly.html"
after=$(cksum "$work/input")
test "$before" = "$after"
check 'CLI commands leave selected bytes unchanged'

echo "FINAL PASS: $passed checks"
