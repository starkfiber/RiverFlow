"""Local integration tests; run with python3 -m unittest -v test_app.py."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from html.parser import HTMLParser

ROOT = Path(__file__).resolve().parent
APP = [sys.executable, str(ROOT / 'app.py')]


class Document(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=True)
        self.tags = []
        self.values = {}
        self.active = []
        self.declarations = []
        self.feed(text)

    def handle_decl(self, decl):
        self.declarations.append(decl.lower())

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        self.tags.append((tag, attrs))
        self.active.append((tag, attrs.get('id')))
        if attrs.get('id'):
            self.values[attrs['id']] = ''

    def handle_endtag(self, tag):
        for index in range(len(self.active) - 1, -1, -1):
            if self.active[index][0] == tag:
                del self.active[index:]
                break

    def handle_data(self, data):
        for _, identifier in self.active:
            if identifier:
                self.values[identifier] += data


class ApplicationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=ROOT)
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / 'selected passage 日本語.txt'
        self.path.write_bytes(b'')

    def run_app(self, *args):
        return subprocess.run(APP + list(args), stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, timeout=10)

    def report(self, data, query):
        self.path.write_bytes(data)
        proc = self.run_app('report', str(self.path), query)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(proc.stderr, b'')
        self.assertTrue(proc.stdout.endswith(b'\n'))
        return json.loads(proc.stdout)

    def test_metrics_and_exact_bytes(self):
        result = self.report('éaaa\tβ\r\nword\u00a0word\n'.encode(), 'aa')
        self.assertEqual(result, dict(schema='passage-desk.v1', bytes=21,
            scalars=18, lines=2, words_ascii_breaks=3, query='aa', matches=2, first_byte=2))
        result = self.report(b'', 'x')
        self.assertEqual(result, dict(schema='passage-desk.v1', bytes=0,
            scalars=0, lines=0, words_ascii_breaks=0, query='x', matches=0, first_byte=None))
        for data, lines, words in [(b'a\rB', 1, 2), (b'\n', 1, 0),
                                   (b'a\n\n', 2, 1), (b' \t\r', 1, 0)]:
            result = self.report(data, 'x')
            self.assertEqual((result['lines'], result['words_ascii_breaks']), (lines, words))
        self.assertEqual(self.report('é e\u0301 É'.encode(), 'é')['matches'], 1)
        self.assertEqual(self.report('😀😀😀'.encode(), '😀😀')['matches'], 2)

    def test_bounds(self):
        self.assertEqual(self.report(b'a' * 1048576, 'a')['matches'], 1048576)
        self.assertEqual(self.report(b'a', 'é' * 64)['matches'], 0)
        self.path.write_bytes(b'a' * 1048577)
        self.assert_refused('report', str(self.path), 'a')

    def assert_refused(self, *args):
        proc = self.run_app(*args)
        self.assertEqual(proc.returncode, 2)
        self.assertEqual(proc.stdout, b'')
        self.assertTrue(proc.stderr)

    def test_invalid_inputs_and_arguments(self):
        for args in [(), ('report',), ('other', str(self.path), 'x'),
                     ('report', str(self.path), 'x', 'extra')]:
            self.assert_refused(*args)
        for query in ['', 'a' * 129, 'é' * 65, '\x01', '\x00']:
            if '\x00' in query:  # OS argv cannot contain NUL; unit-test validation directly.
                from app import validate_query
                with self.assertRaises(ValueError):
                    validate_query(query)
            else:
                self.assert_refused('report', str(self.path), query)
        for data in [b'\xff', b'\xc0\x80', b'\xed\xa0\x80', b'\x00', b'\x0b', b'\x1f']:
            self.path.write_bytes(data)
            for command in ['report', 'html']:
                self.assert_refused(command, str(self.path), 'x')
        self.path.write_bytes(b'good')
        for path in [self.path.parent, self.path.parent / 'missing']:
            self.assert_refused('report', str(path), 'x')
        link = self.path.parent / 'link'
        link.symlink_to(self.path)
        self.assert_refused('report', str(link), 'x')
        fifo = self.path.parent / 'fifo'
        os.mkfifo(str(fifo))
        self.assert_refused('report', str(fifo), 'x')
        raw_args = [os.fsencode(arg) for arg in APP] + [b'report', os.fsencode(self.path), b'\xff']
        proc = subprocess.run(raw_args, capture_output=True, timeout=10)
        self.assertEqual((proc.returncode, proc.stdout), (2, b''))

    def test_html(self):
        query = '<tag a="\'">& é\t\n'
        self.path.write_text('PRIVATE SOURCE', encoding='utf-8')
        proc = self.run_app('html', str(self.path), query)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        text = proc.stdout.decode('utf-8')
        self.assertNotIn('PRIVATE SOURCE', text)
        doc = Document(text)
        self.assertIn('doctype html', doc.declarations)
        self.assertEqual(doc.values['query'], query)
        expected = dict(bytes='14', scalars='14', lines='1', words='2', matches='0', first_byte='none')
        self.assertEqual({key: doc.values[key] for key in expected}, expected)
        tags = [tag for tag, attrs in doc.tags]
        self.assertEqual(tags.count('h1'), 1)
        self.assertEqual(tags.count('td'), 6)
        for tag in ['title', 'caption', 'th', 'style']:
            self.assertIn(tag, tags)
        self.assertTrue(any(tag == 'html' and attrs.get('lang') == 'en' for tag, attrs in doc.tags))
        self.assertTrue(any(tag == 'meta' and attrs.get('name') == 'viewport' for tag, attrs in doc.tags))
        for tag, attrs in doc.tags:
            self.assertNotIn(tag, ['script', 'iframe', 'img', 'link'])
            self.assertFalse(any(key.lower().startswith('on') for key in attrs))
            if 'href' in attrs:
                self.assertTrue(attrs['href'].startswith('#'))

    def test_mcp_recovery_and_reread(self):
        proc = subprocess.Popen(APP + ['mcp', str(self.path), 'aa'],
                                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        def cleanup():
            if proc.poll() is None:
                proc.kill()
            proc.communicate()
        self.addCleanup(cleanup)
        def raw(line):
            proc.stdin.write(line + b'\n')
            proc.stdin.flush()
            return json.loads(proc.stdout.readline())
        def request(method, params=None, ident=1):
            value = dict(jsonrpc='2.0', id=ident, method=method)
            if params is not None:
                value['params'] = params
            return raw(json.dumps(value).encode())
        init = request('initialize', dict(protocolVersion='2025-11-25', capabilities={},
                       clientInfo=dict(name='local-tests', version='1')))
        self.assertEqual(init['result']['protocolVersion'], '2025-11-25')
        proc.stdin.write(b'{"jsonrpc":"2.0","method":"notifications/initialized"}\n')
        proc.stdin.flush()
        tools = request('tools/list')['result']['tools']
        self.assertEqual(len(tools), 1)
        self.assertEqual(tools[0]['name'], 'passage_report')
        self.assertEqual(tools[0]['inputSchema'], dict(type='object', properties={}, additionalProperties=False))
        args = dict(name='passage_report', arguments={})
        self.path.write_bytes(b'aaa')
        expected = json.loads(self.run_app('report', str(self.path), 'aa').stdout)
        self.assertEqual(request('tools/call', args)['result']['structuredContent'], expected)
        # Notifications must not execute the callback: a following ping is the only reply.
        proc.stdin.write(json.dumps(dict(jsonrpc='2.0', method='tools/call', params=args)).encode() + b'\n')
        proc.stdin.flush()
        self.assertEqual(request('ping')['result'], {})
        self.path.write_bytes(b'\xff')
        failed = request('tools/call', args)['result']
        self.assertTrue(failed['isError'])
        self.assertNotIn('structuredContent', failed)
        self.path.unlink()
        self.assertTrue(request('tools/call', args)['result']['isError'])
        self.path.write_bytes(b'aaaa')
        self.assertEqual(request('tools/call', args)['result']['structuredContent']['matches'], 3)
        for params in [dict(name='wrong', arguments={}), dict(name='passage_report'),
                       dict(name='passage_report', arguments={'path': 'x'}),
                       dict(name='passage_report', arguments=[]),
                       dict(name='passage_report', arguments=None)]:
            self.assertIn('error', request('tools/call', params))
        self.assertIn('error', request('unknown'))
        for bad in [b'{', b'{"id":1,"i\\u0064":2}', b'x' * 65537, b'\xff']:
            self.assertIn('error', raw(bad))
            self.assertEqual(request('ping')['result'], {})
        proc.stdin.close()
        proc.wait(timeout=10)
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stderr.read(), b'')
        proc.stdout.close()
        proc.stderr.close()
        # communicate() cannot flush an already closed stdin in cleanup.
        proc.stdin = None

    def test_broken_output(self):
        self.path.write_bytes(b'aaa')
        proc = subprocess.Popen(APP + ['report', str(self.path), 'aa'],
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        proc.stdout.close()
        code = proc.wait(timeout=10)
        diagnostic = proc.stderr.read()
        proc.stderr.close()
        self.assertEqual(code, 2)
        self.assertTrue(diagnostic)

    def test_launch(self):
        self.assertEqual(json.loads((ROOT / 'launch.json').read_text()), ['python3', 'app.py'])


if __name__ == '__main__':
    unittest.main()
