"""Passage Desk: bounded, read-only text reports."""
import html
import json
import sys

from mcp_sdk import serve
from text_sdk import measure, read_regular, search


def validate_query(query):
    encoded = query.encode('utf-8', 'strict')
    if not 1 <= len(encoded) <= 128:
        raise ValueError('query must contain 1..128 UTF-8 bytes')
    measure(encoded)
    return encoded


def build_report(path, query):
    needle = validate_query(query)
    data = read_regular(path, limit=1048576)
    metrics = measure(data)
    found = search(data, needle)
    return dict(schema='passage-desk.v1', bytes=len(data),
                scalars=metrics['scalars'], lines=metrics['lines'],
                words_ascii_breaks=metrics['words_ascii_breaks'], query=query,
                matches=found['matches'], first_byte=found['first_byte'])


def render_html(report):
    fields = [('bytes', 'Bytes', 'bytes'), ('scalars', 'Unicode scalars', 'scalars'),
              ('lines', 'Lines', 'lines'), ('words', 'Words (ASCII breaks)', 'words_ascii_breaks'),
              ('matches', 'Overlapping matches', 'matches'),
              ('first_byte', 'First byte offset', 'first_byte')]
    rows = '\n'.join('<tr><th scope="row">{}</th><td id="{}">{}</td></tr>'.format(
        label, identifier, 'none' if report[key] is None else str(report[key]))
        for identifier, label, key in fields)
    return '''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Passage Desk — Text review</title>
<style>
:root { color-scheme: light dark; font-family: system-ui, sans-serif; line-height: 1.6; }
body { margin: 0; padding: clamp(1rem, 5vw, 3rem); }
main { max-width: 48rem; margin: auto; }
a { color: inherit; text-underline-offset: .2em; }
a:focus-visible { outline: 3px solid currentColor; outline-offset: 4px; }
h1 { line-height: 1.2; font-size: clamp(2rem, 6vw, 3rem); }
.query { padding: 1rem; border: 1px solid; border-radius: .5rem; }
#query { white-space: pre-wrap; overflow-wrap: anywhere; }
table { width: 100%; border-collapse: collapse; margin-top: 1.5rem; }
caption { text-align: left; font-weight: bold; padding-bottom: .5rem; }
th, td { padding: .75rem .5rem; border-bottom: 1px solid; text-align: left; }
td { text-align: right; font-variant-numeric: tabular-nums; }
footer { margin-top: 2rem; font-size: .9rem; }
@media (max-width: 30rem) { th, td { padding: .5rem .25rem; } }
</style>
</head>
<body><main>
<a href="#report-heading">Go to report heading</a>
<h1 id="report-heading" tabindex="-1">Passage Desk</h1>
<p>Read-only text review · exact UTF-8 matching</p>
<div class="query">Query: <span id="query">''' + html.escape(report['query'], quote=True) + '''</span></div>
<table><caption>Text metrics</caption><tbody>
''' + rows + '''
</tbody></table>
<footer>Offsets are zero-based bytes. Words split only at ASCII space, tab, carriage return and line feed. This report contains no source-file text.</footer>
</main></body>
</html>
'''


def main(argv=None):
    args = sys.argv[1:] if argv is None else argv
    try:
        if len(args) != 3 or args[0] not in ('report', 'html', 'mcp'):
            raise ValueError('usage: python3 app.py {report|html|mcp} FILE QUERY')
        command, path, query = args
        validate_query(query)
        if command == 'mcp':
            serve('passage-desk', '1.0.0', 'passage_report',
                  'Read metrics for the launch-selected file and query.',
                  lambda: build_report(path, query))
        else:
            report = build_report(path, query)
            output = (json.dumps(report, ensure_ascii=False, allow_nan=False) + '\n'
                      if command == 'report' else render_html(report))
            sys.stdout.buffer.write(output.encode('utf-8', 'strict'))
            sys.stdout.buffer.flush()
        return 0
    except (OSError, ValueError, UnicodeError) as exc:
        if isinstance(exc, OSError):
            # Prevent Python's shutdown flush from replacing exit 2 with exit 120.
            try:
                sys.stdout.close()
            except OSError:
                pass
        try:
            sys.stderr.write('Passage Desk: {}\n'.format(exc))
        except (OSError, UnicodeError):
            pass
        return 2


if __name__ == '__main__':
    sys.exit(main())
