# Passage Desk

A read-only Python text review CLI, standalone HTML exporter, and launch-selected MCP tool. The application composes the supplied `text_sdk.py` and `mcp_sdk.py`; its entry point, report assembly, HTML renderer and tests are in `app.py` and `test_app.py`.

## Run

Python 3.9 or later and its standard library are sufficient. No build, packages, server or installation is required. Keep both supplied SDK modules beside `app.py`. Run from this directory:

```sh
python3 app.py report examples/passage.txt ana
python3 app.py html examples/passage.txt ana
python3 app.py mcp examples/passage.txt ana
```

`launch.json` contains exactly `["python3","app.py"]`. A launcher appends command, file and query as three separate arguments. Quote paths and queries with spaces in a shell. Commands write only to stdout and diagnostics to stderr; they never modify the selected file. To save an HTML export, the caller can redirect stdout to a separate destination.

The included example contains `banana` followed by LF. Its report is:

```json
{"schema":"passage-desk.v1","bytes":7,"scalars":7,"lines":1,"words_ascii_breaks":1,"query":"ana","matches":2,"first_byte":1}
```

`examples/report.json` and `examples/report.html` were generated using the actual launch array. The HTML document embeds responsive CSS, shows only metrics and escaped query text, and includes a keyboard-focusable local heading link. It has no scripts, remote resources or source-file content.

## MCP

The `mcp` command reads newline-delimited JSON-RPC on stdin and replies on stdout without a banner. Send these lines in order:

```json
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{},"clientInfo":{"name":"local-client","version":"1"}}}
{"jsonrpc":"2.0","method":"notifications/initialized"}
{"jsonrpc":"2.0","id":2,"method":"tools/list"}
{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"passage_report","arguments":{}}}
{"jsonrpc":"2.0","id":4,"method":"ping"}
```

Exactly one tool, `passage_report`, is advertised. Its schema has no properties and disallows additional properties. Arguments must be an explicit empty object. The launch-selected file and query cannot be changed by protocol requests. Every callback reopens and rereads the file. File or content failures return `isError:true` without successful `structuredContent`; a later call can succeed after the file is corrected. Notifications never invoke the callback. EOF exits normally. The supplied bounded legacy helper implements protocol version `2025-11-25`; no authentication or broader modern-protocol compatibility is claimed.

## Limits and error behavior

- Exactly three application arguments are required. Invalid command, query, file, text or output transport causes exit 2 and a diagnostic where possible. Successful commands and normal MCP EOF exit 0. CLI builds the whole result before output; already-written transport bytes cannot be rolled back.
- Input is limited to 1,048,576 bytes using a bounded read. Empty files are valid. Final-component symlinks, missing files, directories and FIFOs are refused. Parent directory components are trusted. Reads are sequential captures, not atomic filesystem snapshots.
- Both input and query require strict UTF-8. NUL and C0 controls other than TAB/LF/CR are refused. Queries contain 1–128 encoded bytes. Matching uses exact bytes, allows overlaps, and performs no normalization or case folding. The first match is a zero-based byte offset, or null when absent.
- Scalars count Unicode code points, not graphemes. LF determines line count, including an unterminated last line. CR alone does not break lines. Words split only on ASCII space, TAB, LF and CR; Unicode whitespace remains inside words.
- MCP requests are bounded to 65,536 payload bytes per newline-framed request. Malformed JSON, duplicate decoded keys and oversized lines are refused while subsequent valid requests remain usable. The helper bounds report payloads to 65,536 bytes.
- Qualification here covers only the installed local Python 3.9/macOS environment. No other-platform, hardware, human-trial, performance or external-grader result is claimed.

## Validation and retained evidence

```sh
python3 -m unittest -v test_app.py
```

Seven local integration tests passed in the final run (`test-results-final.txt`). Tests execute actual report, HTML and MCP commands and check Unicode metrics, overlapping matches, empty and maximum-size input, query boundaries, invalid UTF-8 and controls, file refusals, HTML structure and escaping, launch configuration, broken output, MCP schema, rereads, callback recovery, malformed requests and later ping recovery.

Two earlier failed runs remain intact:

- `test-results-initial.txt`: the test fixture's expected byte/scalar counts were wrong; corrected to 21 bytes and 18 scalars after inspection.
- `test-results-second.txt`: broken-pipe output returned Python shutdown code 120. The application now closes failed stdout before returning 2. The failed test also exposed a test resource cleanup warning, which was corrected.

The supplied SDK files were not changed. No remote services, installs, delegation, shared compute, authentication access or external grader were used. Provider usage was not exposed to the application author and is not estimated here.
