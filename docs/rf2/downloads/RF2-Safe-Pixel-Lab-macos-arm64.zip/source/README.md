# Safe Pixel Lab: checked visual transformations in native RF2

An actual Mac ARM64 application, built19November2026. It takes a fixed8×8 grayscale
image and performs invert, rotate180, checked brightness+32, or a composed
brightness+16/invert/rotate recipe. The native program emits JSON receipts or SVG.
It reuses the existing evidence-contract engine and SHA/output modules, copied
byte-for-byte into this isolated experiment with provenance in BUILD.json. This is
application composition, not a newly invented guarantee or general image editor.

## Try it

```
python3 experiments/rf2-practical-demo-20261119/build.py artifacts/rf2-practical-demo-20261119/your-new-build
artifacts/rf2-practical-demo-20261119/your-new-build/safe-pixels invert 00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
```

The build helper is development tooling. The resulting native executable needs no
Python or Node runtime. Run with `RECIPE 128-CHARACTER-LOWERCASE-HEX [BUDGET ALLOW]`.
The optional permission mask uses add=1, invert=2, rotate=4. The optional budget
counts abstract element operations, not CPU instructions/time. A separate fourth
argument `--svg` emits a native SVG instead of JSON using default permission/budget.
All images are exactly64bytes. No files, external device, network or live data are
modified by this application. The calling shell may redirect output to a new file.

## Actual checks

`qualification-r2/RESULTS.json` records636/636 assertions:120 seeded native
transformation/refusal cases, independently computed state/work/receipts, explicit
edges, malformed arguments, native SVG pixels and an actually compiled candidate
fault that refuses before changing original state. The independent oracle runs in
Python; it is a correctness oracle, not a timed competing application. `showcase/`
adds4 actual asymmetric-arrow native runs and matches SVG/JSON/receipt output.

Source/target/build identity is in `build-r3/BUILD.json`; the executable is ad-hoc
signed, not notarized. Receipts bind selected source identity, input/output and
contract/result fields using SHA-256. They are unsigned content digests and do not
prove who executed the program or substitute for authentication.

## What this demonstrates

A visual native application can compose existing permission/budget, independent
reference/candidate agreement, atomic public-state commit and inspectable receipts.
A denied recipe, low budget, arithmetic overflow or candidate disagreement preserves
the original pixels. Python, C++ and C# can implement these features too. No
exclusive capability, measured authoring/token advantage, runtime speedup, human
learner trial or broad hardware compatibility follows from these tests.

The full native profile differs from Simple V3. The first SVG build used `%`, which
Simple supports but this selected native grammar rejects. Its failure and exact
source are preserved in build-r2. The correction uses `(i&7)` for an eight-column
layout. A premature verifier invocation against that failed build also stopped
before tests and is not counted as a pass. The candidate corruption is a deliberately
mutated test fixture; its retained identity is not a valid binding for the mutated
source. Production source was not modified to create that negative control.

Everything remains local. No shared UI/compiler source, installed runtime, Git,
Memory/KHC, publication, live firewall or infrastructure changes were made.
