# Full native course: the next six lessons

Start with [FIRST-STEPS.md](FIRST-STEPS.md) for one-line Simple programs. These next lessons introduce the full native language. Run each with `./rf2 native academy/examples/native/NAME.flow`; temporary builds are handled for you. Source is under academy/examples/native and shared helpers live in lib/. Original explicit-output-directory routes remain available in tools/rf2learn; historical evidence is retained in artifacts/academy-20261118/qualification-r3 and current diagnostics/MCP regression in artifacts/friendly-final-regression-20261118.

## 1. Say something

Run `./rf2 native academy/examples/native/hello.flow`. Expect `Hello, RF2!`.

Change only the string in hello.flow to your own welcome. Save plain text, then run again. You changed data inside the same program contract. IO can fail; the shared entry handles that instead of reporting a false successful lesson.

## 2. Make a choice

Run `./rf2 native academy/examples/native/choices.flow`. It starts with5 seats and3 guests, so it prints `There is room.`. Change guests to8 and expect `Choose a larger room.`. Equality at5 still fits. Explain why `<=` differs from `<`.

```flow
let seats=5
let guests=3
if guests<=seats
 return say("There is room.\n")
end
```

`let` declares; `set` updates an already declared local. Locals are function-scoped in this selected compiler. `var` is not current syntax. Do not assume native subtraction below zero creates a signed negative number.

## 3. Repeat with a stopping rule

Run `./rf2 native academy/examples/native/loops.flow`. It adds1 through5, producing `Total: 15`. Change the upper bound to10 and expect55. Identify the counter update that makes the loop end.

A native infinite loop is possible. Deliberately removing that update belongs only in an isolated, timeout-supervised test, not in an ordinary unsupervised lesson. Core's separate bounded execution contract does not automatically apply to Systems programs.

## 4. Name a calculation

Run `./rf2 native academy/examples/native/functions.flow`. `twice(21)` produces `Answer: 42`. Change the call to `twice(30)` and expect60. Now add a `triple` function in a private copy and specify expected results before running it.

```flow
fn twice(number)
 return number*2
end
```

A function is reusable behavior; this is not a Java class constructor. Library and nominal type features are taught separately.

## 5. Handle failure

Run `./rf2 native academy/examples/native/errors.flow`. `admit(7)` refuses a room limited to5 and produces `Choose a larger room.`. Change it to `admit(3)` and expect `Admitted: 3`. Explain both handle branches and why a failure code is not a valid admission count.

The example supplies exhaustive success/failure behavior. General exception, panic or signal recovery is not implied by the existence of results.

## 6. Choose your own vocabulary

Run `./rf2 native academy/examples/native/vocabulary.flow`. `tell` delegates to `say`. Swap the two names in your copy and verify the output stays the same. That is library/API customization, not a compiler keyword change. For grammar changes, follow SYNTAX-LAB.md.

## Core versus native

Try `tools/rf2learn core sum '[4294967295,1]'`; checked overflow refuses. `tools/rf2learn core wrap '[4294967295,1]'` returns0 under its explicit wrapping contract. Systems uses a different unsigned machine-word model. Do not carry an overflow assumption from one profile into another.

Build your own trusted source with `tools/rf2learn build YOUR.flow NEW-DIRECTORY`; start the resulting NEW-DIRECTORY/program separately. `tools/rf2learn check YOUR.flow` checks without creating a program. On refusal, retain the diagnostic and use the relevant rf2help topic. Missing `print` is a function/library discovery issue, not evidence that every native program can use a Python-style builtin.
