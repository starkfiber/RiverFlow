# Your language, with compatibility and evidence

You can shape RF2. Start by separating three kinds of change.

| Change | What changes | What is working now |
|---|---|---|
| Vocabulary | Library/function names | `tell` delegates to `say`; both native lesson calls run |
| Syntax | Grammar/token interpretation | A separate compiler experiment is required; `var` is currently refused |
| Semantics | Meaning of operations/types/errors | Requires explicit numeric, lifetime, effect and target contracts |

## Safe first experiment

Copy academy/examples/native and its lib/ into a private directory. Rename `tell` to `speak` in the helper and the vocabulary lesson call. Check, build into a new directory and compare its output. This demonstrates API naming control without changing existing `.flow` grammar.

## A real keyword proposal

For example, propose `var` as an alias for `let`. Do not replace source with a blind text substitution: strings, comments, identifiers, diagnostics, function fingerprints and old programs need their own treatment.

1. Record exact accepted grammar and whether old `let` remains valid.
2. Keep a separate candidate/compiler profile and source hash; do not overwrite the working compiler.
3. Add positive, negative, string/comment and ambiguous-token cases with expected diagnostics.
4. Check the same meaning against an unchanged reference and every supported target/ABI.
5. Replay existing applications, ownership/error boundaries, native self-generation and bounded Core admission.
6. Measure the complete authoring/repair task before claiming fewer tokens or faster development.
7. Decide whether migration is justified; preserve old syntax until compatibility is qualified.

No keyword alias or new profile is implemented by this document. Current tests intentionally show `var` refusing. The learning helper now points to syntax/errors help after compiler refusal, but the compiler's precise hint for an unsupported statement remains an improvement opportunity.

Keep layout/vocabulary experiments distinct from lower-level optimizations. One language can expose a readable API while preserving exact machine semantics; shortening source does not prove reduced CPU time, AI usage or changed transistor physics.
