# Choose, repeat, reuse

Start with [messages and input](VARIABLES-INPUT.md). Then try one new idea at a time.
Save each example in a plain `.flow` file and run it with `./rf2 FILE.flow`.

## Make a choice

```flow
let points = 30
if points >= 30
 say "Level up!"
else
 say "Keep practising."
end
```

`if` checks a condition. `else` is the other choice. `end` closes the block.
Change points to 20 and predict the message before running again.

Comparisons: `==` means equal, `!=` different, `<` less, `<=` at most, `>` greater,
`>=` at least. Compare two values at a time. This first Simple version compares
numbers; text comparison and `and`/`or` expressions are not implemented here yet.
A numeric zero is false; any other numeric value is true.

## Repeat a known number of times

```flow
repeat 3 times
 say "I can learn RF2."
end
```

It prints the message three times. Change 3 to 5 and predict the result.
The number is calculated once when repeat begins. Changing a variable inside the
block does not change that block's original repeat count.

## Repeat while a condition holds

```flow
let count = 3
while count > 0
 show count
 set count = count - 1
end
```

It prints 3,2,1 immediately. This counts values; it does not wait one second between
them. The tested native Focus/Stretch apps provide timed sessions separately.
`while` checks the condition again each time. The update makes this loop stop.

Try accidentally removing the update in a disposable copy. The Simple engine
stops with a work-limit explanation instead of computing forever. Human input can
still wait for an answer; this limit is not a wall-clock timeout or an OS sandbox.

## Give a calculation a name

```flow
fn double(n)
 return n * 2
end
show double(7)
```

It prints 14. `fn` introduces a small function. `n` is its input; `return` gives the
answer. Try double(9), then write a triple function.

This initial Simple function has one numeric return expression. It can call other
small functions, including a function written later. It uses its own inputs rather
than reading outside variables. Functions cannot form a calling circle. They do
not contain questions, messages or statement blocks yet. Full native RF2 already
has a separate, more general function grammar; these limits describe Simple.

## Ask again inside a loop

Introduce names before a block. Inside it, use `set` or ask again:

```flow
let answer = 0
repeat 3 times
 ask number answer "Give me a whole number."
 show answer * 2
end
```

`ask` creates a new name at the top level, or updates an existing same-kind name.
`let` introduces a name once. New names cannot first appear inside if/loop blocks
in this version. This avoids accidentally using a value from a branch that never ran.

## Play, change, explain

```sh
./rf2 academy/examples/simple/guessing-game.flow
./rf2 academy/examples/simple/double-quiz.flow
./rf2 academy/examples/simple/work-planner.flow
```

The guessing game has a fixed secret of 7 and three tries. It is not random or a
security challenge. Change the secret consistently and play again.
The quiz has three rounds and ten points per correct answer. Enter 2,4,6 to score 30.
The planner asks for jobs/workers, handles zero workers, then calculates rounds.

Use `./rf2 inspect FILE.flow` to inspect the potential questions without answering.
Questions inside branches/loops need not occur in the listed order or number.
This command is a local plan view, separate from the nine bounded Core MCP tools.

## Rules to grow with

Simple currently allows 64 meaningful source lines, 32 variable names, eight nested
blocks, eight functions and four numeric function inputs. Each function uses one
return expression. A repeat count must be at most 1,000. Dynamic execution has a
shared 4,096-unit instruction/expression budget; a longer body may hit it before
finishing 1,000 repetitions. Source parsing, validation and constant folding have
separate finite source/expression limits; logical work is not elapsed CPU time.

Names keep their text/number kind. No negative/floating values, block-local new
names, break/continue, recursion or general effects in Simple yet. `main` is reserved
as a function name; full-native entry programs use `./rf2 native FILE.flow`.
`build` produces a CLI executable. A real macOS `.app` needs bundle packaging,
so names ending in .app are refused rather than producing a misleading app file.

All grammar/names/types and every function body are checked before questions.
An input-dependent calculation or work limit can still fail later. Already displayed
questions stay visible; an unfinished staged result is not presented as success.

This is a locally tested Apple Silicon Mac learning edition. It is intended to be
readable for beginners; there has been no child/classroom learning study. The route
into full native libraries, explicit target/device contracts and OS work remains in
[the academy](README.md) and [the project direction](../docs/OWNER-VISION.md).
