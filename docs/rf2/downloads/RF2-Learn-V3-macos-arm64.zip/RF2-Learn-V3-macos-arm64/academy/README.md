# Portable RF2 academy

Start with [first steps](FIRST-STEPS.md), then [variables and input](VARIABLES-INPUT.md), [conditions/loops/functions](CONTROL-FLOW.md), and [full native lessons](LESSONS.md). Full-project evidence and historical source references in the course are not bundled in this starter kit. Use the root README for exact included tools and limits.
