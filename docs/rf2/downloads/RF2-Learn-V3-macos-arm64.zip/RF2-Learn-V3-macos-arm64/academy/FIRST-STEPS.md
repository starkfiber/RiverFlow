Your first RF2 program

1. Open a text editor. Save a file called hello.flow containing:

   say "Hello, world!"

2. In the RiverFlow folder, run:

   ./rf2 hello.flow

You should see:

   Hello, world!

3. Change the message to your own name and run it again.
   say adds a new line for you. Tamil and other UTF-8 text work inside quotes.

Now try a calculation. Save this as calculator.flow:

   show (12 + 8) * 3 - 5

Run ./rf2 calculator.flow. The answer is 55.
You can also calculate directly: ./rf2 calc '(12 + 8) * 3 - 5'

+ adds; - subtracts; * multiplies; ** raises to a power.
/ divides exactly; // divides and drops the remainder; % gives the remainder.
Try ./rf2 calc '7 / 2'. It explains the fraction rather than silently rounding.
Try ./rf2 calc '7 // 2'. The answer is 3.
This beginner mode uses whole numbers from 0 to 18,446,744,073,709,551,615.
Negative numbers, fractions and scientific functions are not supported here yet.

Keep a program to run later: ./rf2 build hello.flow hello
Then run ./hello. This executable does not need the RF2 compiler installed.
An existing output file is never replaced.

Now remember a value:

   let points = 2
   set points = points + 3
   show points

This prints 5. let remembers; set changes; show calculates.

Now ask a question. Save as age.flow:

   ask number age "How old are you?"
   show age + 1

Run ./rf2 age.flow. Enter 12 and press Enter; it prints 13.
For text: ask name "What is your name?" then say name on the next line.
Read academy/VARIABLES-INPUT.md for the next small activities and common mistakes.

The Simple profile uses say, show, let, set and ask, plus blank lines and # comments.
It checks grammar, names and types before asking questions. If a calculation fails
after input, earlier prompts can remain visible; an unfinished result is not printed. Quick runs use the native Simple executor. The build
command creates a standalone native executable; interactive programs include the native
Simple engine. Neither sends your file to an AI service. It is not a general operating-system sandbox.

When ready, learn functions, libraries, loops and files in the full native course:
academy/LESSONS.md. Those programs use ./rf2 native FILE.flow.
The full course currently uses explicit libraries and a different source profile;
Simple programs are not accepted by the bounded Core/MCP tools.

Use ./rf2 help for short commands and ./rf2 help features for the full reference.
This is a local Apple Silicon Mac learning edition, not a published portable release.

Choose, repeat and reuse next: academy/CONTROL-FLOW.md
Try ./rf2 help conditions, ./rf2 help repeat and ./rf2 help small-functions.
Play ./rf2 academy/examples/simple/guessing-game.flow (fixed secret, three tries).
Simple functions currently have one numeric return expression; full native RF2
has its own broader grammar. Loops have a shared work limit and need a stopping rule.
