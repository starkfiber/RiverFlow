# Remember, ask, calculate

Start with a message:

```flow
say "Hello, world!"
```

Save it as `hello.flow`. In the RiverFlow folder, run `./rf2 hello.flow`.

## Give a value a name

```flow
let points = 2
set points = points + 3
show points
```

[Next: conditions, loops and functions](CONTROL-FLOW.md).

`let` remembers a value. `set` changes a value you already named. `show` calculates
and displays a number. This program prints `5`.

Save it as `points.flow`, then run `./rf2 points.flow`.
Change `3` to `8`. Predict the answer before running again.

A name can also remember text:

```flow
let name = "Jitra"
say name
```

Quotes mean text. A name without quotes refers to the value you remembered.
`say "name"` prints the word name; `say name` prints Jitra.

## Ask the person running your program

```flow
ask name "What is your name?"
say "Hello!"
say name
```

Save as `greeting.flow`, then run `./rf2 greeting.flow`.
Type your name and press Enter. Try a Tamil name too.
Your terminal may echo what you type; that echo comes from the terminal.

For a number, say so:

```flow
ask number age "How old are you?"
show age + 1
```

`ask` remembers text. `ask number` asks for a whole number that calculations can use.
If you type `12`, the answer is `13`. If you type `twelve`, RF2 explains the problem.
It does not guess a number for you.

## Make something useful

This little app measures a rectangular floor in whole metres:

```flow
ask number width "Width in whole metres?"
ask number length "Length in whole metres?"
let area = width * length
say "Area in square metres:"
show area
```

Enter `4` and `5`. The result is `20`.
This lesson uses whole numbers from zero upwards. Fractions and negative values
are not supported in this beginner profile yet. This is not a precision measuring tool.

Three runnable examples live in `academy/examples/simple/`: `greeting.flow`,
`rectangle.flow` and `workshop.flow`. Try:

```sh
./rf2 academy/examples/simple/rectangle.flow
```

## Make a mistake on purpose

Try `show pionts` instead of `show points`. The name is different, so RF2 explains
that it has not been introduced. Fix the spelling and run again.

Try `set score = 10` before introducing score. Use `let score = 10` first.
Try asking for a name and then multiplying it. Use `ask number` for numeric answers.
A name keeps its kind: text stays text and numbers stay numbers. In Simple V3, ask
can also update an existing same-kind name; let still introduces a name only once.

The whole program's grammar and names are checked before a question appears.
A result can still fail after an answer, for example if someone enters zero as a
divisor. Earlier questions stay visible; an unfinished result is not printed as success.

## Keep the program

```sh
./rf2 build greeting.flow greeting
./greeting
```

The saved executable needs no compiler or language installation to run on the
qualified Mac. Existing output files are protected. Interactive saved programs
currently include the native Simple engine; they are larger than constant-only
Hello World. Direct specialized machine-code lowering for these new statements
remains further work.

## Grow from here

Use the short words first. Full native RF2 adds functions, libraries, resource rules
and platform contracts. You can read and edit the six-line Focus/Stretch applications
in `experiments/focus-lifecycle/` after the full-native introductory lessons.

For an AI tool, `./rf2 inspect greeting.flow` shows a JSON plan with the questions,
text/number kinds and declared input effects without asking them. This is a local
inspection command. Interactive input is not exposed through the nine bounded Core
MCP tools, and there is no embedded model in this executable.

This is a locally tested teaching edition for Apple Silicon macOS. The examples
are designed for beginners; no child or classroom learning trial has been performed.
