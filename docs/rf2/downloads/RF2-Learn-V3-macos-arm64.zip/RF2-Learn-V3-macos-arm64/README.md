# RF2 local learning kit, Simple V3

Apple Silicon macOS only. Local candidate,19 November2026. MIT source and native
executables by Ilangkhumanan Thirunavokkarasu / SFE. This is not a universal compiler
release, complete SDK, notarized installer or new OS. All native binaries use ad-hoc
signatures; a valid signature does not establish publisher trust. No security
settings or quarantine attributes are changed by this package.

Open Terminal in this extracted folder:

    ./rf2 learn
    ./rf2 academy/examples/simple/hello.flow
    ./rf2 examples/guessing-game.flow
    ./rf2 inspect examples/work-planner.flow
    ./rf2 build examples/double-quiz.flow quiz
    ./quiz

No Node/npm/Python/C++ user runtime is required. macOS provides the shell, signing
and system utilities. The build command makes a CLI executable and refuses `.app`
output names; proper GUI app-bundle packaging is not provided. Interactive saved
programs include a native Simple engine. Constant Hello uses the smaller specialized
native output. Neither route embeds an AI model.

`bin/rf2c` is the qualified hints-R2 systems compiler. `bin/rf2-simple` is the locally
qualified V3 frontend. `bin/rf2-core` retains version0.17 and nine bounded MCP tools;
Simple/Systems programs are not admitted through those tools. Start the unchanged
stdio server with `./rf2 mcp`. Input-aware inspection is a separate CLI command,
not a new interactive MCP tool. Native code is trusted host code, not sandboxed.

The starter SDK includes only io/text/scan and a pinned derived manifest. Test it:

    ./rf2 check examples/native/sdk-count.flow
    ./rf2 native examples/native/sdk-count.flow 42

Use RF2_SDK_ROOT/RF2_COMPILER/RF2_SIMPLE_BIN only to select other explicit trusted
local tools. Missing tools fail rather than downloading anything. Help evidence
paths can refer to the full source checkout, not files shipped in this limited kit.
The included source/native examples require no repository path or installed plugin.

KIT.json and FILES-SHA256.json identify the package inputs/files. Validation receipts
are retained outside this ZIP in the project. No speed, energy, actual model-token
saving, classroom study, general safety or physical-device claim is made.
