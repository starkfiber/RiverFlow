RF2: small words, real programs

Save this in hello.flow:
  say "Hello, world!"
Run ./rf2 hello.flow

Remember and change:
  let points = 2
  set points = points + 3
  show points

Ask a question:
  ask number age "How old are you?"
  show age + 1

Make a choice:
  if age >= 18
   say "Adult ticket"
  else
   say "Child ticket"
  end

Repeat:
  repeat 3 times
   say "Hello!"
  end

Name a numeric calculation:
  fn twice(n)
   return n * 2
  end
  show twice(6)

Try ./rf2 examples/guessing-game.flow
Try ./rf2 examples/double-quiz.flow
Try ./rf2 examples/work-planner.flow
Use ./rf2 inspect FILE.flow to see a plan without answering questions.
Use ./rf2 build FILE.flow NEWNAME to save a standalone command-line executable.
Native source: ./rf2 native academy/examples/native/hello.flow
More: ./rf2 help topics or ./rf2 help lesson NUMBER

Whole nonnegative numbers only. Introduce names before a block, then change them
with set or same-kind ask inside it. Functions have one pure numeric return,
at most four parameters; no global reads, IO or recursive call graphs. Runtime
work is bounded to 4096 units across statements and expressions. repeat is capped
at 1000 iterations; source at64 instructions and64 KiB, block nesting at8.
The games are text games, with fixed secrets and no randomness or GUI claim.
