"""Run with Blender background Python. Import only admitted RF2-generated mesh data."""
from pathlib import Path
import argparse,sys,json,hashlib,math,os,stat,importlib.util
import bpy,bmesh
from mathutils import Vector
p=argparse.ArgumentParser();p.add_argument('--mesh',required=True,type=Path);p.add_argument('--output',required=True,type=Path);p.add_argument('--render',action='store_true');args=p.parse_args(sys.argv[sys.argv.index('--')+1:])
if args.output.exists():raise SystemExit('Choose a new output directory')
info=args.mesh.lstat()
if not stat.S_ISREG(info.st_mode) or info.st_size>131072:raise SystemExit('Mesh input must be a bounded regular file')
raw=args.mesh.read_bytes();text=raw.decode('ascii')
lines=text.splitlines()
if not lines or lines[0]!='# RF2_MESH_V1 centimeter Z_UP FORWARD_Y':raise SystemExit('Wrong mesh header')
params=lines[1].split()
if len(params)!=7 or params[0:2]!=['#','width'] or params[3]!='length' or params[5]!='radius':raise SystemExit('Invalid parameter header')
w,l,r=map(int,[params[2],params[4],params[6]])
if not(80<=w<=200 and 100<=l<=300 and 10<=r<=40 and l>=4*r):raise SystemExit('Parameters outside mesh contract')
allowed={'chassis','body','cabin','windscreen','eye_left','eye_right','wheel_left_front','wheel_right_front','wheel_left_rear','wheel_right_rear','antenna','antenna_cap'}
parts=[];all_vertices=[];current=None
for line in lines[2:]:
 words=line.split()
 if not words:continue
 if words[0]=='o':
  if len(words)!=2 or words[1] not in allowed or any(x['name']==words[1] for x in parts):raise SystemExit('Invalid object declaration')
  current={'name':words[1],'vertices':[],'faces':[],'first':len(all_vertices)};parts.append(current)
 elif words[0]=='v':
  if current is None or len(words)!=4 or len(all_vertices)>=256 or any(not x.isdigit() for x in words[1:]):raise SystemExit('Invalid vertex')
  v=tuple(map(int,words[1:]));
  if any(x>1000 for x in v):raise SystemExit('Coordinate limit')
  all_vertices.append(v);current['vertices'].append(v)
 elif words[0]=='f':
  if current is None or len(words)!=4 or any(not x.isdigit() for x in words[1:]):raise SystemExit('Invalid triangle')
  face=tuple(int(x)-1-current['first'] for x in words[1:])
  if len(set(face))!=3 or any(i<0 or i>=len(current['vertices']) for i in face):raise SystemExit('Invalid local triangle index')
  current['faces'].append(face)
 else:raise SystemExit('Unrecognized mesh instruction')
if set(x['name'] for x in parts)!=allowed or len(all_vertices)!=128 or sum(len(x['faces']) for x in parts)!=208:raise SystemExit('Mesh budget/parts mismatch')
# Native geometry is admitted before Blender scene mutation or artifact publication.
for part in parts:
 edges={};volume=0
 for a,b,c in part['faces']:
  va,vb,vc=[Vector(part['vertices'][i]) for i in (a,b,c)]
  if (vb-va).cross(vc-va).length<1e-6:raise SystemExit('Degenerate triangle')
  volume+=va.dot(vb.cross(vc))/6
  for edge in [(a,b),(b,c),(c,a)]:edges[tuple(sorted(edge))]=edges.get(tuple(sorted(edge)),0)+1
 if any(n!=2 for n in edges.values()) or volume<=0:raise SystemExit('Closed outward surface check failed: '+part['name'])
args.output.mkdir(parents=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
scene=bpy.context.scene;scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1
collection=bpy.data.collections.new('RF2_ROVER');scene.collection.children.link(collection)
def material(name,color,metal,rough):
 m=bpy.data.materials.new(name);m.use_nodes=True;b=m.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(*color,1);b.inputs['Metallic'].default_value=metal;b.inputs['Roughness'].default_value=rough;return m
mats=[material('RF2_Porcelain',(.79,.85,.77),.18,.38),material('RF2_Charcoal',(.035,.06,.065),.1,.65),material('RF2_Teal',(.02,.25,.28),.35,.28),material('RF2_Brass',(.95,.54,.13),.6,.3)]
for part in parts:
 vertices=[((x-(w+r//2*2)/2)*.01,(y-l/2)*.01,z*.01) for x,y,z in part['vertices']]
 mesh=bpy.data.meshes.new(part['name']+'_mesh');mesh.from_pydata(vertices,[],part['faces']);mesh.update(calc_edges=True)
 obj=bpy.data.objects.new(part['name'],mesh);collection.objects.link(obj)
 obj['generator']='Native RF2 procedural mesh';obj['rf2_mesh_sha256']=hashlib.sha256(raw).hexdigest()
 mi=0
 if part['name'].startswith('wheel') or part['name']=='chassis':mi=1
 elif part['name'] in ('windscreen','cabin'):mi=2
 elif part['name'].startswith('antenna') or part['name'].startswith('eye'):mi=3
 mesh.materials.append(mats[mi])
 # Intentional per-face planar UV overlap; no image textures are used.
 uv=mesh.uv_layers.new(name='RF2_FaceUV')
 for poly in mesh.polygons:
  normal=poly.normal;axis=max(range(3),key=lambda k:abs(normal[k]));axes=[i for i in range(3) if i!=axis]
  coords=[vertices[mesh.loops[i].vertex_index] for i in poly.loop_indices]
  lo=[min(v[a] for v in coords) for a in axes];hi=[max(v[a] for v in coords) for a in axes]
  for li,v in zip(poly.loop_indices,coords):uv.data[li].uv=tuple((v[a]-lo[k])/max(hi[k]-lo[k],1e-9) for k,a in enumerate(axes))
assets=list(collection.objects)
def audit_objects(objects):
 rows=[]
 for obj in objects:
  mesh=obj.data;mesh.calc_loop_triangles();bm=bmesh.new();bm.from_mesh(mesh)
  rows.append({'name':obj.name,'vertices':len(mesh.vertices),'triangles':len(mesh.loop_triangles),'nonManifoldEdges':sum(not e.is_manifold for e in bm.edges),'looseVertices':sum(not v.link_edges for v in bm.verts),'uvLayers':len(mesh.uv_layers),'scale':list(obj.scale),'materials':len(mesh.materials)})
  bm.free()
 points=[obj.matrix_world@v.co for obj in objects for v in obj.data.vertices]
 bounds=[[min(v[k] for v in points),max(v[k] for v in points)] for k in range(3)]
 return {'objects':rows,'objectCount':len(rows),'triangles':sum(x['triangles'] for x in rows),'bounds':bounds,'dimensions':[hi-lo for lo,hi in bounds]}
bpy.context.view_layer.update();source_audit=audit_objects(assets)
assert source_audit['objectCount']==12 and source_audit['triangles']==208
bpy.ops.wm.save_as_mainfile(filepath=str(args.output/'rf2-rover-source.blend'))
assert all(not x['nonManifoldEdges'] and not x['looseVertices'] and x['uvLayers'] and x['scale']==[1,1,1] for x in source_audit['objects'])
for obj in scene.objects:obj.select_set(False)
for obj in assets:obj.select_set(True)
bpy.context.view_layer.objects.active=assets[0]
glb=args.output/'rf2-rover.glb'
result=bpy.ops.export_scene.gltf(filepath=str(glb),export_format='GLB',use_selection=True,export_yup=True,export_animations=False,export_cameras=False,export_lights=False,export_materials='EXPORT',export_normals=False,export_texcoords=False,export_tangents=False)
assert 'FINISHED' in result and glb.is_file()
# Re-import into a separate fresh scene before rendering and compare the real exported data.
bpy.ops.wm.read_factory_settings(use_empty=True)
result=bpy.ops.import_scene.gltf(filepath=str(glb),merge_vertices=True);assert 'FINISHED' in result
imported=[o for o in bpy.context.scene.objects if o.type=='MESH'];bpy.context.view_layer.update();roundtrip=audit_objects(imported)
assert roundtrip['objectCount']==source_audit['objectCount'] and roundtrip['triangles']==208
assert all(not x['nonManifoldEdges'] and not x['looseVertices'] for x in roundtrip['objects'])
assert all(abs(a-b)<1e-5 for aa,bb in zip(source_audit['bounds'],roundtrip['bounds']) for a,b in zip(aa,bb))
assert len({m.name for o in imported for m in o.data.materials})==4
# glTF seam vertices are merged by the explicit importer option; closed topology is rechecked.
scene=bpy.context.scene;scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=24
scene.render.resolution_x=600;scene.render.resolution_y=600;scene.render.resolution_percentage=100
scene.world=bpy.data.worlds.new('RF2_StudioWorld');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.8,.84,.8,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.4
floor=material('Studio_Ground',(.70,.75,.70),0,.86)
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.006));plane=bpy.context.object;plane.name='STUDIO_ONLY_GROUND';plane.data.materials.append(floor)
for name,loc,energy,size in [('Key',(3,4,6),650,5),('Fill',(-4,2,4),180,4),('Rim',(1,-4,5),420,3)]:
 lamp=bpy.data.lights.new(name,'AREA');lamp.energy=energy;lamp.shape='DISK';lamp.size=size;obj=bpy.data.objects.new(name,lamp);scene.collection.objects.link(obj);obj.location=loc;obj.rotation_euler=(Vector((0,0,.4))-obj.location).to_track_quat('-Z','Y').to_euler()
cam=bpy.data.cameras.new('RF2_PresentationCamera');cam.type='ORTHO';cam.ortho_scale=3.8;camera=bpy.data.objects.new('RF2_PresentationCamera',cam);scene.collection.objects.link(camera);scene.camera=camera
views={'beauty':(3.6,4.6,3.0),'front':(0,5,1.5),'side':(5,0,1.5),'top':(0,0,6)}
renders=[]
for name,loc in views.items():
 camera.location=loc;camera.rotation_euler=(Vector((0,0,.5))-camera.location).to_track_quat('-Z','Y').to_euler()
 if args.render:
  scene.render.filepath=str(args.output/(name+'.png'));bpy.ops.render.render(write_still=True);renders.append(name+'.png')
camera.location=views['beauty'];camera.rotation_euler=(Vector((0,0,.5))-camera.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.wm.save_as_mainfile(filepath=str(args.output/'rf2-rover.blend'))
# Run the skill's audit on the exported asset-only selection in a new clean import scene,
# avoiding presentation plane (intentionally not a watertight asset) contaminating QA.
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(glb),merge_vertices=True)
audit_script=Path('/Users/ik/.codex/skills/blender-3d-asset-generation/scripts/audit_blender_asset.py')
spec=importlib.util.spec_from_file_location('rf2_skill_audit',audit_script);audit_mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit_mod)
oldargs=sys.argv;sys.argv=['audit','--','--output',str(args.output/'skill-audit.json'),'--max-triangles','1000','--require-applied-scale','--fail-on-warnings'];audit_exit=audit_mod.main();sys.argv=oldargs
assert audit_exit==0, 'Roundtrip skill audit failed'
# Export splits seam vertices; keep topology checks on original closed source meshes separately.
report={'schema':'rf2.blender.pipeline.v1','blenderVersion':bpy.app.version_string,'inputMeshSha256':hashlib.sha256(raw).hexdigest(),'parametersCm':{'width':w,'length':l,'wheelRadius':r},'sourceMeshAudit':source_audit,'glbRoundtripAudit':roundtrip,'materials':4,'imageTextures':0,'animations':0,'armatures':0,'units':'meters','up':'Z in Blender, glTF export Y_UP and reimport conversion verified','forward':'Y','pivot':'centered XY, groundZ0','uvPolicy':'Source .blend has intentionally overlapping per-face UVs; untextured GLB omits UVs/normals to retain shared indexed geometry, importer derives flat normals','assetTopology':'12 separate closed source parts, intentional physical interpenetration; not a merged watertight union','export':'GLB, selection-only source rover; positions/triangle indices/materials, no UV/normal/texture attributes; cameras/lights/animations excluded; import merge_vertices=True','roundtripPassed':True,'importMergeVertices':True,'skillAuditExit':audit_exit,'renders':renders,'limits':['RF2 computes bounded vertex/triangle geometry and validates dimensions; Blender bpy importer supplies PBR materials, camera, lighting, render and export.','Not an RF2 replacement for Blender or Python; not a native RF2 render engine.','No rig, LOD, collision asset or target-game-engine/device validation.','No rendering performance/speed/token benefit or new device physics measured.']}
(args.output/'PIPELINE.json').write_text(json.dumps(report,indent=2))
print('RF2_BLENDER_PIPELINE_OK '+json.dumps({'triangles':208,'objects':12,'roundtrip':True,'renders':len(renders),'skillAuditExit':audit_exit}))
