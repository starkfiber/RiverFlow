from pathlib import Path
import sys,subprocess,hashlib,json
root=Path(__file__).resolve().parents[2];src=Path(__file__).resolve().parent
out=Path(sys.argv[1]).resolve()
if out.exists():raise SystemExit('Choose a new output directory')
out.mkdir(parents=True)
compiler=root/'artifacts/friendly-hints-20261118/compiler-r2/rf2c'
assert hashlib.sha256(compiler.read_bytes()).hexdigest()=='e219b75242d4cc9ce1e3a3ceeaf5883eee258515bd60bc8faf11db67b3e049b7'
r=subprocess.run([str(compiler),str(src/'rover.flow'),str(out/'rf2-rover-mesh'),'--compact','--opt','--diagnostic-json'],capture_output=True,text=True)
(out/'compiler.stdout').write_text(r.stdout);(out/'compiler.stderr').write_text(r.stderr)
if r.returncode:raise SystemExit(r.returncode)
subprocess.run(['/usr/bin/codesign','-s','-',str(out/'rf2-rover-mesh')],check=True)
subprocess.run(['/usr/bin/codesign','--verify',str(out/'rf2-rover-mesh')],check=True)
(out/'BUILD.json').write_text(json.dumps({'target':'macos-arm64','compilerSha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'sourceSha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [src/'rover.flow',src/'lib/output.rf2']},'binarySha256':hashlib.sha256((out/'rf2-rover-mesh').read_bytes()).hexdigest(),'binaryBytes':(out/'rf2-rover-mesh').stat().st_size},indent=2))
