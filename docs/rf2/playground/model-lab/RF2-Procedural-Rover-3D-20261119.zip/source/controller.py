from pathlib import Path
import subprocess,json,sys,hashlib
root=Path(__file__).resolve().parents[2];src=Path(__file__).resolve().parent;out=Path(sys.argv[1]).resolve()
if out.exists():raise SystemExit('Choose new output')
out.mkdir(parents=True)
(out/'BRIDGE-SOURCE.py').write_bytes((src/'bridge.py').read_bytes())
(out/'CONTROLLER-SOURCE.py').write_bytes(Path(__file__).read_bytes())
binary=root/'artifacts/rf2-blender-20261119/build-r1/rf2-rover-mesh';cases=[]
for args,valid in [([],True),(['80','100','10'],True),(['200','300','40'],True),(['120','200','24'],True),(['79','200','24'],False),(['120','99','24'],False),(['120','100','40'],False),(['120','200','0'],False),(['0120','200','24'],False),(['120','200','-1'],False),(['120','200','9.9'],False),(['120','200','18446744073709551615'],False),(['120'],False)]:
 r=subprocess.run([str(binary),*args],capture_output=True,timeout=5);passed=(r.returncode==0)==valid and (r.stdout.startswith(b'# RF2_MESH_V1') if valid else b'\"published\":false' in r.stdout)
 cases.append({'args':args,'validExpected':valid,'passed':passed,'returnCode':r.returncode,'stdoutSha256':hashlib.sha256(r.stdout).hexdigest()})
 if valid:(out/('mesh-'+str(len(cases))+'.obj')).write_bytes(r.stdout)
assert all(c['passed'] for c in cases)
(out/'NATIVE-CASES.json').write_text(json.dumps({'passed':len(cases),'total':len(cases),'cases':cases},indent=2))
command=['/Applications/Blender.app/Contents/MacOS/Blender','--background','--factory-startup','--python-exit-code','9','--python',str(src/'bridge.py'),'--','--mesh',str(out/'mesh-1.obj'),'--output',str(out/'scene')]
if '--render' in sys.argv:command.append('--render')
r=subprocess.run(command,capture_output=True,text=True,timeout=180)
(out/'blender.stdout').write_text(r.stdout);(out/'blender.stderr').write_text(r.stderr)
if r.returncode:raise SystemExit(r.returncode)
if 'RF2_BLENDER_PIPELINE_OK' not in r.stdout:raise SystemExit('Missing pipeline success marker')
print(r.stdout[-2000:])
