# RF2 geometry to Blender: a real local 3D workflow

This experiment creates a small low-poly rover from native RF2-generated geometry.
It is a scoped interoperability demonstration, not a replacement for Blender,
a native RF2 renderer, or proof of faster artwork generation.

## Boundary

1. `rover.flow` validates width, length and wheel radius, computes 128 integer
   vertices and 208 triangles, and writes an admitted OBJ subset. It generates
   boxes and octagonal-prism wheels itself. No Blender operation creates the rover
   asset geometry.
2. `bridge.py` is a fixed Blender Python adapter. It validates the complete data,
   creates meshes from those actual vertices/faces, assigns four materials, exports
   GLB, imports that GLB into a clean scene and checks topology and bounds. Blender
   supplies shading, camera, lights, ground plane, Cycles rendering and exporters.
3. The native mesh emitter has no Python/Node dependency. The render pipeline
   explicitly depends on the installed Blender and its Python API.

## Asset contract

A new static decorative rover; meters in Blender, Z up, +Y forward, centered XY and
pivot on ground Z=0. Source input geometry uses centimeters and nonnegative integer
coordinates. Four wheels, body, cabin, windshield, two eyes and antenna parts remain
separate. Their physical intersection is intentional; this is not a merged solid.
Each source part is a closed outward triangle surface. Budget: 12 meshes, 208
triangles, four materials, no image textures, rig or animation. Per-triangle planar
UVs overlap intentionally because the material-only asset has no texture atlas.

Default dimensions are width120 cm, length200 cm, wheel radius24 cm. Accepted
width80..200, length100..300, radius10..40, with length>=4*radius. These bounds are
program inputs, not a physical vehicle specification or hardware measurement.

## Run

From the RiverFlow checkout, select new artifact directories:

```
python3 experiments/rf2-blender-20261119/build.py artifacts/rf2-blender-20261119/new-build
```

The helper pins the existing native compiler and captures exact source/binary
hashes. `rf2-rover-mesh` emits OBJ to stdout; users may redirect to a **new** file.
`controller.py` uses the qualified build-r1 and the existing Blender CLI. Run it
through the configured disposable-cache guard. `--render` produces four PNG views;
without it geometry, exports, save and roundtrip verification still run.

The controller checks all native parameters before passing a mesh to Blender.
Malformed mesh data is refused before scene mutation/output creation. Blender
runs with `--python-exit-code 9`; the controller additionally requires a success
marker, preserving actual script failures rather than trusting process startup.
The exporter and source scenes always use new paths.

## Evidence and limits

The original mesh source `.blend`, presentation `.blend`, `.glb`, beauty/front/side/top PNGs and
JSON reports are project-owned unique artifacts. Temporary caches go to the
configured mounted cache, not the only copies of the asset.

The first export/import preserved dimensions and triangles, but the default glTF
importer split seam vertices and the skill audit reported non-manifold boundaries.
That warning-only first report is retained. Requesting `merge_vertices=True` alone did not merge vertices with differing
normal/UV attributes; that second attempt stopped with exit9 before rendering.
Those are standard glTF attribute seams, not automatically physical holes.
For this untextured static asset, the final scoped export omits normal/UV
attributes and retains shared positions/triangle indices/materials. Blender derives
flat normals on import. The actual roundtrip is closed, dimensionally identical
and passes the skill auditor with fail-on-warnings. The original editable source
.blend retains its intentionally overlapping UVs. This is an explicit untextured
variant, not a hidden repair of the earlier attribute-bearing GLB.

Blender 5.2.1 LTS is the inspected local engine. Its deprecated use_nodes warnings
are retained and do not claim Blender 6 compatibility. No target game-engine,
physical device, collision, LOD, rig, deformation, texture-baking or production
frame-rate qualification is claimed. No speed, energy, real AI-token advantage,
novel geometry algorithm or transistor/quantum claim was measured.
