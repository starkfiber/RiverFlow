RF2 0.18 development candidate, macOS ARM64
Separate trust and website research bundle. Stable full runtime remains 0.17.
Native programs require no Node/npm/Python runtime.
./rf2-trust keygen /private/new-key
./rf2-trust mcp /private/new-key
./rf2-site
The VM controller needs separately installed QEMU/HVF, firmware and a reviewed Linux image/seed.
Python reference server and benchmark controller are development/guest components only.
HMAC uses a shared key, not a public signature. Rotation requires restart. No anti-replay or hardware attestation.
Ad-hoc signed, not Developer-ID signed or notarized. Do not bypass OS security warnings; build/review locally if required.
This is not an RF2 hypervisor or production HTTP framework.
Author Ilangkhumanan Thirunavokkarasu. Published by SFE. MIT.
