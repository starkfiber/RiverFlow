RF2 0.34 development candidate. Native compiler HOST: Apple Silicon macOS.
Firmware TARGET: ESP32-C3 bounded RV32IM RAM image, not arbitrary RF2 programs.
Ad-hoc signed, not notarized. Stable release unchanged.

./rf2-esp32c3 examples/esp32c3/uart-smoke.flow NEW-PREFIX
Outputs NEW-PREFIX.elf / .bin / .map. Existing outputs refuse.
./rf2 mcp

To rebuild the cross-compiler using RF2 only:
./rf2c source/embedded-compiler.rf2 NEW-COMPILER --compact
Apply normal macOS codesign -s - NEW-COMPILER before execution.
The native compilers need no Python/Node/C++/assembler/linker runtime.
Python test controllers and GNU/QEMU comparison tools are development tools.

ROM/SPI boot, UART TX/RX and scripted GPIO/sensor models were tested in QEMU.
NO physical board or temperature sensor was tested. Firmware is NOT automatically flashed.
The examples inherit ROM UART setup. I2C timing and watchdog behavior need hardware checks.
Read examples/esp32c3/README.md and board.json before any device operation.
No Secure Boot, OTA, radio, other ESP32 architecture, Arduino or Pico support claimed.
Existing nine bounded MCP tools gain no raw-MMIO/flash/device authority.
Evidence/limits: https://github.com/starkfiber/RiverFlow/blob/main/docs/ESP32C3-0.34.md
Created by Ilangkhumanan Thirunavokkarasu. Published by SFE. MIT licence.
