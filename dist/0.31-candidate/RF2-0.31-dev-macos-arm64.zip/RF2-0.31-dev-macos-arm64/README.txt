RF2 0.31 development bundle: Apple Silicon macOS only

Development candidate, not a stable release, signed with local ad-hoc signatures.
Not Apple-notarized. Follow your normal OS security review; do not bypass warnings.
These native programs require no Node, npm, Python or C++ runtime.

From this folder:
 ./rf2 status
 ./rf2c --check examples/hello.rf2
 ./rf2c examples/hello.rf2 new-hello --opt --compact
 codesign -s - new-hello
 ./new-hello
 printf banana | ./text-search ana --overlap
 ./rf2 mcp

The hello program exits0; the search returns two overlapping matches.
MCP retains the stable0.17 runtime contract and nine bounded tools. Compiler source
is development0.31; these are separate version identities. There is no embedded AI
model or raw systems-code execution over MCP. Systems compilation is trusted.

Search limits:1MiB stdin,128-byte query, byte matching rather than Unicode words.
Check-only validates but does not run source or prove its runtime correctness.
Signature/manifest hashes identify bytes, not external certification.

Source, test controllers, exact measurements and remaining gaps:
 https://github.com/starkfiber/RiverFlow/blob/main/docs/FOUNDATION-0.31.md

Created by Ilangkhumanan Thirunavokkarasu. Published by SFE. MIT licence.
