RF2 Documents 0.37 development bundle
Created by Ilangkhumanan Thirunavokkarasu. Published by SFE. MIT licence.
Host: Apple Silicon macOS. Ad-hoc signed, not notarized.
No Node/npm/Python/C++ user runtime is required.

From this extracted folder:
./workspace examples/documents/fixtures/documents.txt --serve
Open the printed local URL. Stop in Terminal with Ctrl+C.
The included texts are programming examples. To read your own files, put one
literal path per line in a UTF-8 manifest, then name it instead of the example list.
Relative paths resolve from the current Terminal directory, not the manifest folder.
Files are read-only, strict UTF-8; final-component symlinks and nonregular files refuse.
Limits: 64 documents, 64 KiB each, 1 MiB total; query 256 UTF-8 bytes.
The snapshot lives in memory; restart to reload changes. No PDF/DOCX extraction,
edits, persistent index, watched updates, accounts or collaboration is included.
The local listener is not authenticated against other processes on this Mac.

./workspace examples/documents/fixtures/documents.txt --catalog
./text-lines examples/documents/fixtures/tamil.txt தமிழ்
./rf2 status
./rf2 mcp

The unchanged native runtime reports 0.17.0 and exposes the same nine bounded tools.
The included Mac compiler is the previously qualified 0.36-bundle compiler.
Version 0.37 identifies these new libraries/application/package, not a new backend.
No embedded compiler, device operation, flash capability or new MCP authority is added.

To rebuild the application from included RF2 source:
export RF2_HOME="$PWD"
sh tools/dev.sh build examples/documents/workspace.flow rebuilt-workspace --opt
./rebuilt-workspace/program examples/documents/fixtures/documents.txt --catalog

Source documentation links assume the full source repository. Current guide:
https://github.com/starkfiber/RiverFlow/tree/main/examples/documents
Tests use independent developer tooling; they are not user runtime dependencies.
No new speed, energy, AI-token or independent security-certification claim.
