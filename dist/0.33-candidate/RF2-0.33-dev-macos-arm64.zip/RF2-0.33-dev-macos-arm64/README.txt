RF2 0.33 development candidate. Apple Silicon macOS only.
Ad-hoc signed, not notarized; use normal OS security review.
Stable release unchanged. Native programs require no Node/npm/Python runtime.

./rf2 status
./rf2c --check examples/collection-tools/telemetry-summary.flow
printf '9,1,9,3,2' | ./telemetry-summary
printf '9,1,9,3,2' | ./value-frequency
./rf2 mcp

Both .flow apps share examples/collection-tools/lib/numbers.rf2 and output.rf2.
To compile: rf2c SOURCE NEW-OUTPUT --opt --compact
Then apply normal macOS codesign -s - NEW-OUTPUT before execution.
Input: canonical unsigned decimal integers, ASCII whitespace/comma separators,
1MiB stdin, 65536 values. Summary uses checked u64 sum and lower median.
Output numeric JSON requires an integer-aware consumer for full u64 precision.
Collections relocate heap storage; local checked moves and typed mutable borrows.
No owner returns, concurrency, arbitrary raw-pointer safety or infallible cleanup.
Runtime retains0.17 contract/nine bounded MCP tools; compiler development0.33.
No embedded AI, raw systems over MCP, ESP32 or Arduino firmware support.
Source/tests/limits: https://github.com/starkfiber/RiverFlow/blob/main/docs/HEAP-COLLECTIONS-0.33.md
Created by Ilangkhumanan Thirunavokkarasu. Published by SFE. MIT licence.
