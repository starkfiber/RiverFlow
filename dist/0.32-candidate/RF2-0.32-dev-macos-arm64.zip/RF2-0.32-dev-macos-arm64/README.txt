RF2 0.32 development candidate. Apple Silicon macOS only.
Ad-hoc signed, not notarized; use normal OS security review.
Stable release remains unchanged. Native programs need no Node/npm/Python runtime.

./rf2 status
./rf2c --check examples/search-tools/main.rf2
printf banana | ./text-search ana --overlap
printf 'WARN retry\nINFO ready\n' | ./log-scan WARN
./rf2 mcp

Both applications import examples/search-tools/lib/search.rf2.
To compile a fresh app, use rf2c SOURCE NEW-OUTPUT --opt --compact,
then apply normal macOS codesign -s - NEW-OUTPUT before execution.
Query limit4096bytes, stdin1MiB. Byte matching, not Unicode normalization.
New arrays have separate frame storage, not an unbounded heap or thread model.
Runtime retains0.17 contract/nine bounded tools; compiler source is development0.32.
No embedded AI or raw systems execution over MCP.
Source, tests and limits: https://github.com/starkfiber/RiverFlow/blob/main/docs/STRUCTURED-STORAGE-0.32.md
Created by Ilangkhumanan Thirunavokkarasu. Published by SFE. MIT licence.
